# Qt SerialPort Programming Demo
基于Qt的串口通信演示
##程序截图
![运行截图](https://github.com/WalkingFrog/Qt-SerialPort-Programming-Demo/blob/master/other/processing.png)
