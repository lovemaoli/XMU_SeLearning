#include <stdio.h>
int main(void)
{
    printf("A .c is used to end a C program filename.\n");
    
    return 0;
}
