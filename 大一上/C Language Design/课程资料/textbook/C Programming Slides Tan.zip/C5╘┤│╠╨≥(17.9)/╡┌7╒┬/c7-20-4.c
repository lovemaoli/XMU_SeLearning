//file4.c
void print_string(char str[])
{
  printf("%s\n",str);
}
