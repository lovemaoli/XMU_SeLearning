#include <stdio.h>
int main()
{void printstar();            
 void print_message();       
 printstar();                  
 print_message();            
 printstar(); 
 return 0;
}

void printstar()           
{
 printf("******************\n");
}

void print_message()           
{printf("  How do you do!\n");
}
