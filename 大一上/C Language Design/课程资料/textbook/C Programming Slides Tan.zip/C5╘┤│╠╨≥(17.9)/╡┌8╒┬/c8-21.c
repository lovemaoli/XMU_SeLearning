#include <stdio.h>
int main()
 {char *a="I love China!";
  a=a+7;
  printf("%s\n",a);
  return 0;
}
