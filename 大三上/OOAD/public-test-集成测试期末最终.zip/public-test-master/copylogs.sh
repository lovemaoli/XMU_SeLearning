cd /root/logs
TIME=$(date "+%Y-%m-%d")
for file in $(ls *.$TIME.log)
do
  curl -T $file $1/test/logs/  -u mingqiu:$2
done