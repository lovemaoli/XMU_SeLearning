#!/bin/bash
## modified by luxun@2020

## 将文件结尾从CRLF改为LF，解决了cd 错误问题
cd /public-test
git pull

#cp -rf /home/mybaby/private-test/* $1/private

## 在主项目下使用 -pl -am 编译子项目，否则找不到依赖
## $1 代表第一个参数，$0代表命令名
mvn clean surefire-report:report -Dmanagement.gate=$3 -Dmall.gate=$4 1>public.log
echo "curl -X MKCOL $5/test/integration-test/$1/ -u mingqiu:$6"
curl -X MKCOL $5/test/integration-test/$1/ -u mingqiu:$6
echo "curl -X MKCOL $5/test/integration-test/$1/$2/ -u mingqiu:$6"
curl -X MKCOL $5/test/integration-test/$1/$2/ -u mingqiu:$6
echo "curl -X MKCOL $5/test/integration-test/$1/$2/public/ -u mingqiu:$6"
curl -X MKCOL $5/test/integration-test/$1/$2/public/ -u mingqiu:$6
echo "curl -T target/site/surefire-report.html $5/test/integration-test/$1/$2/public/index.html -u mingqiu:$6"
curl -T target/site/surefire-report.html $5/test/integration-test/$1/$2/public/index.html -u mingqiu:$6
echo "curl -X MKCOL $5/test/integration-test/$1/$2/public/css/ -u mingqiu:$6"
curl -X MKCOL $5/test/integration-test/$1/$2/public/css/ -u mingqiu:$6
curl -X MKCOL $5/test/integration-test/$1/$2/public/images/ -u mingqiu:$6
curl -X MKCOL $5/test/integration-test/$1/$2/public/images/logos/ -u mingqiu:$6
curl -T css/apache-maven-fluido-1.11.1.min.css $5/test/integration-test/$1/$2/public/css/apache-maven-fluido-1.11.1.min.css -u mingqiu:$6
curl -T css/print.css $5/test/integration-test/$1/$2/public/css/print.css -u mingqiu:$6
curl -T css/site.css $5/test/integration-test/$1/$2/public/css/site.css -u mingqiu:$6
curl -T images/logos/maven-feather.png $5/test/integration-test/$1/$2/public/images/logos/maven-feather.png -u mingqiu:$6
curl -T public.log $5/test/integration-test/$1/$2/public.log -u mingqiu:$6

#cd ../private
#mvn surefire-report:report -Dmanagement.gate=$3 -Dmall.gate=$4
#mvn site:deploy
