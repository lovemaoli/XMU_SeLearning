package cn.edu.xmu.oomall.publictest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

/**
 * @author Ming Qiu
 **/
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
public class PublicTestApp {
    public static void main(String[] args) {
        SpringApplication.run(PublicTestApp.class, args);
    }
}
