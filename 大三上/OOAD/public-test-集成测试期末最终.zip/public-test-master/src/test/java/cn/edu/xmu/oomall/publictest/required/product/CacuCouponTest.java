package cn.edu.xmu.oomall.publictest.required.product;

import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Collections;

/**
 * @author Chihua Ying
 */
@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CacuCouponTest extends BaseTestOomall {
    private final static String CACUCOUPON = "/product/couponactivities/{id}/caculate";

    /**
     * 计算商品优惠价格测试
     * 限制：满3件
     * 优惠：最便宜的5折
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsAmountAndCouponIsCheapestPercentage() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 1, \"quantity\": 1},{\"onsaleId\": 3, \"quantity\": 1},{\"onsaleId\": 4, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 5)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '1')].discount").isEqualTo(Collections.singletonList(52887))//原价53295
                .jsonPath("$.data[?(@.id == '3')].discount").isEqualTo(Collections.singletonList(12554))//原价12650
                .jsonPath("$.data[?(@.id == '4')].discount").isEqualTo(Collections.singletonList(1020));//原价1027
    }

    /**
     * 计算商品优惠价格测试
     * 限制：满3件
     * 优惠：9折
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsAmountAndCouponIsPercentage() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 1, \"quantity\": 1},{\"onsaleId\": 3, \"quantity\": 1},{\"onsaleId\": 4, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 6)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '1')].discount").isEqualTo(Collections.singletonList(47966))//原价53295
                .jsonPath("$.data[?(@.id == '3')].discount").isEqualTo(Collections.singletonList(11386))//原价12650
                .jsonPath("$.data[?(@.id == '4')].discount").isEqualTo(Collections.singletonList(925));//原价1027
    }

    /**
     * 计算商品优惠价格测试
     * 限制：满3件
     * 优惠：10元
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsAmountAndCouponIsPrice() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 1, \"quantity\": 1},{\"onsaleId\": 3, \"quantity\": 1},{\"onsaleId\": 4, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 7)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '1')].discount").isEqualTo(Collections.singletonList(52500))//原价53295
                .jsonPath("$.data[?(@.id == '3')].discount").isEqualTo(Collections.singletonList(12462))//原价12650
                .jsonPath("$.data[?(@.id == '4')].discount").isEqualTo(Collections.singletonList(1012));//原价1027
    }

    /**
     * 计算商品优惠价格测试
     * 限制：跨2类
     * 优惠：10元
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsCategoryCrossAndCouponIsPrice() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 9, \"quantity\": 1},{\"onsaleId\": 12, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 9)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '9')].discount").isEqualTo(Collections.singletonList(6324))//原价6985
                .jsonPath("$.data[?(@.id == '12')].discount").isEqualTo(Collections.singletonList(3231));//原价3569
    }

    /**
     * 计算商品优惠价格测试
     * 限制：跨2类
     * 优惠：9折
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsCategoryCrossAndCouponIsPercentage() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 9, \"quantity\": 1},{\"onsaleId\": 12, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 10)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '9')].discount").isEqualTo(Collections.singletonList(6287))//原价6985
                .jsonPath("$.data[?(@.id == '12')].discount").isEqualTo(Collections.singletonList(3213));//原价3569
    }

    /**
     * 计算商品优惠价格测试
     * 限制：跨2类
     * 优惠：最便宜的5折
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsCategoryCrossAndCouponIsCheapestPercentage() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 9, \"quantity\": 1},{\"onsaleId\": 12, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 11)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '9')].discount").isEqualTo(Collections.singletonList(5804))//原价6985
                .jsonPath("$.data[?(@.id == '12')].discount").isEqualTo(Collections.singletonList(2966));//原价3569
    }

    /**
     * 计算商品优惠价格测试
     * 限制：满100
     * 优惠：最便宜的5折
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsPriceAndCouponIsCheapestPercentage() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 6, \"quantity\": 1},{\"onsaleId\": 8, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 97)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '6')].discount").isEqualTo(Collections.singletonList(22045))//原价29086
                .jsonPath("$.data[?(@.id == '8')].discount").isEqualTo(Collections.singletonList(20695));//原价27306
    }

    /**
     * 计算商品优惠价格测试
     * 限制：满100
     * 优惠：9折
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsPriceAndCouponIsPercentage() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 6, \"quantity\": 1},{\"onsaleId\": 8, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 98)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '6')].discount").isEqualTo(Collections.singletonList(26178))//原价29086
                .jsonPath("$.data[?(@.id == '8')].discount").isEqualTo(Collections.singletonList(24576));//原价27306
    }

    /**
     * 计算商品优惠价格测试
     * 限制：满100
     * 优惠：10元
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsPriceAndCouponIsPrice() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 6, \"quantity\": 1},{\"onsaleId\": 8, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 99)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '6')].discount").isEqualTo(Collections.singletonList(28571))//原价29086
                .jsonPath("$.data[?(@.id == '8')].discount").isEqualTo(Collections.singletonList(26822));//原价27306
    }

    /**
     * 计算商品优惠价格测试
     * 限制：跨2类 且 满100
     * 优惠：10元
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsPriceAndCategoryCrossAndCouponIsPrice() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 6, \"quantity\": 1},{\"onsaleId\": 8, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 100)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '6')].discount").isEqualTo(Collections.singletonList(28571))//原价29086
                .jsonPath("$.data[?(@.id == '8')].discount").isEqualTo(Collections.singletonList(26822));//原价27306
    }

    /**
     * 计算商品优惠价格测试
     * 限制：3件 且 满100
     * 优惠：9折
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsPriceAndAmountAndCouponIsPercentage() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 6, \"quantity\": 1},{\"onsaleId\": 8, \"quantity\": 1},{\"onsaleId\": 9, \"quantity\": 2}]";
        this.mallClient.post().uri(CACUCOUPON, 101)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '6')].discount").isEqualTo(Collections.singletonList(26178))//原价29086
                .jsonPath("$.data[?(@.id == '8')].discount").isEqualTo(Collections.singletonList(24576))//原价27306
                .jsonPath("$.data[?(@.id == '9')].discount").isEqualTo(Collections.singletonList(6287));//原价6985
    }

    /**
     * 计算商品优惠价格测试
     * 未满足数量限制
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenIsNotSatisfiedWithAmountLimitation() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 6, \"quantity\": 1},{\"onsaleId\": 8, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 6)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '6')].discount").doesNotExist()
                .jsonPath("$.data[?(@.id == '8')].discount").doesNotExist();
    }

    /**
     * 计算商品优惠价格测试
     * 未满足数量限制（优惠为最便宜的5折）
     * @author 吴凯
     */
    @Test
    public void testCacuCouponWhenIsNotSatisfiedGivenAmountLimitation3() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 6, \"quantity\": 1},{\"onsaleId\": 8, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 5L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '6')].discount").doesNotExist()
                .jsonPath("$.data[?(@.id == '8')].discount").doesNotExist();
    }

    /**
     * 计算商品优惠价格测试
     * 未满足数量限制（优惠为10元）
     * @author 吴凯
     */
    @Test
    public void testCacuCouponWhenIsNotSatisfiedGivenAmountLimitation2() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 6, \"quantity\": 1},{\"onsaleId\": 8, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 7)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '6')].discount").doesNotExist()
                .jsonPath("$.data[?(@.id == '8')].discount").doesNotExist();
    }

    /**
     * 计算商品优惠价格测试
     * 未满足价格限制
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenIsNotSatisfiedWithPriceLimitation() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 10, \"quantity\": 2},{\"onsaleId\": 12, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 98)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '10')].discount").doesNotExist()
                .jsonPath("$.data[?(@.id == '12')].discount").doesNotExist();
    }

    /**
     * 计算商品优惠价格测试
     * 未满足价格限制（最便宜的5折）
     * @author 吴凯
     */
    @Test
    public void testCacuCouponWhenIsNotSatisfiedWithPriceLimitation2() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 10, \"quantity\": 2},{\"onsaleId\": 12, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 97)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '10')].discount").doesNotExist()
                .jsonPath("$.data[?(@.id == '12')].discount").doesNotExist();
    }

    /**
     * 计算商品优惠价格测试
     * 未满足价格限制（10元）
     * @author 吴凯
     */
    @Test
    public void testCacuCouponWhenIsNotSatisfiedWithPriceLimitation3() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 10, \"quantity\": 2},{\"onsaleId\": 12, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON, 99)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '10')].discount").doesNotExist()
                .jsonPath("$.data[?(@.id == '12')].discount").doesNotExist();
    }

    /**
     * 计算商品优惠价格测试
     * 未满足跨种类限制
     * @author Chihua Ying
     * 修改用例错误
     * @author  Kai Wu
     * 修改测试用例断言路径错误
     * @author  Chihua Ying
     */
    @Test
    public void testCacuCouponWhenIsNotSatisfiedWithCategoryCrossLimitation() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 10, \"quantity\": 10}]";
        this.mallClient.post().uri(CACUCOUPON, 10)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '10')].discount").doesNotExist();
    }

    /**
     * 计算商品优惠价格测试
     * 未满足跨种类限制（10元）
     * @author 吴凯
     */
    @Test
    public void testCacuCouponWhenIsNotSatisfiedWithCategoryCrossLimitation2() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 10, \"quantity\": 10}]";
        this.mallClient.post().uri(CACUCOUPON, 9)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.[?(@.id == '10')].discount").doesNotExist();
    }

    /**
     * 计算商品优惠价格测试
     * 未满足跨种类限制（最便宜的5折）
     * @author 吴凯
     */
    @Test
    public void testCacuCouponWhenIsNotSatisfiedWithCategoryCrossLimitation3() throws Exception {
        String token = this.customerLogin("699275", "123456");
        String body = "[{\"onsaleId\": 10, \"quantity\": 10}]";
        this.mallClient.post().uri(CACUCOUPON, 11)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.[?(@.id == '10')].discount").doesNotExist();
    }


    /**
     * 计算商品优惠价格测试
     * 不存在的活动id
     * 2023-12-22
     * @author 吴凯
     */
    @Test
    public void testCaculateCouponActivityGivenNonExistId() throws Exception{
        String token = this.customerLogin("699275","123456");
        String body = "[{\"onsaleId\": 1, \"quantity\": 1},{\"onsaleId\": 3, \"quantity\": 1},{\"onsaleId\": 4, \"quantity\": 1}]";
        this.mallClient.post().uri(CACUCOUPON,22653L)
                .header("authorization",token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author renyu
     * 测试使用无效商品ID参加活动，顾客用api
     * @throws Exception
     */
    @Test
    public void testActivityGivenInvalidProductId() throws Exception {
        String token = this.customerLogin("customer1", "123456");
        String body = "[{\"onsaleId\": 99999999, \"quantity\": 1},{\"onsaleId\": 8, \"quantity\": 1},{\"onsaleId\": 9, \"quantity\": 2}]";
        
        this.mallClient.post().uri(CACUCOUPON, 101)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
 
    /**
     * @author renyu
     * 测试参加不存在的活动，顾客用api
     * @throws Exception
     */
    @Test
    public void testCouponActivityGivenNonExistent() throws Exception {
        String token = this.customerLogin("customer1", "123456");
        String body = "[{\"onsaleId\": 1, \"quantity\": 1}]";
 
        this.mallClient.post().uri(CACUCOUPON, 9999)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 计算商品优惠价格测试
     * 边界测试：当折扣为PriceCouponDiscount时，商品的discount有潜在的被减到负数的风险，
     * 而事实上，商城里的价格不可能是负的，这里故意给了满足限制，但是价格很低的商品，看看discount是否为0
     * 限制：满3件
     * 优惠：10元
     * @author Chihua Ying
     */
    @Test
    public void testCacuCouponWhenLimitationIsAmountAndCouponIsPriceGivenSpecialSituation() throws Exception {
        String token = this.customerLogin("customer1", "123456");
        String body = "[{\"onsaleId\": 15, \"quantity\": 3}]";
        this.mallClient.post().uri(CACUCOUPON, 7)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.id == '15')].discount").isEqualTo(Collections.singletonList(0));//原价136
    }

    /**
     *商品优惠为非coupon优惠Id,此处为团购活动id
     *@author Shi yuhao
     */
    @Test
    public void testCacuCouponGivenWrongId() throws Exception {

        String token = this.customerLogin("customer1", "123456");
        String body = "[{\"onsaleId\": 10, \"quantity\": 10}]";
        /*团购活动ID*/
        this.gatewayClient.post().uri(CACUCOUPON, 8)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     *活动非本商铺活动，是活动但活动不是本商铺的
     * @author Shi yuhao
     *
     */
    @Test
    public void testCacuCouponGivenWrongShop() throws Exception {
        String token = this.customerLogin("customer1", "123456");
        String body = "[{\"onsaleId\": 10, \"quantity\": 10}]";
        /*实际ID为2*/
        this.gatewayClient.post().uri(CACUCOUPON, 5)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }


    /**
     *complex limitation复合限制
     * @author Shi yuhao
     * 不满足三件限制
     *
     */

    @Test
    public void testCacuCouponGivenComplexNoBeyondThreePieces() throws Exception {
        String token = this.customerLogin("customer1", "123456");
        String body = "[{\"onsaleId\": 10, \"quantity\": 1}]";
        /*三件满100元打9折*/
        /*不满足三件限制*/
        this.gatewayClient.post().uri(CACUCOUPON, 101)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.PAY_CHANNEL_EXIST.getErrNo())
                .jsonPath("$.data[0].discount").doesNotExist();
    }

}
