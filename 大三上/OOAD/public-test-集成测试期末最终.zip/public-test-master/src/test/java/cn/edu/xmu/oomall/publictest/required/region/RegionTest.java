//School of Informatics Xiamen University, GPL-3.0 license

package cn.edu.xmu.oomall.publictest.required.region;

import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.JacksonUtil;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class RegionTest extends BaseTestOomall {

    private final static String STATE = "/region/regions/states";
    private final static String SUBREGION = "/region/shops/{did}/regions/{id}/subregions";
    private final static String CUSTOMERSUBREGION = "/region/regions/{id}/subregions";
    private final static String SHOPREGIONID = "/region/shops/{did}/regions/{id}";
    private final static String REGIONID = "/region/regions/{id}";
    private final static String SUSPENDREGION = "/region/shops/{did}/regions/{id}/suspend";
    private final static String RESUMEREGION = "/region/shops/{did}/regions/{id}/resume";
    private final static String PARENTREGION = "region/internal/regions/{id}/parents";

    private final static String REGIONNAME ="/region/regions";
    private static Long regionId = null;

    /**
     * @author huangzian
     * @throws Exception
     */
    @Test
    public void getStates() throws Exception {
        this.mallClient.get().uri(STATE)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.length()").isEqualTo(3)
                .jsonPath("$.data[?(@.code == '0')].name").isEqualTo("有效")
                .jsonPath("$.data[?(@.code == '1')].name").isEqualTo("停用")
                .jsonPath("$.data[?(@.code == '2')].name").isEqualTo("废弃");
    }

    /**
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(10)
    public void postSubregion() throws Exception{
        String token = this.adminLogin("admin", "123456");
        String json = "{\"name\": \"test1234\", \"pinyin\": \"test1234\", \"lng\": \"100\", \"lat\": \"1234\",  \"mergerName\": \"test1234\"," +
                "\"areaCode\": \"1111\", \"shortName\": \"test\", \"zipCode\": \"1111\", \"cityCode\": \"1111\"}";
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(SUBREGION, 0, 268)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .jsonPath("$.data.name").isEqualTo("test1234")
                .returnResult().getResponseBody()), "UTF-8");

        this.regionId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

    }

    @Test
    public void postSubregionWithBlankName() throws Exception{
        String token = this.adminLogin("admin", "123456");
        String json = "{\"mergeName\": \"test1234\", " +
                "\"shortName\": \"test\"}";
        this.gatewayClient.post().uri(SUBREGION, 0, 268)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    @Test
    public void postSubregionGivenWrongUser() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"test1234\", \"pinyin\": \"test1234\", \"lng\": \"100\", \"lat\": \"1234\",  \"mergerName\": \"test1234\"," +
                "\"areaCode\": \"1111\", \"shortName\": \"test\", \"zipCode\": \"1111\", \"cityCode\": \"1111\"}";
        this.gatewayClient.post().uri(SUBREGION, 1, 268)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    @Test
    public void postSubregionGivenNonExistId() throws Exception{
        String token = this.adminLogin("admin", "123456");
        String json = "{\"name\": \"test1234\", \"pinyin\": \"test1234\", \"lng\": \"100\", \"lat\": \"1234\",  \"mergerName\": \"test1234\"," +
                "\"areaCode\": \"1111\", \"shortName\": \"test\", \"zipCode\": \"1111\", \"cityCode\": \"1111\"}";
        this.gatewayClient.post().uri(SUBREGION, 0, 1234268)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    @Test
    @Order(12)
    public void putRegions(){
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin111s", "123456");
        this.mallClient.get().uri(REGIONID,  regionId)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(this.regionId.intValue())
                .jsonPath("$.data.name").isEqualTo("test1234")
                .jsonPath("$.data.pinyin").isEqualTo("test1234")
                .jsonPath("$.data.lng").isEqualTo("100.0")
                .jsonPath("$.data.lat").isEqualTo("1234.0")
                .jsonPath("$.data.mergerName").isEqualTo("test1234")
                .jsonPath("$.data.areaCode").isEqualTo("1111")
                .jsonPath("$.data.cityCode").isEqualTo("1111")
                .jsonPath("$.data.shortName").isEqualTo("test")
                .jsonPath("$.data.zipCode").isEqualTo("1111")
                .jsonPath("$.data.status").isEqualTo(0)
                .jsonPath("$.data.creator.name").isEqualTo("admin");


        String json = "{\"name\": \"test4\", " +
                "\"shortName\": \"test112\"}";
        this.gatewayClient.put().uri(SHOPREGIONID, 0, this.regionId )
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.mallClient.get().uri(REGIONID,  regionId)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(this.regionId.intValue())
                .jsonPath("$.data.name").isEqualTo("test4")
                .jsonPath("$.data.pinyin").isEqualTo("test1234")
                .jsonPath("$.data.lng").isEqualTo("100.0")
                .jsonPath("$.data.lat").isEqualTo("1234.0")
                .jsonPath("$.data.mergerName").isEqualTo("test1234")
                .jsonPath("$.data.areaCode").isEqualTo("1111")
                .jsonPath("$.data.cityCode").isEqualTo("1111")
                .jsonPath("$.data.shortName").isEqualTo("test112")
                .jsonPath("$.data.zipCode").isEqualTo("1111")
                .jsonPath("$.data.status").isEqualTo(0)
                .jsonPath("$.data.creator.name").isEqualTo("admin")
                .jsonPath("$.data.modifier.name").isEqualTo("admin111s");
    }

    @Test
    public void putRegionsGivenWrongUser(){
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"test4\", " +
                "\"shortName\": \"test\"}";
        this.gatewayClient.put().uri(SHOPREGIONID, 1, 268 )
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    @Test
    public void putRegionsGivenNonExistId(){
        String token = this.adminLogin("admin", "123456");
        String json = "{\"name\": \"test4\", " +
                "\"shortName\": \"test\"}";
        this.gatewayClient.put().uri(SHOPREGIONID, 0, 26122823 )
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    @Test
    public void putRegionsGivenNameBlank(){
        String token = this.adminLogin("admin", "123456");
        String json = "{\"name\": \"  \", " +
                "\"shortName\": \"test\"}";
        this.gatewayClient.put().uri(SHOPREGIONID, 0, 268 )
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    @Test
    @Order(20)
    public void getSubregion() throws Exception{
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(SUBREGION+"?page=1&pageSize=30", 0, 268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(23)
                .jsonPath("$.data.list[?(@.name == 'test4')].id").isEqualTo(this.regionId.intValue());
    }

    @Test
    public void getSubregionGivenNonExistId() throws Exception{
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(SUBREGION+"?page=1&pageSize=30", 0, 12345268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    @Test
    public void getSubregionGivenWrongUser() throws Exception{
        assertNotNull(this.regionId);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(SUBREGION+"?page=1&pageSize=30", 1, 268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(25)
    public void suspendRegion() throws Exception{
        assertNotNull(regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(SUSPENDREGION, 0, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        //判断该地区状态
        this.mallClient.get().uri(REGIONID, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(regionId.intValue())
                .jsonPath("$.data.status").isEqualTo(1);

        //判断其上级地区状态不改变
        this.mallClient.get().uri(REGIONID, 203)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(203)
                .jsonPath("$.data.status").isEqualTo(0);

        //判断其下级地区变为停用
        this.mallClient.get().uri(REGIONID, 269)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(269)
                .jsonPath("$.data.status").isEqualTo(1);

        this.mallClient.get().uri(REGIONID, 270)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(270)
                .jsonPath("$.data.status").isEqualTo(1);
    }


    @Test
    public void suspendRegionGivenWrongUser(){
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(SUSPENDREGION, 1, 268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    @Test
    public void suspendRegionGivenNonExistId(){
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(SUSPENDREGION, 0, 22331268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    @Test
    @Order(26)
    public void getCustomerSubregionAfterSuspend() throws Exception{
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(CUSTOMERSUBREGION+"?page=1&pageSize=30",  268)//缺少参数did
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+this.regionId+"')]").doesNotExist();
    }

    /**
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(27)
    public void resumeRegion() throws Exception{
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(RESUMEREGION, 0, this.regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        //判断该地区状态
        this.mallClient.get().uri(REGIONID, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(regionId)
                .jsonPath("$.data.status").isEqualTo(0);

        //判断其上级地区状态不变
        this.mallClient.get().uri(REGIONID, 203)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(203)
                .jsonPath("$.data.status").isEqualTo(0);

        //判断其下级地区状态变为有效
        this.mallClient.get().uri(REGIONID, 269)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(269)
                .jsonPath("$.data.status").isEqualTo(0);

        this.mallClient.get().uri(REGIONID, 270)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(270)
                .jsonPath("$.data.status").isEqualTo(0);
    }


    @Test
    public void resumeRegionGivenWrongUser(){
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(RESUMEREGION, 1, 268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    @Test
    public void resumeRegionGivenNonExistId(){
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(RESUMEREGION, 0, 22331268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 恢复之后再查询某地区
     * @author 吴凯
     */
    @Test
    @Order(28)
    public void getCustomerSubregionAfterResume() throws Exception{
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(CUSTOMERSUBREGION+"?page=1&pageSize=30", 0, 268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+this.regionId+"')]").isEqualTo(this.regionId.intValue());
    }


    @Test
    @Order(30)
    public void getCustomerSubregion() throws Exception{
        assertNotNull(regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(CUSTOMERSUBREGION+"?page=1&pageSize=30", 268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+regionId+"')].id").exists();
    }

    @Test
    public void getCustomerSubregionGivenNonExistId() throws Exception{
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(CUSTOMERSUBREGION+"?page=1&pageSize=30", 12345268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(40)
    public void delRegion() throws Exception{
        assertNotNull(regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.delete().uri(SHOPREGIONID, 0, this.regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        //判断该地区状态
        this.mallClient.get().uri(REGIONID, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(regionId.intValue())
                .jsonPath("$.data.status").isEqualTo(2);

        //判断其上级地区状态不改变
        this.mallClient.get().uri(REGIONID, 203)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(203)
                .jsonPath("$.data.status").isEqualTo(0);

        //判断其下级地区状态变为废弃
        this.mallClient.get().uri(REGIONID, 269)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(269)
                .jsonPath("$.data.status").isEqualTo(2);

        this.mallClient.get().uri(REGIONID, 270)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(270)
                .jsonPath("$.data.status").isEqualTo(2);
    }

    @Test
    @Order(41)
    public void getCustomerSubregionAfterDelete() throws Exception{
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(CUSTOMERSUBREGION+"?page=1&pageSize=30",  268)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+regionId+"')].id").doesNotExist();
    }

    /**
     * 地区删除(废弃态)后不能恢复
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(41)
    public void resumeRegionAfterDelete(){
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(RESUMEREGION, 0, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        this.mallClient.get().uri(REGIONID, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(regionId.intValue())
                .jsonPath("$.data.status").isEqualTo(2);
    }

    /**
     * 地区删除(废弃态)后不能停用
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(41)
    public void suspendRegionAfterDelete(){
        assertNotNull(this.regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(SUSPENDREGION, 0, this.regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        this.mallClient.get().uri(REGIONID, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(regionId.intValue())
                .jsonPath("$.data.status").isEqualTo(2);
    }

    /**
     * 地区删除(废弃态)后不能在创建其子地区
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(41)
    public void postSubRegionAfterDelete() throws Exception{
        assertNotNull(regionId);
        String token = this.adminLogin("admin", "123456");
        String json = "{\"name\": \"test12345\", \"pinyin\": \"test12345\", \"lng\": \"100\", \"lat\": \"12345\",  \"mergerName\": \"test1234\"," +
                "\"areaCode\": \"1111\", \"shortName\": \"test\", \"zipCode\": \"1111\", \"cityCode\": \"1111\"}";
        this.gatewayClient.post().uri(SUBREGION, 0, regionId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        this.mallClient.get().uri(REGIONID, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(regionId.intValue())
                .jsonPath("$.data.status").isEqualTo(2);
    }

    /**
     * 地区删除(废弃态)后不能修改
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(41)
    public void putRegionAfterDelete() throws Exception{
        assertNotNull(regionId);
        String token = this.adminLogin("admin11", "123456");
        String json = "{\"name\": \"test41\", " +
                "\"shortName\": \"test1122\"}";
        this.gatewayClient.put().uri(SHOPREGIONID, 0, regionId )
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        this.mallClient.get().uri(REGIONID, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(regionId.intValue())
                .jsonPath("$.data.status").isEqualTo(2);
    }



     /**
     * @author renyu
     * 测试修改地区信息时提供空的地区名称
     * @throws Exception
     */
    @Test
    public void testPutRegionGivenEmptyName() throws Exception {
        String token = this.adminLogin("admin", "123456");
        String json = "{\"name\": \"\", \"shortName\": \"test\"}";
        this.gatewayClient.put().uri(SHOPREGIONID, 0, regionId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * @author renyu
     * 测试顾客查询子地区时使用已被废弃的地区ID
     * @throws Exception
     */
    @Test
    @Order(41)
    public void testGetSubregionGivenDeletedRegionId() throws Exception {
        assertNotNull(regionId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(CUSTOMERSUBREGION + "?page=1&pageSize=30", regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author renyu
     * 测试删除地区时使用不存在的地区ID
     * @throws Exception
     */
    @Test
    public void testDelRegionGivenNonExistId() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.delete().uri(SHOPREGIONID, 0, 99999999)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author renyu
     * 测试停用地区时使用已经停用的地区ID
     * @throws Exception
     */
    @Test
    @Order(26)
    public void testSuspendRegionGivenAlreadySuspendedId() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(SUSPENDREGION, 0, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }

    /**
     * @author renyu
     * 测试删除地区时使用已经删除的地区ID
     * @throws Exception
     */
    @Test
    @Order(41)
    public void testDelRegionGivenAlreadyDeletedId() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.delete().uri(SHOPREGIONID, 0, regionId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }

    /**
     * @author renyu
     * 测试查询上级地区时使用废弃态地区ID
     * @throws Exception
     */
    @Test
    @Order(41)
    public void testGetRegionParentsGivenAlreadyDeletedId() throws Exception {
        this.mallClient.get().uri(PARENTREGION, regionId)
                .exchange()
                .expectStatus().isBadRequest() 
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author renyu
     * 测试使用不存在的地区ID查询上级地区
     * @throws Exception
     */
    @Test
    public void testGetRegionParentsGivenNonExistentId() throws Exception {
        Long nonExistentRegionId = 99999999L;
        this.mallClient.get().uri(PARENTREGION, nonExistentRegionId)
                .exchange()
                .expectStatus().isNotFound() // 预期返回状态为未找到
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author 张宁坚
     * 测试使用地区名查询地区id
     */
    @Test
    public void testRetriveRegionIdByNameGivenExistedName() throws Exception {
        this.mallClient.get().uri(REGIONNAME+"?name=北京市")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK)
                .jsonPath("$.data.id").isEqualTo(1);
    }

    /**
     * @author 张宁坚
     * 测试使用不存在的地区名获取地区id
     */
    @Test
    public void testRetriveRegionIdByNameGivenNonExistentName() throws Exception {
        this.mallClient.get().uri(REGIONNAME+"?name=福厦")
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author 张宁坚
     * 测试使用空的地区名获取地区id
     */
    @Test
    public void testRetriveRegionIdByNameGivenEmptyName() throws Exception {

        this.mallClient.get().uri(REGIONNAME+"?name=")
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

}
