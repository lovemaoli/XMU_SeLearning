//School of Informatics Xiamen University, GPL-3.0 license

package cn.edu.xmu.oomall.publictest.required.product;

import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.JacksonUtil;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ProductTest extends BaseTestOomall {

    private static final String MODELID = "/shop/shops/{shopId}/templates/{id}";

    private static final String PRODUCTROOT = "/product/products";

    private static final String SUBCATPRODUCTS = "/product/subcategories/{id}/products";
    private static final String LOGISTICS = "/product/shops/{shopId}/shoplogistics/{id}/product";
    private static final String COMMISSIONRATIO = "/product/shops/{shopId}/products/{id}/commissionratio";
    private static final String STATEURL ="/product/products/states";
    private static final String PRODUCTID ="/product/products/{id}";
    private static final String APPLY ="/product/shops/{shopId}/products/{id}/apply";
    private static final String DRAFT = "/product/shops/{shopId}/draftproducts";
    private static final String DRAFTID = "/product/shops/{shopId}/draftproducts/{id}";
    private static final String PUBLISH = "/product/shops/{shopId}/draftproducts/{id}/publish";
    private static final String PROHIBIT = "/product/shops/{shopId}/products/{id}/prohibit";
    private static final String ALLOW = "/product/shops/{shopId}/products/{id}/allow";

    private static final String TEMPLATEPRODUCT="/product/shops/{shopId}/templates/{id}/products";
    private static final String SHOPPRODUCTID = "/product/shops/{shopId}/products/{id}";
    private static final String OTHERPRODUCT = "/product/shops/{shopId}/products/{id}/relations";

    private static final String ONSALE = "/product/shops/{shopId}/products/{id}/onsales";
    private static final String ONSALEID = "/product/shops/{shopId}/onsales/{id}";
    private static final String ONSALEIDCANCEL = "/product/shops/{shopId}/onsales/{id}/cancel";
    private static final String ONSALEPROD = "/product/onsales/{id}";
    private static final String VALIDONSALE = "/product/shops/{shopId}/onsales/{id}/valid";
    private static final String CANCELONSALE = "/product/shops/{shopId}/onsales/{id}/cancel";

    private static final String COUPON = "/product/couponactivities";
    private static final String COUPONACTID = "/product/couponactivities/{id}";
    private static final String COUPONACTPRODUCT = "/product/couponactivities/{id}/products";
    private static final String SHOPCOUPON = "/product/shops/{shopId}/couponactivities";
    private static final String SHOPCOUPONID = "/product/shops/{shopId}/couponactivities/{id}";
    private static final String SHOPCOUPONIDPUBLISH = "/product/shops/{shopId}/couponactivities/{id}/publish";
    private static final String SHOPCOUPONACTONSALE = "/product/shops/{shopId}/couponactivities/{id}/onsales/{sid}";

    private static final String GROUPON = "/product/groupons";
    private static final String GROUPONID = "/product/groupons/{id}";
    private static final String GROUPONPRODUCT = "/product/groupons/{id}/products";
    private static final String SHOPALLGROUPON = "/product/shops/{shopId}/groupons";
    private static final String SHOPGROUPON = "/product/shops/{shopId}/products/{pid}/groupons";
    private static final String SHOPGROUPONID = "/product/shops/{shopId}/groupons/{id}";
    private static final String SHOPGROUPONPUBLISH = "/product/shops/{shopId}/groupons/{id}/publish";
    private static final String ADDPRODUCTTOGROUPON = "/product/shops/{shopId}/products/{pid}/groupons/{id}";
    private static final String CATEGORY = "/product/shops/{shopId}/categories/{id}";
    private static final String GETCATEGORY = "/product/categories/{id}/subcategories";
    private static final String SUBCATEGORY = "/product/shops/{shopId}/categories/{id}/subcategories";


    private static Integer advId1 = null;
    private static Integer advId2 = null;

    private static Long categoryId1 = null;
    private static Long categoryId2 = null;


    private static Integer grouponId1 = null;

    private static Long draftProdId1 = null;
    private static Long draftProdId2 = null;
    private static Long draftProdId3 = null;
    private static Long productId = null;
    private static Long productId2 = null;
    private static Long onsaleId1 = null;
    private static Long onsaleId2 = null;
    private static Long onsaleId3 = null;

    private static Long couponActId1 = null;
    private static Long couponActId2 = null;



    /**
     * 修改店铺对应的商品
     * @modify Hui Zou
     */
    @Test
    @Order(1)
    public void getProductBeforeDelTemplate14() throws Exception{
        String token = this.adminLogin("shop3", "123456");
        this.gatewayClient.get().uri(SHOPPRODUCTID, 3, 1551)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1551)
                .jsonPath("$.data.template.id").isEqualTo(14)
                .jsonPath("$.data.template.default").isEqualTo(0);

        this.gatewayClient.get().uri(SHOPPRODUCTID, 3, 1569)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1569)
                .jsonPath("$.data.template.id").isEqualTo(14)
                .jsonPath("$.data.template.default").isEqualTo(0);

        this.gatewayClient.get().uri(SHOPPRODUCTID, 3, 1570)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1570)
                .jsonPath("$.data.template.id").isEqualTo(14)
                .jsonPath("$.data.template.default").isEqualTo(0);
    }

    @Test
    @Order(2)
    public void delTemplate() throws Exception{
        String token = this.adminLogin("shop3", "123456");
        this.gatewayClient.get().uri(MODELID, 3, 14)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(14);

        //莆田
        this.gatewayClient.delete().uri(MODELID, 3, 14)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(MODELID, 3, 14)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 获得product的所有状态
     * @throws Exception
     * 修改状态的对应码
     * @modify Hui Zou
     */
    @Test
    public void getProductState() throws Exception {
        this.mallClient.get().uri(STATEURL)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.length()").isEqualTo(3)
                .jsonPath("$.data[?(@.code == '0')].name").isEqualTo("禁售")
                .jsonPath("$.data[?(@.code == '1')].name").isEqualTo("上架")
                .jsonPath("$.data[?(@.code == '2')].name").isEqualTo("下架");
    }


    /**
     * 新增商铺1商品
     *
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(10)
    public void postDraftProductShop1() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"湘妹子剁辣椒\"," +

                "\"originalPrice\": 100000," +
                "\"unit\": \"test\"," +
                "\"categoryId\": 257," +
                "\"barCode\": \"6924254673123\"," +
                "  \"originPlace\": \"长沙\"}";
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(DRAFT, 1)
                .contentType(MediaType.APPLICATION_JSON)
                .header("authorization", token)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()),"UTF-8");

        this.draftProdId1 = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(DRAFT+"?page=1&pageSize=50", 1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].name").isEqualTo("湘妹子剁辣椒")


                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].originalPrice").isEqualTo(100000)
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].unit").isEqualTo("test")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].creator.name").isEqualTo("shop1");

    }

    /**
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    public void postDraftProductGivenFirstCategory() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"湘妹子剁辣椒\"," +

                "\"originalPrice\": 100000," +
                "\"unit\": \"test\"," +
                "\"categoryId\": 1," +
                "  \"originPlace\": \"长沙\"}";
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(DRAFT, 1)
                .contentType(MediaType.APPLICATION_JSON)
                .header("authorization", token)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CATEGORY_NOTALLOW.getErrNo())
                .returnResult().getResponseBody()),"UTF-8");
    }

    /**
     * 不存在的
     * @throws Exception
     */
    @Test
    @Order(20)
    public void getProductDetailGivenDraftId() throws Exception {
        assertNotNull(this.draftProdId1);
        this.mallClient.get().uri(PRODUCTID, this.draftProdId1)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }


    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void putDraftProductTestGivenNonExistId() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"2222222\"}";
        this.gatewayClient.put().uri(DRAFTID, 1, 78552246)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }


    /**
     * 修改商铺1商品
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(20)
    public void putDraftProductShop1() throws Exception{
        assertNotNull(this.draftProdId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"categoryId\": 247, \"originalPrice\": 1000}";
        this.gatewayClient.put().uri(DRAFTID, 1, this.draftProdId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(DRAFT+"?page=1&pageSize=50", 1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].name").isEqualTo("湘妹子剁辣椒")


                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].originPlace").isEqualTo("长沙")

                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].creator.name").isEqualTo("shop1")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].modifier.name").isEqualTo("shop1");
    }

    /**
     * 新增商铺2商品
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(20)
    public void postDraftProductTestShop2() throws Exception{
        assertNotNull(draftProdId1);
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"name\": \"樱桃键盘\"," +
                "\"originalPrice\": 34200," +
                "\"categoryId\": 218," +
                "  \"originPlace\": \"东莞\"}";
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(DRAFT, 2)
                .contentType(MediaType.APPLICATION_JSON)
                .header("authorization", token)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()),"UTF-8");

        this.draftProdId2 = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(DRAFT+"?page=1&pageSize=50", 2)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')].name").isEqualTo("樱桃键盘")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')].originalPrice").isEqualTo(34200)
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')].originPlace").isEqualTo("东莞")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')].creator.name").isEqualTo("shop2")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')]").doesNotExist();
    }

    /**
     * 管理员查询商品
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(30)
    public void getDraftProduct() throws Exception{
        assertNotNull(draftProdId1);
        assertNotNull(draftProdId2);
        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(DRAFT+"?page=1&pageSize=50", 0)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')].name").isEqualTo("樱桃键盘")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')].originalPrice").isEqualTo(34200)
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')].originPlace").isEqualTo("东莞")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')].creator.name").isEqualTo("shop2")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].creator.name").isEqualTo("shop1");

    }

    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void delDraftProductTestGivenNonExistId() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(DRAFTID, 1, 5987456)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 删除商铺2商品
     * @throws Exception
     */
    @Test
    @Order(40)
    public void delDraftProduct() throws Exception{
        assertNotNull(draftProdId2);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.delete().uri(DRAFTID, 2, this.draftProdId2)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(DRAFT+"?page=1&pageSize=50", 2)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')]").doesNotExist();
    }

    /**
     * id不存在
     * @throws Exception
     * @reason 缺少了commissionRatio的参数 jyx
     */
    //@Test
    @Order(50)
    public void publishProductGivenNonExistId() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(PUBLISH, 0, 598656)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 店铺1管理员发布
     * @author Zeyu Zuo
     * @reason 缺少了commissionRatio的参数 jyx
     * @throws Exception
     */
    //@Test
    @Order(50)
    public void publishProductGivenWrongUser() throws Exception{
        assertNotNull(this.draftProdId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(PUBLISH, 1, this.draftProdId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

        this.gatewayClient.get().uri(DRAFT+"?page=1&pageSize=50", 0)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+draftProdId2+"')]").doesNotExist()
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')].creator.name").isEqualTo("shop1");
    }

    /**
     * @modify Rui Li
     * 平台管理员发布
     * @throws Exception
     *
     */
    @Test
    @Order(60)
    public void publishProduct() throws Exception{
        assertNotNull(this.draftProdId1);
        String body = "{\"commissionRatio\":1}";
        String token = this.adminLogin("13088admin", "123456");
        String ret = new String(Objects.requireNonNull(this.gatewayClient.put().uri(PUBLISH, 0, this.draftProdId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo()).returnResult().getResponseBody()), "UTF-8");

        productId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(DRAFT+"?page=1&pageSize=50", 1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+draftProdId1+"')]").doesNotExist();
    }

    /**
     * 查询正在销售的商品
     * 无输入
     * @author Hui Zou
     * @throws Exception
     * @resason 缺少输入参数的名称 jyx
     */
    //@Test
    @Order(65)
    public void testGetSkuListGivenNormalArgNull() throws Exception {
        this.gatewayClient.get().uri(PRODUCTROOT+"?page=1&pageSize=50")
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.type").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].category.name").isEqualTo("有机食品")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].creator.name").isEqualTo("shop1");
    }

    /**
     * 查询正在销售的商品
     * 仅输入条码号
     * @author Hui Zou
     * @throws Exception
     * @缺少了 shopId等参数 jyx
     */
    //@Test
    @Order(65)
    public void testGetSkuListGivenNormalGetBarCode() throws Exception {
        this.gatewayClient.get().uri(PRODUCTROOT+"?barCode=\"6924254673123\"&page=1&pageSize=50")
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.type").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].category.name").isEqualTo("有机食品")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].creator.name").isEqualTo("shop1");
    }

    /**
     * 查询正在销售的商品
     * 仅输入商铺id
     * @author Hui Zou
     * @throws Exception
     */
    @Test
    @Order(65)
    public void testGetSkuListGivenNormalGetShopId() throws Exception {
        this.gatewayClient.get().uri(PRODUCTROOT+"?shopId=1&page=1&pageSize=50")
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.type").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].category.name").isEqualTo("有机食品")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].creator.name").isEqualTo("shop1");
    }

    /**
     * 查询正在销售的商品
     * 仅输入商品名称
     * @author Hui Zou
     * @throws Exception
     * @reason 缺少输入参数的名称 jyx
     */
    //@Test
    @Order(65)
    public void testGetSkuListGivenNormalGetProductName() throws Exception {
        this.gatewayClient.get().uri(PRODUCTROOT+"?name=\"辣椒\"&page=1&pageSize=50")
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.type").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].category.name").isEqualTo("有机食品")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].creator.name").isEqualTo("shop1");

    }

    /**
     * 查询正在销售的商品
     * 完整输入参数
     * @author Hui Zou
     * @throws Exception
     * @reason No matching value at JSON path "$data.list[?(@.id == 'null')].name jyx
     */
    //@Test
    @Order(65)
    public void testGetSkuListGivenNormalArgFull() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(PRODUCTROOT+"?shopId=1&barCode=\"6924254673123\"&name=\"辣椒\"&page=1&pageSize=50")
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.type").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].category.name").isEqualTo("有机食品")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].creator.name").isEqualTo("shop1");
    }

    /**
     * 查询正在销售的商品
     * 商铺不存在
     * @author Hui Zou
     * @throws Exception
     * @reason 由于数据data为空，故data.length（）无效 jyx
     */
    //@Test
    @Order(65)
    public void testGetSkuListGivenShopIdWrong() throws Exception {
        this.gatewayClient.get().uri(PRODUCTROOT+"?shopId=100000000000&barCode=\"6924254673123\"&name=\"辣椒\"&page=1&pageSize=50")
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.length()").isEqualTo(0);
    }

    /**
     * 查询正在销售的商品
     * 商品名称不存在
     * @author Hui Zou
     * @throws Exception
     * @reason 参数名称错误应该是 shopId，而不应该是shopIs jyx
     */
    //@Test
    @Order(65)
    public void testGetSkuListGivenProductNameWrong() throws Exception {
        this.gatewayClient.get().uri(PRODUCTROOT+"?shopIs=1&barCode=\"6924254673123\"&name=\"UFO\"&page=1&pageSize=50")
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.data.length()").isEqualTo(0);;
    }

    /**
     * 查询正在销售的商品
     * 条码号不存在(本店铺不存在该商品)
     * @author Hui Zou
     * @throws Exception
     */
    @Test
    @Order(65)
    public void testGetSkuListGivenBarCodeWrong() throws Exception {
        this.gatewayClient.get().uri(PRODUCTROOT+"?shopIs=1&barCode=\"100000000000000\"&name=\"辣椒\"&page=1&pageSize=50")
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }


    /**
     * 查询分类下的正在销售的商品
     * @author Hui Zou
     * @throws Exception
     * @reason 数据库更新后，247对应的商品与断言不相同 jyx
     */
    //@Test
    @Order(66)
    public void testGetProductInCategoryGivenNormal() throws Exception {
        assertNotNull(productId);
        this.gatewayClient.get().uri(SUBCATPRODUCTS+"?page=1&pageSize=10", 247)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].category.name").isEqualTo("有机食品")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].creator.name").isEqualTo("shop1");
    }

    /**
     * 查询分类下的正在销售的商品
     * 不存在该分类
     * @author Hui Zou
     * @throws Exception
     * @ 对于不存在的商品分类，应该返回一个空列表而不是返回对象不存在 jyx
     */
    //@Test
    @Order(66)
    public void testGetProductInCategoryGivenSubCategoryNull() throws Exception {
        this.gatewayClient.get().uri(SUBCATPRODUCTS+"?page=1&pageSize=10", -100)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 店家获得使用特殊物流的货品
     * 是本店铺且存在该物流
     * @author Hui Zou
     * @throws Exception
     * @reason 数据库当中所有的商品shop_logistic_id==null jyx
     */
    //@Test
    @Order(67)
    public void testGetProductInLogisticsGivenNormal() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(LOGISTICS+"?page=1&pageSize=10",1, 1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originalPrice").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].originPlace").isEqualTo("长沙")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].category.name").isEqualTo("有机食品")
                .jsonPath("$.data.list[?(@.id == '"+productId+"')].creator.name").isEqualTo("shop1");
    }

    /**
     * 店家获得使用特殊物流的货品
     * 是当前店铺的
     * 不存在该物流
     * @author Hui Zou
     * @throws Exception
     */
    @Test
    @Order(67)
    public void testGetProductInLogisticsGivenLogisticWrong() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(LOGISTICS+"?page=1&pageSize=10",1, -1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound();
    }

    /**
     * 店家获得使用特殊物流的货品
     * 不是当前店铺的
     * 存在该物流
     * @author Hui Zou
     * @throws Exception
     */
    @Test
    @Order(67)
    public void testGetProductInLogisticsGivenShopWrong() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(LOGISTICS+"?page=1&pageSize=10",10, 1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 店家获得使用特殊物流的货品
     * 不存在该物流
     * 不是当前店铺的
     * @author Hui Zou
     * @throws Exception
     */
    @Test
    @Order(67)
    public void testGetProductInLogisticsGivenShopAndLogisticWrong() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(LOGISTICS+"?page=1&pageSize=10",10, -1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 平台管理员修改货品分账比例
     * 是平台管理员
     * 存在商品
     * @author Hui Zou
     * @throws Exception
     */
    @Test
    @Order(68)
    public void testPutProductRatioGivenNormal() throws Exception {
        assertNotNull(productId);
        String token = this.adminLogin("admin", "123456");
        String json = "{\"commissionRatio\": 50}";
        this.gatewayClient.put().uri(COMMISSIONRATIO,0, 1550)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * 平台管理员修改货品分账比例
     * 是平台管理员
     * 不存在商品
     * @author Hui Zou
     * @throws Exception
     */
    @Test
    @Order(68)
    public void testPutProductRatioGivenProductNull() throws Exception {
        String token = this.adminLogin("admin", "123456");
        String json = "{\"commissionRatio\": 50}";
        this.gatewayClient.put().uri(COMMISSIONRATIO+"?page=1&pageSize=10",0L, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());

    }

    /**
     * 平台管理员修改货品分账比例
     * 不是平台管理员
     * 存在该商品
     * @author Hui Zou
     * @throws Exception
     */
    @Test
    @Order(68)
    public void testPutProductRatioGivenUserWrong() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"commissionRatio\": 50}";
        this.gatewayClient.put().uri(COMMISSIONRATIO+"?page=1&pageSize=10",10, 1550)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

    }

    /**
     * 平台管理员修改货品分账比例
     * 不是平台管理员
     * 不存在该商品
     * @author Hui Zou
     * @throws Exception
     */
    @Test
    @Order(68)
    public void testPutProductRatioGivenUserWrongAndProductNull() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"commissionRatio\": 50}";
        this.gatewayClient.put().uri(COMMISSIONRATIO+"?page=1&pageSize=10",10, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 与现有商品建立关系
     * @author Ming Qiu
     * <p>
     * date: 2022-12-29 11:26
     * @throws Exception
     */
    @Test
    @Order(70)
    public void createOtherProduct() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"productId\": 1553}";
        this.gatewayClient.post().uri(OTHERPRODUCT, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo());
    }

    @Test
    @Order(70)
    public void createOtherProductGivenTwoShops() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"productId\": 1558}";
        this.gatewayClient.post().uri(OTHERPRODUCT, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    @Test
    public void createOtherProductGivenNonExistId1() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"productId\": 1558}";
        this.gatewayClient.post().uri(OTHERPRODUCT, 1, 775678)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * @throws Exception
     */
    @Test
    @Order(70)
    public void createOtherProductGivenNonExistId2() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"productId\": 15583345}";
        this.gatewayClient.post().uri(OTHERPRODUCT, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 设置相关字段为空
     * @throws Exception
     */
    @Test
    @Order(70)
    public void createOtherProductGivenBlank() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{}";
        this.gatewayClient.post().uri(OTHERPRODUCT, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
    * 获取商品详细信息(1553)
    * @author Zexu Xiang
    */
    @Test
    @Order(80)
    public void getProductDetailGiven1553() throws Exception {
        assertNotNull(productId);
        this.mallClient.get().uri(PRODUCTID, 1553)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1553)
                .jsonPath("$.data.category.id").isEqualTo(187)
                .jsonPath("$.data.category.name").isEqualTo("女式裤子")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.originalPrice").isEqualTo(3036)
                .jsonPath("$.data.originPlace").isEqualTo("广东")
                .jsonPath("$.data.price").isEqualTo(1027)
                .jsonPath("$.data.quantity").isEqualTo(32)
                .jsonPath("$.data.maxQuantity").isEqualTo(50)
                .jsonPath("$.data.status").isEqualTo(2)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].status").isEqualTo(1);
    }


    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void postOnsaleGivenNonExistId() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 1100," +
                "\"beginTime\": \"2022-12-18T20:38:20\"," +
                "\"endTime\": \"2025-12-18T20:38:20\","+
                "  \"quantity\": 10000," +
                "  \"type\": 0," +
                "  \"maxQuantity\":10}";
        this.gatewayClient.post().uri(ONSALE, 1, 1223345)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 上架销售字段为空
     * @throws Exception
     */
    @Test
    public void postOnsaleGivenBlank() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{}";
        this.gatewayClient.post().uri(ONSALE, 1, 1223345)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(90)
    public void postOnsaleGivenWrongUser() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"price\": 5000," +
                "\"beginTime\": \"2022-12-18T20:38:20\"," +
                "\"endTime\": \"2022-12-18T20:38:20\","+
                "  \"quantity\": 10000," +
                "  \"type\": 0," +
                "  \"maxQuantity\":2}";
        this.gatewayClient.post().uri(ONSALE, 2, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }
    /**
     * 开始时间早于结束时间
     * @throws Exception
     */
    @Test
    @Order(90)
    public void postOnsaleGivenEarlyEndTime() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 500," +
                "\"beginTime\": \"2022-12-12T20:38:20\"," +
                "\"endTime\": \"2021-12-19T20:38:20\","+
                "  \"quantity\": 100," +
                "  \"type\": 0," +
                "  \"maxQuantity\":2}";
        this.gatewayClient.post().uri(ONSALE, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.LATE_BEGINTIME.getErrNo());
    }

    /**
     * 支付时间早于开始时间
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(90)
    public void postOnsalePayBeforeBegin() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 500," +
                "\"beginTime\": \"2021-12-12T20:38:20\"," +
                "\"endTime\": \"2022-12-19T20:38:20\","+
                "\"payTime\": \"2020-12-19T20:38:20\","+
                "  \"quantity\": 100," +
                "  \"type\": 0," +
                "  \"maxQuantity\":2}";
        this.gatewayClient.post().uri(ONSALE, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.ADV_SALE_TIMEEARLY.getErrNo());
    }

    /**
     * 支付时间晚于结束时间
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(90)
    public void postOnsalePayAfterEnd() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 500," +
                "\"beginTime\": \"2021-12-12T20:38:20\"," +
                "\"endTime\": \"2022-12-19T20:38:20\","+
                "\"payTime\": \"2023-12-19T20:38:20\","+
                "  \"quantity\": 100," +
                "  \"type\": 0," +
                "  \"maxQuantity\":2}";
        this.gatewayClient.post().uri(ONSALE, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.ADV_SALE_TIMELATE.getErrNo());
    }

    /**
     * 尾款时间早于开始时间
     * @author Rui Li
     */
    @Test
    @Order(90)
    public void postOnsaleGivenEarlyPayTime() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 500," +
                "  \"beginTime\": \"2023-12-01T08:00:00\",\n" +
                "  \"endTime\": \"2023-12-15T18:00:00\",\n" +
                "  \"quantity\": 100," +
                "  \"payTime\": \"2022-12-05T12:30:00\",\n" +
                "  \"type\": 0," +
                "  \"maxQuantity\":2}";
        this.gatewayClient.post().uri(ONSALE, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.ADV_SALE_TIMEEARLY.getErrNo());
    }
    /**
     * 尾款时间晚于结束时间
     * @author Rui Li
     */
    @Test
    @Order(90)
    public void postOnsaleGivenLatePayTime() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 500," +
                "  \"beginTime\": \"2023-12-01T08:00:00\",\n" +
                "  \"endTime\": \"2023-12-15T18:00:00\",\n" +
                "  \"quantity\": 100," +
                "  \"payTime\": \"2024-12-05T12:30:00\",\n" +
                "  \"type\": 0," +
                "  \"maxQuantity\":2}";
        this.gatewayClient.post().uri(ONSALE, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.ADV_SALE_TIMELATE.getErrNo());
    }
    /**
     * 同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(100)
    public void postOnsale() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 1000," +
                "\"beginTime\": \"2022-12-18T20:38:20\"," +
                "\"endTime\": \"2025-12-18T20:38:20\","+
                "  \"quantity\": 10000," +
                "  \"type\": 0," +
                "  \"maxQuantity\":2}";
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(ONSALE, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");
        onsaleId1 = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);
    }
    /**
     * 同时间
     * @modify Rui Li
     * @throws Exception
     */
    @Test
    @Order(110)
    public void postOnsaleGivenSameTime() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 500," +
                "\"beginTime\": \"2021-12-19T20:38:20\"," +
                "\"endTime\": \"2023-12-12T20:38:20\","+
                "  \"quantity\": 100," +
                "  \"type\": 0," +
                "  \"maxQuantity\":2}";
        this.gatewayClient.post().uri(ONSALE, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.GOODS_ONSALE_CONFLICT.getErrNo());
    }

    /**
     * 时间不冲突
     * @throws Exception
     */
    @Test
    @Order(110)
    public void postSecondOnsale() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 1100," +
                "\"beginTime\": \"2019-12-19T20:38:20\"," +
                "\"endTime\": \"2020-01-12T20:38:20\","+
                "  \"quantity\": 10002," +
                "  \"type\": 0," +
                "  \"maxQuantity\":20}";
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(ONSALE, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .jsonPath("$.data.state").isEqualTo(0)
                .returnResult().getResponseBody()), "UTF-8");
        this.onsaleId2 = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);
    }


    /**
     * @author Zexu Xiang
     * 获取商品信息(1553)在上架之后
     */
    @Test
    @Order(115)
    public void getProductDetailGiven1553AfterAddOnsale() throws Exception {
        assertNotNull(productId);
        this.mallClient.get().uri(PRODUCTID, 1553)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1553)
                .jsonPath("$.data.category.id").isEqualTo(187)
                .jsonPath("$.data.category.name").isEqualTo("女式裤子")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.originalPrice").isEqualTo(3036)
                .jsonPath("$.data.price").isEqualTo(1027)
                .jsonPath("$.data.quantity").isEqualTo(32)
                .jsonPath("$.data.maxQuantity").isEqualTo(50)
                .jsonPath("$.data.status").isEqualTo(2)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].status").isEqualTo(1);
    }
    /**
     *获取商品详细信息
     *@author ZexuXiang
     */
    @Test
    @Order(115)
    public void getProductDetailGivenProductBeforeValid() throws Exception {
        assertNotNull(productId);
        this.mallClient.get().uri(PRODUCTID, productId)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1000)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.status").isEqualTo(1)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);
    }

    /**
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(116)
    public void getOnSaleGivenWrongUser() throws Exception{
        assertNotNull(onsaleId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.get().uri(ONSALEID, 2, this.onsaleId1)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }
    /**
     * 同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(116)
    public void getFirstOnsale() throws Exception{
        assertNotNull(onsaleId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(ONSALEID, 1, this.onsaleId1)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.price").isEqualTo(1000);
    }
    /**
     * 同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(116)
    public void getSecondOnsale() throws Exception{
        assertNotNull(onsaleId2);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(ONSALEID, 1, onsaleId2)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.price").isEqualTo(1100);
    }
    /**
     * @author Rui Li
     * 销售不存在
     */
    @Test
    @Order(116)
    public void getOnsaleWhenNotExist() throws Exception{
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(ONSALEID, 0, 999999)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Zexu Xiang
     * 获取在有效期之前指定的product第一个onsale的顾客信息
     */
    @Test
    @Order(116)
    public void getFirstOnsaleCustomerBeforeValid() throws Exception{
        assertNotNull(onsaleId1);
        assertNotNull(productId);
        this.mallClient.get().uri(ONSALEPROD, onsaleId1)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1000)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.price").isEqualTo(1000)
                .jsonPath("$.data.quantity").isEqualTo(10000)
                .jsonPath("$.data.maxQuantity").isEqualTo(2)
                .jsonPath("$.data.status").isEqualTo(1)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);
    }

    /**
     * @author Zexu Xiang
     * 获取在有效期之前指定的product第二个onsale的顾客信息
     */
    @Test
    @Order(116)
    public void getSecondOnsaleCustomerBeforeValid() throws Exception{
        assertNotNull(onsaleId1);
        assertNotNull(productId);
        this.mallClient.get().uri(ONSALEPROD, onsaleId1)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1000)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.price").isEqualTo(1100)
                .jsonPath("$.data.quantity").isEqualTo(10002)
                .jsonPath("$.data.maxQuantity").isEqualTo(20)
                .jsonPath("$.data.status").isEqualTo(1)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);

    }

    /**
     * @author Rui Li
     * 获取一个商品的所有销售
     */
    @Test
    @Order(128)
    public void testGetAllOnsale() throws Exception {
        String token = this.adminLogin("shop4", "123456");
        this.gatewayClient.get().uri(ONSALE, 4, 1552)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2)
                .jsonPath("$.data.list[?(@.id == '3')].price").isEqualTo(12650)
                .jsonPath("$.data.list[?(@.id == '8569')].price").isEqualTo(2000);
    }

    /**
     * @author Rui Li
     * 商户越权访问
     */
    @Test
    @Order(128)
    public void testGetAllOnsaleGivenWrongToken() throws Exception {
        String token = this.adminLogin("shop8", "123456");
        this.gatewayClient.get().uri(ONSALE, 8, 1552)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    @Test
    @Order(129)
    public void validOnsaleGivenWrongUser() throws Exception{
        assertNotNull(onsaleId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(VALIDONSALE, 2, onsaleId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange().expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    @Test
    @Order(130)
    public void validOnsale() throws Exception{
        assertNotNull(onsaleId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(VALIDONSALE, 1, onsaleId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * 处理人：李睿
     * 原因：该接口不存在
     */
//    @Test
    public void validOnsaleGivenNonExistId() throws Exception{
        assertNotNull(onsaleId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(VALIDONSALE, 1, 1222032)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange().expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
    * @author Zexu Xiang
    * 获取商品信息(商品在有效期后)
    */
    @Test
    @Order(140)
    public void getProductDetailGivenProductAfterValid() throws Exception {
        assertNotNull(productId);
        this.mallClient.get().uri(PRODUCTID, productId)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1000)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.price").isEqualTo(1000)
                .jsonPath("$.data.quantity").isEqualTo(10000)
                .jsonPath("$.data.maxQuantity").isEqualTo(2)
                .jsonPath("$.data.status").isEqualTo(2)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);
    }

    /**
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(150)
    public void getProductDetailGiven1553AfterValid() throws Exception {
        assertNotNull(productId);
        this.mallClient.get().uri(PRODUCTID, 1553)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1553)
                .jsonPath("$.data.category.id").isEqualTo(187)
                .jsonPath("$.data.category.name").isEqualTo("女士裤子")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.originalPrice").isEqualTo(3036)
                .jsonPath("$.data.price").isEqualTo(1027)
                .jsonPath("$.data.quantity").isEqualTo(32)
                .jsonPath("$.data.maxQuantity").isEqualTo(50)
                .jsonPath("$.data.status").isEqualTo(2)
                .jsonPath("$.data.sharable").isEqualTo(0)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(14)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].price").isEqualTo(94)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].quantity").isEqualTo(109)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].price").isEqualTo(1000)
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].quantity").isEqualTo(10000)
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].status").isEqualTo(2);
    }
    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void putProductGivenNonExistId() throws Exception{
        String json = "{\"weight\": 500}";
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(SHOPPRODUCTID, 1, 598633585)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * @author Zeyu Zuo
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(160)
    public void putProductGivenWrongUser() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"weight\": 500}";
        this.gatewayClient.put().uri(SHOPPRODUCTID, 2, this.productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 修改商品重量小于0
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(161)
    public void testPutProductGivenLess0Weight() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"weight\": -2}";
        this.gatewayClient.put().uri(SHOPPRODUCTID, 1, this.productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 修改freeThreshold小于0
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(161)
    public void testPutProductGivenLess0FreeThreshold() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"freeThreshold\": -2}";
        this.gatewayClient.put().uri(SHOPPRODUCTID, 1, this.productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * 同店铺管理员修改商品信息
     * @throws Exception
     * @author Zexu Xiang
     */
    @Test
    @Order(170)
    public void putProduct() throws Exception {
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"weight\": 500, \"barCode\": \"test1\"}";
        this.gatewayClient.put().uri(SHOPPRODUCTID, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.mallClient.get().uri(PRODUCTID, productId)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1000)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.price").isEqualTo(1000)
                .jsonPath("$.data.quantity").isEqualTo(10000)
                .jsonPath("$.data.maxQuantity").isEqualTo(2)
                .jsonPath("$.data.status").isEqualTo(2)
                .jsonPath("$.data.weight").isEqualTo(500)
                .jsonPath("$.data.barCode").isEqualTo("test1")
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);
    }

    /**
     * @author Zeyu Zuo
     * @throws Exception
     */
    @Test
    @Order(180)
    public void putProductWithCheckedProperty() throws Exception {
        assertNotNull(productId);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"originalPrice\": 1500, \"weight\": 700}";
        this.gatewayClient.put().uri(SHOPPRODUCTID, 1, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.mallClient.get().uri(PRODUCTID, productId)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1000)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.price").isEqualTo(1000)
                .jsonPath("$.data.quantity").isEqualTo(10000)
                .jsonPath("$.data.maxQuantity").isEqualTo(2)
                .jsonPath("$.data.status").isEqualTo(2)
                .jsonPath("$.data.sharable").isEqualTo(0)
                .jsonPath("$.data.weight").isEqualTo(700)
                .jsonPath("$.data.barCode").isEqualTo("test1")
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].price").isEqualTo(94)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].quantity").isEqualTo(109)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(1)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].price").isEqualTo(1027)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].quantity").isEqualTo(32)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);

        String ret = new String(Objects.requireNonNull(this.gatewayClient.get().uri(DRAFT + "?page=1&pageSize=50", 1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.product.id == '"+productId+"')].orignalPrice").isEqualTo(1500)
                .returnResult().getResponseBody()),"UTF-8");

        List<String> vos = JacksonUtil.parseSubnodeToObjectList(ret, "/data/list", String.class);
        this.draftProdId3 = vos.stream().filter(o-> productId.equals(JacksonUtil.parseSubnodeToObject(o, "/product/id", Long.class))).map(o-> JacksonUtil.parseObject(o, "id", Long.class)).findAny().orElse(null);
    }
    /**
     * 平台管理员发布
     * @author Zexu Xiang
     * @throws Exception
     */
    @Test
    @Order(190)
    public void publishChangedProduct() throws Exception{
        assertNotNull(draftProdId3);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(PUBLISH, 0, this.draftProdId3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(DRAFTID, 1, this.draftProdId3)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());

        this.mallClient.get().uri(PRODUCTID, productId)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1500)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.price").isEqualTo(1000)
                .jsonPath("$.data.quantity").isEqualTo(10000)
                .jsonPath("$.data.maxQuantity").isEqualTo(2)
                .jsonPath("$.data.status").isEqualTo(2)
                .jsonPath("$.data.weight").isEqualTo(700)
                .jsonPath("$.data.barCode").isEqualTo("test1")
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);

    }

    /**
     * 平台管理员禁售id不存在的商品
     * @author Zexu Xiang
     * @throws Exception
     */
    @Test
    public void prohibitProductGivenNonExistId() throws Exception{
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(PROHIBIT, 0, 325698)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 同店铺管理员禁售
     * @throws Exception
     */
    @Test
    @Order(200)
    public void prohibitProductGivenWrongUser() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(PROHIBIT, 2, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange().expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 平台管理员禁售
     * @author Zexu Xiang
     * @throws Exception
     */
    @Test
    @Order(210)
    public void prohibitProduct() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(PROHIBIT, 0, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.mallClient.get().uri(PRODUCTID, productId)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1500)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.status").isEqualTo(1)
                .jsonPath("$.data.weight").isEqualTo(700)
                .jsonPath("$.data.barCode").isEqualTo("test1")
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);
    }
    /**
    * 获取产品信息(1553)在禁售之后
    * @author Zexu Xiang
    */
    @Test
    @Order(220)
    public void getProductDetailGiven1553AfterProhibitProduct() throws Exception {
        assertNotNull(productId);
        this.mallClient.get().uri(PRODUCTID, 1553)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1553)
                .jsonPath("$.data.category.id").isEqualTo(187)
                .jsonPath("$.data.category.name").isEqualTo("女式裤子")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.originalPrice").isEqualTo(3036)
                .jsonPath("$.data.price").isEqualTo(1027)
                .jsonPath("$.data.quantity").isEqualTo(32)
                .jsonPath("$.data.maxQuantity").isEqualTo(50)
                .jsonPath("$.data.status").isEqualTo(2)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].status").isEqualTo(1);
    }

    /**
     * 平台管理员解禁id不存在的商品
     * @author Zexu Xiang
     * @throws Exception
     */
    @Test
    public void allowProductGivenNonExistId() throws Exception{
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(ALLOW, 0, 325698)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 同店铺管理员解禁
     * @throws Exception
     */
    @Test
    @Order(230)
    public void allowProductGivenWrongUser() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(ALLOW, 2, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 平台管理员解禁
     * @throws Exception
     * @author Zexu Xiang
     */
    @Test
    @Order(240)
    public void allowProductTest5() throws Exception{
        assertNotNull(productId);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(ALLOW, 0, productId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.mallClient.get().uri(PRODUCTID, productId)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1500)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.price").isEqualTo(1000)
                .jsonPath("$.data.quantity").isEqualTo(10000)
                .jsonPath("$.data.maxQuantity").isEqualTo(2)
                .jsonPath("$.data.status").isEqualTo(2)
                .jsonPath("$.data.weight").isEqualTo(700)
                .jsonPath("$.data.barCode").isEqualTo("test1")
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);
    }
    /**
    *获取产品信息(1553)在解禁之后
    * @author Zexu Xiang
    */
    @Test
    @Order(250)
    public void getProductDetailGiven1553AfterAllow() throws Exception {
        assertNotNull(productId);
        this.mallClient.get().uri(PRODUCTID, 1553)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1553)
                .jsonPath("$.data.category.id").isEqualTo(187)
                .jsonPath("$.data.category.name").isEqualTo("女式裤子")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.originalPrice").isEqualTo(3036)
                .jsonPath("$.data.price").isEqualTo(1027)
                .jsonPath("$.data.quantity").isEqualTo(32)
                .jsonPath("$.data.maxQuantity").isEqualTo(50)
                .jsonPath("$.data.status").isEqualTo(2)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].price").isEqualTo(1000)
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].quantity").isEqualTo(10000)
                .jsonPath("$.data.otherProducts[?(@.id == '"+productId+"')].status").isEqualTo(2);
    }

    // 依据api，couponVo无beginTime、endTime，故该测试删除

    /**
     * 商铺创建优惠活动：成功
     * @author fan ninghan
     */
    @Test
    @Order(260)
    public void testPostCouponAct() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"优惠测试1\", \"quantity\": 1000, \"quantityType\": 1, \"validTerm\": 0, \"couponTime\": \"2022-12-10T20:38:20\"," +
                "\"strategy\": {" +
                "\"value\": 90," +
                "\"couponLimitation\": {" +
                "\"value\": 0," +
                "\"className\": \"cn.edu.xmu.oomall.product.model.strategy.impl.ComplexCouponLimitation\"," +
                "\"couponLimitationList\": [{" +
                "\"value\": 3," +
                "\"className\": \"cn.edu.xmu.oomall.product.model.strategy.impl.AmountCouponLimitation\"" +
                "}, {" +
                "\"value\": 10000," +
                "\"className\": \"cn.edu.xmu.oomall.product.model.strategy.impl.PriceCouponLimitation\"" +
                "}]" +
                "}," +
                "\"className\": \"cn.edu.xmu.oomall.product.model.strategy.impl.PercentageCouponDiscount\"" +
                "} }";
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(SHOPCOUPON, 1L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        this.couponActId1 = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(SHOPCOUPONID, 1L, this.couponActId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(this.couponActId1)
                .jsonPath("$.data.name").isEqualTo("优惠测试1")
                .jsonPath("$.data.quantity").isEqualTo(1000)
                .jsonPath("$.data.quantityType").isEqualTo(1)
                .jsonPath("$.data.validTerm").isEqualTo(0)
                .jsonPath("$.data.couponTime").isEqualTo("2022-12-10T20:38:20")
                .jsonPath("$.data.creator.name").isEqualTo("shop1");
    }

    /**
     * 商铺获取所有上线优惠活动列表
     * 该测试的问题在于couponActId1的数据是新增的，尚未被管理员publish，故无法获取新增的数据：doesNotExists
     * 该操作与用户类型无关，无需区分管理员和普通用户
     *
     * @author fan ninghan
     */
    @Test
    @Order(270)
    public void testGetCouponActGivenUnpublished() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.customerLogin("customer1", "123456");
        this.mallClient.get().uri(COUPON+"?page=1&pageSize=30")
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+this.couponActId1 +"')]").doesNotExist();
    }

    /**
     * 获取店铺的优惠活动列表-productId为空-status为空-成功
     * @author Ningjian Zhang
     */
    @Test
    public void testGetCouponactivityByShopIdWithoutStatus(){
        String token=this.adminLogin("shop2","123456");
        this.mallClient.get().uri(SHOPCOUPON,2L)
                .header("authorization",token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(4)
                .jsonPath("$.data.list[?(@.id=='4')].name").isEqualTo("团购活动2");
    }

    /**
     * 获取店铺的优惠活动列表-productId为空-status不为空-成功
     * @author Ningjian Zhang
     */
    @Test
    public void testGetCouponactivityByShopIdWithStatus(){

        String token=this.adminLogin("shop2","123456");
        this.mallClient.get().uri(SHOPCOUPON+"?status=2",2L)
                .header("authorization",token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(4)
                .jsonPath("$.data.list[?(@.id=='4')].name").isEqualTo("团购活动2");
    }

    /**
     * 获取店铺的优惠活动列表-productId不为空-成功
     * @author Ningjian Zhang
     */
    @Test
    public void testGetCouponactivityByShopIdWithProductId(){

        String token=this.adminLogin("shop2","123456");
        this.mallClient.get().uri(SHOPCOUPON+"?productId=1668",2L)
                .header("authorization",token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(4)
                .jsonPath("$.data.list[?(@.id=='4')].name").isEqualTo("团购活动2")
                .jsonPath("$.data.list[?(@.id=='4')].quantity").isEqualTo(34);
    }

    /**
     * 商铺查看优惠活动详情：couponActId不存在
     * @author fan ninghan
     */
    @Test
    public void testGetCouponActGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(SHOPCOUPONID, 1L, 99999L)   // 此处需设置为之前插入数据的shopId
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺查看优惠活动详情：不同店铺管理员
     * @author fan ninghan
     */
    @Test
    @Order(270)
    public void testGetCouponActGivenWrongUser() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.get().uri(SHOPCOUPONID, 2L, this.couponActId1)   // 此处需与之前设置的插入数据的shopId不同
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 商铺修改优惠活动：修改couponActId不存在
     * @author fan ninghan
     */
    @Test
    public void testPutCouponActGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"优惠测试1-修改\"}";
        this.gatewayClient.put().uri(SHOPCOUPONID, 1L, 99999L)   // 此处需设置为之前插入数据的shopId
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());

    }

    /**
     * 商铺修改优惠活动：数量小于0
     * @author Huanjia Zhang
     */
    @Test
    public void testPutCouponActGivenQuantityWrong() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"优惠测试1-修改\", \"quantity\": \"-1\"}";
        this.gatewayClient.put().uri(SHOPCOUPONID, 1L, this.couponActId1)   // 此处需设置为之前插入数据的shopId
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());

    }

    /**
     * 商铺修改优惠活动：错误的数量控制（不是0或1）
     * @author Huanjia Zhang
     */
    @Test
    public void testPutCouponActGivenQuantityTypeWrong() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"优惠测试1-修改\", \"quantityType\": \"2\"}";
        this.gatewayClient.put().uri(SHOPCOUPONID, 1L, this.couponActId1)   // 此处需设置为之前插入数据的shopId
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());

    }

    /**
     * 商铺修改优惠活动：有效时间小于0
     * @author Huanjia Zhang
     */
    @Test
    public void testPutCouponActGivenValidTermWrong() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"优惠测试1-修改\", \"validTerm\": \"-1\"}";
        this.gatewayClient.put().uri(SHOPCOUPONID, 1L, this.couponActId1)   // 此处需设置为之前插入数据的shopId
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());

    }

    /**
     * 商铺修改优惠活动：不同店铺管理员
     * @author fan ninghan
     */
    @Test
    @Order(270)
    public void testPutCouponActGivenWrongUser() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"name\": \"优惠测试1-test\"}";
        this.gatewayClient.put().uri(SHOPCOUPONID, 2L, this.couponActId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    // 依据api，couponVo无beginTime、endTime，即：无法修改时间，故该测试删除

    /**
     * 修改优惠活动
     * @author fan ninghan
     */
    @Test
    @Order(270)
    public void testPutCouponAct() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"优惠测试1-修改\"}";
        this.gatewayClient.put().uri(SHOPCOUPONID, 1L, this.couponActId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        // 检查修改，确认修改成功
        this.gatewayClient.get().uri(SHOPCOUPONID, 1L, this.couponActId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(this.couponActId1)
                .jsonPath("$.data.name").isEqualTo("优惠测试1-修改");
    }

    /**
     * 管理员审核优惠活动：非管理员审核
     * @author fan ninghan
     */
    @Test
    public void testPublishCouponActGivenNonManagerial() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(SHOPCOUPONIDPUBLISH, 1L, this.couponActId1)  // shopId为1L，并非管理员
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().is4xxClientError()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 管理员审核优惠活动
     * @author fan ninghan
     */
    @Test
    public void testPublishCouponAct() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(SHOPCOUPONIDPUBLISH, 0L, this.couponActId1)  // shopId为1L，对应的onsaleId包括4L
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        // 查看所有上线活动列表
        String token2 = this.customerLogin("customer1", "123456");
        this.mallClient.get().uri(COUPON+"?endTime=2032-12-10T20:38:20&page=1&pageSize=30")
                .header("authorization", token2)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+this.couponActId1 +"')]").exists();
    }

    /**
     * 用户获取优惠活动：测试beginTime、endTime
     * @author fan ninghan
     */
    @Test
    public void testGetCouponActGivenEarlyEndTime() throws Exception {
        String token2 = this.customerLogin("customer1", "123456");
        this.mallClient.get().uri(COUPON+"?endTime=2002-12-10T20:38:20&page=1&pageSize=30")
                .header("authorization", token2)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+this.couponActId1 +"')]").doesNotExist();
    }

    /**
     * 将优惠活动加到Onsale上：couponActId不存在
     * @author fan ninghan
     */
    @Test
    public void testAddCouponActToOnsaleGivenWrongId() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.post().uri(SHOPCOUPONACTONSALE, 1L, 99999L, 4L)  // shopId为1L，对应的onsaleId包括4L
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 将优惠活动加到Onsale上：不同店铺管理员（shop与activity不匹配）
     * @author fan ninghan
     */
    @Test
    @Order(290)
    public void testAddCouponActToOnsaleGivenWrongUser() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.post().uri(SHOPCOUPONACTONSALE, 2L, this.couponActId1, 37L)    // shopId为2L，对应的onsaleId包括37L
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }


    /**
     * 将优惠活动加到Onsale上：productId = 1533L
     * @author fan ninghan
     */
    @Test
    @Order(300)
    public void testAddCouponActToOnsale() throws Exception {
        assertNotNull(couponActId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.post().uri(SHOPCOUPONACTONSALE, 1L, this.couponActId1, 4L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * 将优惠活动加到Onsale上：onsaleId为之前插入的
     * @author fan ninghan
     */
    @Test
    @Order(300)
    public void testAddCouponActToOnsaleGivenEarlyGeneratedId() throws Exception {
        assertNotNull(this.couponActId1);
        assertNotNull(this.onsaleId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.post().uri(SHOPCOUPONACTONSALE, 1L, this.couponActId1, this.onsaleId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * 将优惠活动加到Onsale上：给错误的OnsaleId
     * 由于OnsaleId错误、OnsaleId与shop不匹配错误类型相同，仅对其错误情况进行测试
     * @author fan ninghan
     */
    @Test
    @Order(300)
    public void testAddCouponActToOnsaleGivenWrongOnsale() throws Exception {
        assertNotNull(this.couponActId1);
        assertNotNull(this.onsaleId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.post().uri(SHOPCOUPONACTONSALE, 1L, this.couponActId1, 999L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 将优惠活动从Onsale上删除：非本店铺管理员
     * @author fan ninghan
     */
    @Test
    @Order(300)
    public void testDeleteCouponActOnsaleGivenUnauthorizedAdmin() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.delete().uri(SHOPCOUPONACTONSALE, 2L, this.couponActId1, 4L)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 将优惠活动从Onsale上删除：
     * @author fan ninghan
     */
    @Test
    @Order(300)
    public void testDeleteCouponActOnsale() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOPCOUPONACTONSALE, 1L, this.couponActId1, 4L)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @throws Exception
     * 获取产品信息在加入优惠之后
     * author Zexu Xiang
     */
    @Test
    @Order(310)
    public void getProductAfterAddCoupon() throws Exception {
        assertNotNull(couponActId1);
        this.mallClient.get().uri(PRODUCTID, productId)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1500)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.price").isEqualTo(1000)
                .jsonPath("$.data.quantity").isEqualTo(10000)
                .jsonPath("$.data.maxQuantity").isEqualTo(2)
                .jsonPath("$.data.status").isEqualTo(2)
                .jsonPath("$.data.weight").isEqualTo(700)
                .jsonPath("$.data.barCode").isEqualTo("test1")
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2)
                .jsonPath("$.data.actList[?(@.id == '"+couponActId1+"')].name").isEqualTo("优惠测试11");
    }




    @Test
    @Order(320)
    public void getCustomerCouponAct2() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.customerLogin("customer1", "123456");
        this.mallClient.get().uri(COUPON+"?page=1&pageSize=30")
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+this.couponActId1 +"')]").exists();
    }

    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void delCouponActGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOPCOUPONID, 1,12435005)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(330)
    public void delCouponActGivenWrongUser() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.delete().uri(SHOPCOUPONID,2, this.couponActId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 取消预售活动
     * @throws Exception
     */
    @Test
    @Order(340)
    public void delCouponAct() throws Exception {
        assertNotNull(this.couponActId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOPCOUPONID,1, this.couponActId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(SHOPCOUPONID, 1, this.couponActId2)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 处理人：李睿
     * 原因： token错误
     * id不存在
     * @throws Exception
     */
    @Test
    public void delOnSaleTestGivenNonExistId() throws Exception{
        String token = this.adminLogin("8131600001", "123456");
        this.gatewayClient.delete().uri(ONSALEID, 1, 324235)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 同店铺管理员
     * @throws Exception
     * @author Zexu Xiang
     */
    @Test
    @Order(350)
    public void delOnSaleTest() throws Exception{
        assertNotNull(onsaleId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(ONSALEID, 1, onsaleId1)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.mallClient.get().uri(ONSALEPROD, onsaleId1)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(productId)
                .jsonPath("$.data.category.id").isEqualTo(247)
                .jsonPath("$.data.category.name").isEqualTo("有机食品")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("湘妹子剁辣椒")
                .jsonPath("$.data.originalPrice").isEqualTo(1000)
                .jsonPath("$.data.originPlace").isEqualTo("长沙")
                .jsonPath("$.data.price").isEqualTo(1100)
                .jsonPath("$.data.quantity").isEqualTo(10002)
                .jsonPath("$.data.maxQuantity").isEqualTo(20)
                .jsonPath("$.data.status").isEqualTo(1)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("$.data.otherProducts.length()").isEqualTo(15)
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].name").isEqualTo("尖叫纤维运动饮料")
                .jsonPath("$.data.otherProducts[?(@.id == '2014')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].name").isEqualTo("松花鸭皮蛋(六枚)")
                .jsonPath("$.data.otherProducts[?(@.id == '2076')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].name").isEqualTo("海天黄豆酱")
                .jsonPath("$.data.otherProducts[?(@.id == '2213')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].name").isEqualTo("摩天真开心")
                .jsonPath("$.data.otherProducts[?(@.id == '2629')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].name").isEqualTo("肤歌幽兰除菌皂")
                .jsonPath("$.data.otherProducts[?(@.id == '4264')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].name").isEqualTo("安记粉蒸肉50")
                .jsonPath("$.data.otherProducts[?(@.id == '4303')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].name").isEqualTo("富华椰子糖")
                .jsonPath("$.data.otherProducts[?(@.id == '4373')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].name").isEqualTo("神象特一粉25000")
                .jsonPath("$.data.otherProducts[?(@.id == '4463')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].name").isEqualTo("肖家花椒粒")
                .jsonPath("$.data.otherProducts[?(@.id == '4473')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].name").isEqualTo("博益蚊子药")
                .jsonPath("$.data.otherProducts[?(@.id == '1580')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].name").isEqualTo("汇源果汁醋")
                .jsonPath("$.data.otherProducts[?(@.id == '5357')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].name").isEqualTo("伟龙美笛琴音壶")
                .jsonPath("$.data.otherProducts[?(@.id == '4831')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].name").isEqualTo("香格里鸡汁汤")
                .jsonPath("$.data.otherProducts[?(@.id == '5454')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].name").isEqualTo("玉丽粉底液")
                .jsonPath("$.data.otherProducts[?(@.id == '3513')].status").isEqualTo(2)
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].name").isEqualTo("欢乐家岭南杂果罐头")
                .jsonPath("$.data.otherProducts[?(@.id == '1553')].status").isEqualTo(2);
    }

    /**
     * author: Xu Huang
     * describe: 非管理员修改商品类目信息
     */
    @Test
    @Order(30)
    public void putCateoryFailed() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String roleJson = "{\"name\": \"临时测试一级分类\",\"commissionRatio\": 0}";
        this.gatewayClient.put().uri(CATEGORY,0,1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(roleJson)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

    }

    /**
     * author: Xu Huang
     * describe: 管理员修改商品类目信息
     */
    @Test
    @Order(30)
    public void putCateory() throws Exception {
        String token = this.adminLogin("admin", "123456");
        String roleJson = "{\"name\": \"测试一级分类\",\"commissionRatio\": 0}";
        this.gatewayClient.put().uri(CATEGORY,0,1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(roleJson)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

    }

    /**
     * author: Xu Huang
     * describe: 管理员修改商品类目信息 - 不存在该分类
     */
    @Test
    @Order(30)
    public void putCateoryGivenNonExistId() throws Exception {
        String token = this.adminLogin("admin", "123456");
        String roleJson = "{\"name\": \"测试一级分类\",\"commissionRatio\": 0}";
        this.gatewayClient.put().uri(CATEGORY,0,100000)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(roleJson)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());

    }

    /**
     * author: Huanjia Zhang
     * describe: 修改商品类目信息 比率小于0
     */
    @Test
    @Order(30)
    public void putCateoryGivenRatioWrong() throws Exception {
        String token = this.adminLogin("admin", "123456");
        String roleJson = "{\"name\": \"测试一级分类\",\"commissionRatio\": -1}";
        this.gatewayClient.put().uri(CATEGORY,0,100000)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(roleJson)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());

    }

    /**
     * author: Xu Huang
     * describe: 非管理员添加商品类目
     */
    @Test
    @Order(31)
    public void postSubCategoriesFailed() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String roleJson = "{\"name\": \"测试二级分类\",\"commissionRatio\": 0}";
        this.gatewayClient.post().uri(SUBCATEGORY, 0, 1)
                .header("authorization", token)
                .bodyValue(roleJson)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * author: Huanjia Zhang
     * describe: 比率小于0
     */
    @Test
    @Order(31)
    public void postSubCategoriesGivenRatioWrong() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String roleJson = "{\"name\": \"测试二级分类\",\"commissionRatio\": -1}";
        this.gatewayClient.post().uri(SUBCATEGORY, 0, 1)
                .header("authorization", token)
                .bodyValue(roleJson)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * author: Xu Huang
     * describe: 管理员成功添加商品类目
     */
    @Test
    @Order(31)
    public void postSubCategories() throws Exception {
        String token = this.adminLogin("admin", "123456");
        String roleJson = "{\"name\": \"测试二级分类\",\"commissionRatio\": 0}";
        this.gatewayClient.post().uri(SUBCATEGORY, 0, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(roleJson)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo()); // 返回添加成功
    }

    /**
     * 管理员添加商品类目
     * 类目为空
     *
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(31)
    public void postSubCategoriesGivenBlank() throws Exception {
        String token = this.adminLogin("admin", "123456");
        String roleJson = "{}";
        this.gatewayClient.post().uri(SUBCATEGORY, 0, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(roleJson)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * author: Xu Huang
     * describe: 非管理员查询商品分类关系
     * https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/product/adminQuerySubCategory
     */
    @Test
    @Order(32)
    public void getCategorySubsFailed() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(SUBCATEGORY, 0,1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * author: Xu Huang
     * describe: 管理员查询商品分类关系
     * https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/product/adminQuerySubCategory
     */
    @Test
    @Order(32)
    public void getCategorySubs() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(SUBCATEGORY,0, 1) // 修正参数个数传递错误的问题，下方修改同此
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.name == '测试二级分类')].id").exists();
    }

    /**
     * author: Xu Huang
     * describe: 管理员查询商品分类关系 - 不存在该分类
     * https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/product/adminQuerySubCategory
     **/
    @Test
    @Order(32)
    public void getCategorySubsGivenNonExistId() throws Exception {
        String token = this.adminLogin("admin", "123456");
        mallClient.get().uri(SUBCATEGORY,0, 545321)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * author: Xu Huang
     * describe: 管理员查询商品分类关系 - 该分类下无子分类
     * https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/product/adminQuerySubCategory
     **/
    @Test
    @Order(32)
    public void getCategorySubsGivenNoSubs() throws Exception {
        String token = this.adminLogin("admin", "123456");
        mallClient.get().uri(SUBCATEGORY,0, 313)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.data.length()").isEqualTo(0);
    }

    /**
     * author: Xu Huang
     * describe: 无需管理员权限即可查询商品分类关系
     * https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/product/querySubCategory
     */
    @Test
    @Order(32)
    public void getCategorySubsPublic() throws Exception {
        this.gatewayClient.get().uri(GETCATEGORY, 1)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data[?(@.name == '女式裤子')].id").exists(); // 女士裤子为 id 为 1 的女装男装的子类
    }

    /**
     * author: Xu Huang
     * describe: 无需管理员权限即可查询商品分类关系 - 不存在该分类
     * https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/product/querySubCategory
     **/
    @Test
    @Order(32)
    public void getCategorySubsPublicGivenNonExistId() throws Exception {
        mallClient.get().uri(GETCATEGORY,545321)
                .exchange()
                .expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * author: Xu Huang
     * describe: 无需管理员权限即可查询商品分类关系 - 该分类下无子分类
     * https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/product/querySubCategory
     **/
    @Test
    @Order(32)
    public void getCategorySubsPublicGivenNoSubs() throws Exception {
        mallClient.get().uri(GETCATEGORY,313)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.data.length()").isEqualTo(0);
    }

    /**
     * author: Xu Huang
     * describe: 非管理员删除商品类目信息
     */
    @Test
    @Order(33)
    public void deleteCategoryFailed() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(CATEGORY,0,1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * author: Xu Huang
     * describe: 管理员删除商品类目信息
     */
    @Test
    @Order(33)
    public void deleteCategory() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.delete().uri(CATEGORY,0,1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * author: Xu Huang
     * describe: 管理员删除不存在的id的商品类目
     */
    @Test
    @Order(33)
    public void deleteCategoryGivenNonExistId() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.delete().uri(CATEGORY,0,173412)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void getGropuonDetailGivenNonExistId() throws Exception {
        String token = this.customerLogin("customer1", "123456");
        this.mallClient.get().uri(GROUPONID, 10325)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }


    /**
     * 不同店铺管理员
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(410)
    public void postGrouponGivenWrongUser() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":10000,\"quantity\":10000,\"max_quantity\":200," +
                "\"beginTime\":\"2023-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";
        this.gatewayClient.post().uri(SHOPGROUPON, 2,2550)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 创建团购活动（参数缺失）
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(415)
    public void postGrouponWithMissedParams() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{" +
                "\"price\":10000,\"quantity\":10000,\"max_quantity\":200," +
                "\"beginTime\":\"3030-12-05T10:09:50.000\",\"endTime\":\"3032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,4929)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo())
                .returnResult().getResponseBody();
    }

    /**
     * 创建团购活动（商铺和商品不对应）
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(415)
    public void postGrouponWithIllegalProduct() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":10000,\"quantity\":10000,\"max_quantity\":200," +
                "\"beginTime\":\"2023-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,4972)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo())
                .returnResult().getResponseBody();
    }

    /**
     * 创建团购活动（不存在的商品）
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(415)
    public void postGrouponWithNoneProduct() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":10000,\"quantity\":10000,\"max_quantity\":200," +
                "\"beginTime\":\"2023-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,9999)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo())
                .returnResult().getResponseBody();
    }

    /**
     * 创建团购活动（销售冲突）
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(415)
    public void postGrouponWithConflict() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":10000,\"quantity\":10000,\"max_quantity\":200," +
                "\"beginTime\":\"2000-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 2,3291)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.GOODS_ONSALE_CONFLICT.getErrNo())
                .returnResult().getResponseBody();
    }
    /**
     * 创建团购活动（活动开始时间晚于结束时间）
     * @throws Exception
     * @author hyx
     */
    @Test
    public void testPostGrouponGivenEarlyBegin() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":10000,\"quantity\":10000,\"max_quantity\":200," +
                "\"beginTime\":\"2032-12-05T10:09:50.000\",\"endTime\":\"2023-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,4959)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.LATE_BEGINTIME.getErrNo())
                .returnResult().getResponseBody();
    }
    /**
     * 创建团购活动 价格小于0
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(415)
    public void testPostGrouponGivenWrongPrice() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":-1,\"quantity\":100,\"max_quantity\":200," +
                "\"beginTime\":\"2023-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,4959)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo())
                .returnResult().getResponseBody();
    }
    /**
     * 创建团购活动 比例小于0
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(415)
    public void testPostGrouponGivenWrongPercentage() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": -1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":1,\"quantity\":100,\"max_quantity\":200," +
                "\"beginTime\":\"2023-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,4959)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo())
                .returnResult().getResponseBody();
    }
    /**
     * 创建团购活动 比例大于100%
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(415)
    public void testPostGrouponGivenWrongPercentage1() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1000000}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":-1,\"quantity\":100,\"max_quantity\":200," +
                "\"beginTime\":\"2023-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,4959)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo())
                .returnResult().getResponseBody();
    }
    /**
     * 创建团购活动 数量小于0
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(415)
    public void testPostGrouponGivenWrongQuantity() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":10000,\"quantity\":-1,\"max_quantity\":200," +
                "\"beginTime\":\"2023-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,4959)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo())
                .returnResult().getResponseBody();
    }
    /**
     * 创建团购活动 最大数量小于0
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(415)
    public void testPostGrouponGivenWrongMaxQuantity() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":10000,\"quantity\":100,\"max_quantity\":-1," +
                "\"beginTime\":\"2023-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,4959)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo())
                .returnResult().getResponseBody();
    }
    /**
     * 创建团购活动
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(420)
    public void postGroupon() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":10000,\"quantity\":10000,\"max_quantity\":200," +
                "\"beginTime\":\"3030-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        String ret = new String(Objects.requireNonNull( this.gatewayClient.post().uri(SHOPGROUPON, 1,4929)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        this.grouponId1 = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Integer.class);
        this.gatewayClient.get().uri(SHOPGROUPONID, 1, this.grouponId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(this.grouponId1)
                .jsonPath("$.data.name").isEqualTo("团购测试1")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.creator.name").isEqualTo("shop1");
    }

    /**
     * 顾客查询活动
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(440)
    public void getCustomerGroupon() throws Exception {
        // 刚创建的活动是新建态，无法查询
        assertNotNull(this.grouponId1);
        String token = this.customerLogin("customer1", "123456");
        this.mallClient.get().uri(GROUPON)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+this.grouponId1+"')]").doesNotExist();
    }
    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void getGrouponGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(SHOPGROUPONID, 1, 23544558)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 不同店铺管理员
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(450) // 创建之后再测试这个方法
    public void getGrouponGivenWrongUser() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.get().uri(SHOPGROUPONID, 2, grouponId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }
    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void putGrouponGivenNonExistId() throws Exception {
        String token = this.adminLogin("8131600001", "123456");
        String json = "{\"name\": \"团购测试11\"}";
        this.gatewayClient.put().uri(SHOPGROUPONID, 1,12435005)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(450)
    public void putGrouponGivenWrongUser() throws Exception {
        assertNotNull(grouponId1);
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"name\": \"团购测试11\"}";
        this.gatewayClient.put().uri(SHOPGROUPONID,2, grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 修改团购活动
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(460)
    public void putGroupon() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试11\"}";
        this.gatewayClient.put().uri(SHOPGROUPONID,1, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(SHOPGROUPONID, 1, this.grouponId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(this.grouponId1)
                .jsonPath("$.data.name").isEqualTo("团购测试11");
    }

    /**
     * 非平台管理员发布团购活动
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(460)
    public void putPublishGrouponWithShop() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(SHOPGROUPONPUBLISH,1, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 平台管理员发布团购活动
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(465)
    public void putPublishGroupon() throws Exception {
        assertNotNull(this.grouponId1);
        String adminToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(SHOPGROUPONPUBLISH,0, this.grouponId1)
                .header("authorization", adminToken)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        // 已发布的团购活动可以被顾客查询到
        String token = this.customerLogin("customer1", "123456");
        this.mallClient.get().uri(GROUPON)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+this.grouponId1+"')]").exists();
    }

    /**
     * 平台管理员发布已审核的团购活动
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(468)
    public void putPublishGrouponWithWrongStatus() throws Exception {
        assertNotNull(this.grouponId1);
        String adminToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(SHOPGROUPONPUBLISH,0, this.grouponId1)
                .header("authorization", adminToken)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }
    /**
     * 将商品加入到活动中（必要参数缺失）
     * @throws Exception
     * @author hyx
     */
    @Test
    @Order(470)
    public void testPostAddProductToGrouponGivenLackPrice() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\":, \"quantity\": 200, \"maxQuantity\": 2}";
        this.gatewayClient.post().uri(ADDPRODUCTTOGROUPON, 1, 4959, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 将商品加入到活动中（数量小于0）
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(470)
    public void testPostAddProductToGrouponGivenWrongQuantity() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\":100, \"quantity\": -1, \"maxQuantity\": 2}";
        this.gatewayClient.post().uri(ADDPRODUCTTOGROUPON, 1, 4959, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 将商品加入到活动中（最大数量小于0）
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(470)
    public void testPostAddProductToGrouponGivenWrongMaxQuantity() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\":100, \"quantity\": 200, \"maxQuantity\": -1}";
        this.gatewayClient.post().uri(ADDPRODUCTTOGROUPON, 1, 4959, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 将商品加入到活动中（商品id和s商铺id不匹配）
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(470)     // 在审核之后
    public void postAddProductToGrouponWithWrongShop() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"price\":100, \"quantity\": 200, \"maxQuantity\": 2}";
        this.gatewayClient.post().uri(ADDPRODUCTTOGROUPON, 2, 4959, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 将商品加入到活动中（商品id不存在）
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(470)     // 在审核之后
    public void postAddProductToGrouponWithWrongProductId() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\":100, \"quantity\": 200, \"maxQuantity\": 2}";
        this.gatewayClient.post().uri(ADDPRODUCTTOGROUPON, 1, 99999, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 将商品加入到活动中（活动id不存在）W
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(470)     // 在审核之后
    public void postAddProductToGrouponWithWrongActivity() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\":100, \"quantity\": 200, \"maxQuantity\": 2}";
        // 传入不存在的活动id，因此不能使用之前的grouponId1
        this.gatewayClient.post().uri(ADDPRODUCTTOGROUPON, 1, 4959, 9999)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 将商品加入到活动中（销售冲突）
     * @throws Exception
     * @author WuTong
     */
    @Test
    @Order(470)     // 在审核之后
    public void postAddProductToGrouponWithConfilictOnsale() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\":100, \"quantity\": 200, \"maxQuantity\": 2}";
        // 这里没办法使用创建出来的grouponId1，因为数据库销售的时间均为2021-2027
        // 且不能让新创建的销售时间与上述时间重叠，否则无法正常创建（创建时也会进行判重叠）
        this.gatewayClient.post().uri(ADDPRODUCTTOGROUPON, 2, 1668, 4)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.GOODS_ONSALE_CONFLICT.getErrNo());
    }
    /**
     * 修改团购活动 比例小于0
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(460)
    public void testPutGrouponGivenWrongRadio() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试11\"}" +
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": -1}";
        this.gatewayClient.put().uri(SHOPGROUPONID, 1, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * 修改团购活动 比例大于100%
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(460)
    public void testPutGrouponGivenWrongRadio1() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试11\"}" +
                "\"thresholds\": [" +
                "{ \"quantity\": 10, \"percentage\": 100000000}";
        this.gatewayClient.put().uri(SHOPGROUPONID, 1, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * 修改团购活动 数量小于0
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(460)
    public void testPutGrouponGivenWrongQuantity() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试11\"}" +
                "\"thresholds\": [" +
                "{ \"quantity\": -1, \"percentage\": 1}";
        this.gatewayClient.put().uri(SHOPGROUPONID, 1, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * 修改团购活动 开始时间晚于结束时间
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(460)
    public void testPutGrouponGivenBeginTimeLateThanEndTime() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试11\", \"beginTime\":\"2032-12-05T10:09:50.000\", \"endTime\":\"2023-12-05T10:09:50.000\"}";
        this.gatewayClient.put().uri(SHOPGROUPONID, 1, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.LATE_BEGINTIME.getErrNo());
    }


    //上线前商品无有效销售
    @Test
    @Order(470)
    public void getProductDetailGivenGroupon() throws Exception {
        assertNotNull(this.grouponId1);
        this.mallClient.get().uri(PRODUCTID, 1709)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1790)
                .jsonPath("$.data.category.id").isEqualTo(260)
                .jsonPath("$.data.category.name").isEqualTo("女式裤子")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("王守义白胡椒粉25")
                .jsonPath("$.data.originalPrice").isEqualTo(62471)
                .jsonPath("$.data.price").isEqualTo(41686)
                .jsonPath("$.data.quantity").isEqualTo(91)
                .jsonPath("$.data.maxQuantity").isEqualTo(50)
                .jsonPath("$.data.status").isEqualTo(2)
                .jsonPath("$.data.sharable").isEqualTo(0)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("data.actList[?(@.id == '"+grouponId1+"')]").exists();
    }

    /**
     * 创建预售活动
     * @throws Exception
     */
    @Test
    @Order(480)
    public void postGrouponGivenSameOnsale() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试2\","+
                "\"thresholds\": [" +
                "{ \"quantity\": 100, \"percentage\": 1}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}" +
                "]}";
        this.gatewayClient.post().uri(SHOPGROUPON, 1, 160)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.GOODS_ONSALE_CONFLICT.getErrNo());

    }

    /**
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(490)
    public void delGrouponGivenWrongUser() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.delete().uri(SHOPGROUPONID,2, grouponId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 删除团购活动，活动id不存在
     * @throws Exception
     * @author hyx
     */
    @Test
    public void delGrouponGivenIdNoExist() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.delete().uri(SHOPGROUPONID,2, 75654)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 删除预售活动
     * @throws Exception
     */
    @Test
    @Order(500)
    public void delGroupon() throws Exception {
        assertNotNull(grouponId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOPGROUPONID,1, grouponId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.mallClient.get().uri(PRODUCTID, 1709)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1790)
                .jsonPath("$.data.category.id").isEqualTo(260)
                .jsonPath("$.data.category.name").isEqualTo("女式裤子")
                .jsonPath("$.data.shop.id").isEqualTo(1)
                .jsonPath("$.data.shop.name").isEqualTo("OOMALL自营商铺")
                .jsonPath("$.data.name").isEqualTo("王守义白胡椒粉25")
                .jsonPath("$.data.originalPrice").isEqualTo(62471)
                .jsonPath("$.data.price").isEqualTo(41686)
                .jsonPath("$.data.quantity").isEqualTo(91)
                .jsonPath("$.data.maxQuantity").isEqualTo(50)
                .jsonPath("$.data.status").isEqualTo(2)
                .jsonPath("$.data.sharable").isEqualTo(0)
                //商铺默认免邮门槛
                .jsonPath("$.data.freeThreshold").isEqualTo(10000)
                .jsonPath("data.actList[?(@.id == '"+grouponId1+"')]").doesNotExist();
    }

    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void postAdvSaleGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"预售活动1\",\"payTime\": \"2022-01-25T20:38:20\", \"deposite\": 10000 }";
        this.gatewayClient.post().uri(ONSALE, 1, 12435005)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    public void postAdvSaleGivenWrongUser() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"name\": \"预售活动1\",\"payTime\": \"2022-01-25T20:38:20\", \"deposite\": 10000 }";
        this.gatewayClient.post().uri(ONSALE, 2, 163)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }
    /**
     * 创建预售活动
     * @throws Exception
     */
    @Test
    @Order(510)
    public void postAdvSale() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"预售活动1\",\"payTime\": \"2022-01-25T20:38:20\", \"deposite\": 10000 }";
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(ONSALE, 1, 163)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        this.advId1 = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Integer.class);
        this.gatewayClient.get().uri(ONSALEID, 1, this.advId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(this.advId1)
                .jsonPath("$.data.name").isEqualTo("预售活动1");
    }
    @Test
    @Order(520)
    public void getCustomerAdvSale() throws Exception {
        assertNotNull(advId1);
        this.mallClient.get().uri(ONSALE)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+advId1+"')]").exists();
    }
    @Test
    @Order(520)
    public void getShopAdvSale() throws Exception {
        assertNotNull(this.advId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(ONSALE, 1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+advId1+"')]").exists();

    }
    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void getAdvSaleGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(ONSALEID, 1, 23544558)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(520)
    public void getAdvSaleGivenWrongUser() throws Exception {
        assertNotNull(this.advId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.get().uri(ONSALEID, 2, advId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }
    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void putAdvSaleGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"deposit\": 150000}";
        this.gatewayClient.put().uri(ONSALEID, 1,12435005)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(530)
    public void putAdvSale3() throws Exception {
        assertNotNull(this.advId1);
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"deposit\": 150000}";
        this.gatewayClient.put().uri(ONSALEID,2, this.advId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }
    /**
     * 修改预售活动
     * @throws Exception
     */
    @Test
    @Order(530)
    public void putAdvSale7() throws Exception {
        assertNotNull(this.advId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"deposit\": 150000}";
        this.gatewayClient.put().uri(ONSALEID,1, this.advId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(ONSALEID, 1, this.advId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(this.advId1)
                .jsonPath("$.data.name").isEqualTo("预售活动1")
                .jsonPath("$.data.deposit").isEqualTo(150000);
    }
    /**
     * id不存在
     * @throws Exception
     */
    @Test
    public void delAdvSaleGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(ONSALEID, 1,12435005)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 不同店铺管理员
     * @throws Exception
     */
    @Test
    @Order(540)
    public void dellineAdvSaleGivenWrongUser() throws Exception {
        assertNotNull(this.advId1);
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.delete().uri(ONSALEID,2, advId1)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }


    /**
     * 删除预售活动
     * @throws Exception
     */
    @Test
    @Order(550)
    public void dellineAdvSale() throws Exception {
        assertNotNull(advId1);
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(ONSALEID,1, this.advId2)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

    }

    /**
     * @author Rui Li
     * 取消销售活动-进行中
     */
    @Test
    @Order(560)
    public void cancelOnsaleWhenProcessing() throws Exception {
        String token= this.adminLogin("shop4", "123456");
        this.gatewayClient.put().uri(CANCELONSALE,4, 845)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Rui Li
     * 取消销售活动-已结束
     */
    @Test
    @Order(570)
    public void cancelOnsaleWhenFinished() throws Exception {
        String token= this.adminLogin("shop4", "123456");
        this.gatewayClient.put().uri(CANCELONSALE,4, 8569)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Rui Li
     * 取消销售活动-未开始
     */
    @Test
    @Order(580)
    public void cancelOnsaleWhenNotStart() throws Exception {
        String token= this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(CANCELONSALE,2, 344)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Rui Li
     * 取消销售活动-越权访问
     */
    @Test
    @Order(590)
    public void cancelOnsaleGivenWrongToken() throws Exception{

        String token= this.adminLogin("shop8", "123456");
        this.gatewayClient.put().uri(CANCELONSALE,8, 845)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

    }

    /**
     * 取消预售
     * @throws Exception
     * 该商铺不存在该预售商品
     * @author Caozhiyi
     */
    @Order(590)
    @Test
    public void cancelOnsaleIdWithNoExistId() throws Exception {
        String token= this.adminLogin("shop4", "123456");
        this.gatewayClient.put().uri(CANCELONSALE,4,1654645 )
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    @Test
    @Order(1000)
    public void getProductWithDelTemplate14() throws Exception{
        String token = this.adminLogin("shop3", "123456");
        this.gatewayClient.get().uri(SHOPPRODUCTID, 3, 1551)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1551)
                .jsonPath("$.data.template.id").isEqualTo(15)
                .jsonPath("$.data.template.default").isEqualTo(1);

        this.gatewayClient.get().uri(SHOPPRODUCTID, 3, 1569)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1569)
                .jsonPath("$.data.template.id").isEqualTo(15)
                .jsonPath("$.data.template.default").isEqualTo(1);

        this.gatewayClient.get().uri(SHOPPRODUCTID, 3, 1570)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1570)
                .jsonPath("$.data.template.id").isEqualTo(15)
                .jsonPath("$.data.template.default").isEqualTo(1);
    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * 成功创建会影响下文，存下ID，并标序号
     * 403 forbidden()：修改创建人为shop
     */
    @Order(1001)
    @Test
    public void testCreateDraftGivenSuccess() throws Exception {
        String shopToken = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"小猫老弟\",\"originalPrice\": 1000,  \"categoryId\": 313 , \"originPlace\":  \"100\", \"unit\":  \"unit\"}";


        String ret=new String(Objects.requireNonNull(this.gatewayClient.post().uri(DRAFT, 1)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()),"UTF-8");

        this.draftProdId2 = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(DRAFTID, 1, draftProdId2)
                .header("authorization", shopToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(draftProdId2)
                .jsonPath("$.data.name").isEqualTo("小猫老弟")
                .jsonPath("$.data.shop.id").isEqualTo( 1);


    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * 不允许1分类
     * 404 not found
     */
    @Test
    public void testCreateDraftGivenCategoryNOTALLOW() throws Exception {

        String shopToken = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"小猫老弟\",\"originalPrice\": 1000, \"categoryId\": 1 , \"originPlace\":  \"100\", \"unit\":  \"unit\"}";

        this.gatewayClient.post().uri(DRAFT, 1)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CATEGORY_NOTALLOW.getErrNo());
    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * 无分类
     * pass
     */
    @Test
    public void testCreateDraftGivenCategoryIdNull() throws Exception {

        String shopToken = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"小猫老弟\",\"originalPrice\": 1000 , \"originPlace\": \"100\" , \"unit\": \"unit\" }";
        this.mallClient.post().uri(DRAFT, 1)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * 草稿商品测试
     * @author Huanjia Zhang
     * 原价小于0
     * pass
     */
    @Test
    public void testCreateDraftGivenPriceWrong() throws Exception {

        String adminToken = this.adminLogin("13088admin", "123456");
        String json = "{\"name\": \"小猫老弟\",\"originalPrice\": -1 , \"originPlace\": \"100\" , \"unit\": \"unit\" }";
        this.mallClient.post().uri(DRAFT, 1)
                .header("authorization", adminToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * 草稿商品测试
     * @author shiyuhao
     * 管理员得到草稿，上文创建草稿会对他产生影响
     * 长度2?被前面测试影响
     */
    @Order(1002)
    @Test
    public void testGetAllProductDraftGivenAdmin() throws Exception {

        String adminToken =  this.adminLogin("13088admin", "123456");

        this.gatewayClient.get().uri(DRAFT+"?page=1&pageSize=10", 0)
                .header("authorization", adminToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2)
                .jsonPath("$.data.list[0].id").isEqualTo(70);
    }


    /**
     * 草稿商品测试
     * @author shiyuhao
     * 测试商铺的商品
     * pass
     */
    @Test
    public void testGetAllProductDraftGivenShop() throws Exception {

        String shopToken = this.adminLogin("shop10", "123456");

        this.gatewayClient.get().uri(DRAFT+"?page=1&pageSize=10", 10)
                .header("authorization", shopToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(1);
    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * pass
     */
    @Test
    public void testGetDraftDetailGivenSuccess() throws Exception {
        String shopToken = this.adminLogin("shop10", "123456");

        this.gatewayClient.get().uri(DRAFTID, 10,70)
                .header("authorization", shopToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(70)
                .jsonPath("$.data.shop.id").isEqualTo(10)
                .jsonPath("$.data.product.id").isEqualTo(1576);

    }
    /**
     * 草稿商品测试
     * @author shiyuhao
     * pass
     */
    @Test
    public void testGetProductDraftGivenAdmin() throws Exception {
        String adminToken =  this.adminLogin("13088admin", "123456");

        this.gatewayClient.get().uri(DRAFTID, 0,70)
                .header("authorization", adminToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(70)
                .jsonPath("$.data.shop.id").isEqualTo(10)
                .jsonPath("$.data.product.id").isEqualTo(1576);

    }
    /**
     * 草稿商品测试
     * @author shiyuhao
     * 不同商铺无法访问草稿
     * pass
     */
    @Test
    public void testGetProductDraftGivenWrongShop() throws Exception {

        String shopToken = this.adminLogin("shop1", "123456");

        this.gatewayClient.get().uri(DRAFTID, 1,70)
                .header("authorization", shopToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

    }



    /**
     * 草稿商品测试
     * @author shiyuhao
     * pass
     */
    @Test
    public void testModifyDraftGivenSuccess() throws Exception {

        String shopToken = this.adminLogin("shop10", "123456");
        String json = "{\"name\": \"coke\",\"originalPrice\": 1000, \"categoryId\": 313 , \"originPlace\": \"100\" , \"unit\": \"unittest\" }";


        this.gatewayClient.put().uri(DRAFTID, 10,70)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody();

    }


    /**
     * 草稿商品测试
     * @author shiyuhao
     * 分类1无法修改
     * 404 not found
     */
    @Test
    public void testModifyDraftGivenCategoryNotAllow() throws Exception {

        String shopToken = this.adminLogin("shop10", "123456");
        String json = "{\"name\": \"coke\",\"originalPrice\": 1000, \"categoryId\": 1 , \"originPlace\": \"100\" , \"unit\": \"unittest\" }";

        this.gatewayClient.put().uri(DRAFTID, 10,70)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CATEGORY_NOTALLOW.getErrNo());

    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * pass
     */

    @Test
    public void testModifyDraftGivenAdmin() throws Exception {

        String adminToken = this.adminLogin("13088admin", "123456");
        String json = "{\"name\": \"coke\",\"originalPrice\": 1000, \"categoryId\": 313 , \"originPlace\": \"100\" , \"unit\":\"unittest\" }";

        this.gatewayClient.put().uri(DRAFTID, 0,70)
                .header("authorization", adminToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno") .isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * 不匹配商铺无法修改草稿
     * pass
     */

    @Test
    public void testModifyDraftGivenWrongShop() throws Exception {

        String shopToken = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"coke\",\"originalPrice\": 1000, \"categoryId\": 1 , \"originPlace\": \"100\" , \"unit\": \"unittest\" }";

        this.gatewayClient.put().uri(DRAFTID, 1,70)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * 删除草稿，这里删除创建的，也会对得到全部草稿有印象
     * 404 not found，可能是null
     */

    @Order(1004)
    @Test
    public void testDelProductsGivenSuccess() throws Exception {
        assertNotNull(draftProdId2);
        String shopToken = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(DRAFTID,1,draftProdId2)
                .header("authorization", shopToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * 不匹配商铺无法删除
     * pass
     */

    @Test
    public void testDelDraftProductsGivenWrongShop() throws Exception {

        String shopToken = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(DRAFTID,1,70)
                .header("authorization", shopToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * 发布商品失败
     * pass
     */

    @Test
    public void testPublicProductGivenFail() throws Exception {

        String shopToken = this.adminLogin("shop10", "123456");
        String json = "{\"commissionRatio\":1}";
        this.gatewayClient.put().uri(PUBLISH,10,300)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().is4xxClientError()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

    }

    /**
     * 草稿商品测试
     * @author Huanjia Zhang
     * 发布商品 比率小于0
     */

    @Test
    public void testPublicProductGivenRatioWrong() throws Exception {

        String shopToken = this.adminLogin("admin13088", "123456");
        String json = "{\"commissionRatio\":-1}";
        this.gatewayClient.put().uri(PUBLISH,0,70)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());

    }

    /**
     * 草稿商品测试
     * @author shiyuhao
     * 发布草稿商品成功
     * 标上标号，防止对商品部分造成干扰
     * 只能管理员修改
     */

    @Test
    @Order(1010)
    public void testPublicProductGivenSuccess() throws Exception {

        String adminToken = this.adminLogin("13088admin", "123456");
        String json = "{\"commissionRatio\":1}";
        this.gatewayClient.put().uri(PUBLISH,0,70)
                .header("authorization", adminToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }



    /**
     * @author Chihua Ying
     * 查看优惠活动（无需登录） - 优惠活动id找不到
     * @throws Exception
     */
    @Test
    public void testFindCouponActByIdGivenWrongId()throws Exception{
        this.mallClient.get().uri(COUPONACTID, 666666)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 查看优惠活动（无需登录） - 成功
     * @throws Exception
     */
    @Test
    public void testFindCouponActByIdGivenExistedId()throws Exception{
        this.mallClient.get().uri(COUPONACTID, 5)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.name").isEqualTo("满3件最便宜的5折");
    }

    /**
     * @author Chihua Ying
     * 查看活动中的商品（无需登录） - 成功
     * @throws Exception
     */
    @Test
    public void testFindCouponActProductByIdGivenExistedId()throws Exception{
        this.mallClient.get().uri(COUPONACTPRODUCT, 6)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '1683')].name").isEqualTo("恋味炖鱼料")
                .jsonPath("$.data.list[?(@.id == '1683')].price").isEqualTo(67699)
                .jsonPath("$.data.list[?(@.id == '1683')].status").isEqualTo(2);

    }

    /**
     * @author Chihua Ying
     * 查看活动中的商品（无需登录） - 该优惠活动不存在
     * @throws Exception
     */
    @Test
    public void testFindCouponActProductByIdGivenWrongId()throws Exception{
        this.mallClient.get().uri(COUPONACTPRODUCT, 666666)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 商户申请修改商品
     * @author Caozhiyi
     */
    @Order(1005)
    @Test
    public void testApplyModifyProduct() throws Exception {

        String shopToken = this.adminLogin("shop10", "123456");
        String json = "{\"name\": \"coke\",\"originalPrice\": 1000, \"categoryId\": 313 , \"originPlace\": \"100\" , \"unit\": \"unittest\" }";

        this.gatewayClient.put().uri(APPLY,10,1550)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno") .isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(70);
    }

    /**
     * 商户申请修改商品
     * 商户id与商品id不匹配
     * @author Caozhiyi
     */
    @Test
    public void testApplyModifyProductWithNoExistId() throws Exception {

        String shopToken = this.adminLogin("shop10", "123456");
        String json = "{\"name\": \"coke\",\"originalPrice\": 1000, \"categoryId\": 313 , \"originPlace\": \"100\" , \"unit\": \"unittest\" }";

        this.gatewayClient.put().uri(APPLY,10,489465)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno") .isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商户申请修改商品
     * @author Caozhiyi
     * 分类1无法修改（500）
     */
    @Test
    public void testApplyModifyProductNotAllow() throws Exception {
        String shopToken = this.adminLogin("shop10", "123456");
        String json = "{\"name\": \"coke\",\"originalPrice\": 1000, \"categoryId\": 1 , \"originPlace\": \"100\" , \"unit\": \"unittest\" }";

        this.gatewayClient.put().uri(APPLY, 10,1550)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CATEGORY_NOTALLOW.getErrNo());
    }

    /**
     * 店家取消商品的相关
     * @author Caozhiyi
     * （500）
     */
    @Order(1006)
    @Test
    public void testDelRelateProduct() throws Exception {

        String shopToken = this.adminLogin("shop10", "123456");

        this.gatewayClient.delete().uri(OTHERPRODUCT, 10,1550)
                .header("authorization", shopToken)
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * 店家取消商品的相关
     * 商铺并不存在已相关的该商品或者该商品已被取消相关
     * @author Caozhiyi
     */
    @Test
    public void testDelRelateProductWithNoExistId() throws Exception {

        String shopToken = this.adminLogin("shop10", "123456");

        this.gatewayClient.delete().uri(OTHERPRODUCT, 10,15551)
                .header("authorization", shopToken)
                .exchange()
                .expectStatus().isNotFound()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 店家取消商品的相关
     * 越权操作
     * @author Caozhiyi
     */
    @Test
    public void testDelRelateProductWithNoAllowed() throws Exception {

        String shopToken = this.adminLogin("shop1", "123456");

        this.gatewayClient.delete().uri(OTHERPRODUCT, 10,2319)
                .header("authorization", shopToken)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 获得该模板product的信息
     * @throws Exception
     * 店家获得使用运费模板的货（数据错误）
     * @author Caozhiyi
     */
    @Order(1006)
    @Test
    public void getTemplateProduct() throws Exception {
        String shopToken = this.adminLogin("shop3", "123456");
        this.gatewayClient.get().uri(TEMPLATEPRODUCT+"?page=1&pageSize=30",3,14)
                .header("authorization", shopToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '"+117+"')].name").isEqualTo("欢乐家杨梅罐头")
                .jsonPath("$.data.list[?(@.id == '"+115+"')].name").isEqualTo("六神沐浴露")
                .jsonPath("$.data.list[?(@.id == '"+216+"')].name").isEqualTo("六神金盏菊香皂");
    }

    /**
     * 店家获得使用运费模板的货
     * @throws Exception
     * 越权操作
     * @author Caozhiyi
     */
    @Test
    public void getTemplateProductWithTemplateNoExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.mallClient.get().uri(TEMPLATEPRODUCT+"?page=1&pageSize=30",10,1516556)
                .header("authorization", token)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 查看活动中的商品
     * @throws Exception
     * @author Caozhiyi（500）
     */
    @Test
    @Order(1007)
    public void getGrouponActProduct() throws Exception {
        this.mallClient.get().uri(GROUPONPRODUCT, 4)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.[?(@.id == '\"+1668+\"')].name").isEqualTo("肖家白胡椒粉30");
    }

    /**
     * 查看活动中的商品
     * @throws Exception
     * 活动不存在
     * @author Caozhiyi
     */
    @Test
    public void getGrouponActProductWithNoExistId() throws Exception {
        this.gatewayClient.get().uri(GROUPONPRODUCT+"?productId=1551&page=1&pageSize=30", 3)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员查询商铺的所有状态团购
     * @throws Exception
     * 根据productId进行查询
     * @author Caozhiyi
     */
    @Test
    @Order(1008)
    public void queryGrouponWithProductId() throws Exception {
        String adminToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(SHOPALLGROUPON+"?productId=1559&page=1&pageSize=30", 10  )
                .header("authorization", adminToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * 管理员查询商铺的所有状态团购
     * @throws Exception
     * 根据状态进行查询(500)
     * @author Caozhiyi
     */
    @Test
    public void queryGrouponWithStatus() throws Exception {
        String adminToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(SHOPALLGROUPON+"?status=0&page=1&pageSize=30",1)
                .header("authorization", adminToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.name").isEqualTo("团购活动4");
    }

    /**
     * 管理员查询商铺的所有状态团购
     * @throws Exception
     * 商户和活动不匹配
     * @author Caozhiyi
     */
    @Test
    public void queryGrouponWithNo() throws Exception {
        String adminToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(SHOPALLGROUPON+"?productId=1559&page=1&pageSize=30",10)
                .header("authorization", adminToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员查询商铺的所有状态团购
     * @throws Exception
     * 直接进行查询
     * @author Caozhiyi
     */
    @Test
    @Order(1008)
    public void queryGroupon() throws Exception {
        String adminToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(SHOPALLGROUPON+"?page=1&pageSize=30", 1)
                .header("authorization", adminToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * 管理员查询商铺的所有状态团购
     * @throws Exception
     * productID和status一起查询
     * @author Caozhiyi
     */
    @Test
    @Order(1008)
    public void queryGrouponWithStatusandProductId() throws Exception {

        String adminToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(SHOPALLGROUPON+"?productId=1551&status=1&page=1&pageSize=30", 2 )
                .header("authorization", adminToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }


    /**
     * 团购中的商品
     * @throws Exception
     * author 吴凯
     */
    @Test
    @Order(322)
    public void getGrouponProducts() throws Exception {
        this.mallClient.get().uri(GROUPONPRODUCT+"?page=1&pageSize=10", 4)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '1634')].name").isEqualTo("百事可乐2000");
    }

    /**
     * 团购中的商品(id不存在)
     * @throws Exception
     * author 吴凯
     */
    @Test
    @Order(324)
    public void getGrouponProductsWithIdIsNotExisted() throws Exception {
        this.mallClient.get().uri(GROUPONPRODUCT+"?page=1&pageSize=10", 37762)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员查询商铺的所有状态团购
     * @throws Exception
     * 非管理员越权操作
     * @author Caozhiyi
     */
    @Test
    public void queryGrouponWithNoAdmin() throws Exception {
        String shopToken = this.adminLogin("shop3", "123456");
        this.gatewayClient.get().uri(SHOPALLGROUPON+"?page=1&pageSize=30",1)
                .header("authorization", shopToken)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 店家或管理员查看商品详情 - 商铺不包含该商品
     * @throws Exception
     */
    @Test
    public void testGetProductIdGivenNotExist()throws  Exception{
        String shopToken = this.adminLogin("shop10", "123456");
        this.gatewayClient.get().uri(SHOPPRODUCTID, 10,1551)
                .header("authorization", shopToken)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 店家或管理员查看商品详情 - 管理员查看商品详情 - 商品不存在
     * @throws Exception
     */
    @Test
    public void testGetProductIdGivenNotExist2()throws  Exception{
        String adminToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(SHOPPRODUCTID, 0,150)
                .header("authorization", adminToken)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 店家或管理员查看商品详情 - 店家查看商品 - 商品不存在
     * @throws Exception
     */
    @Test
    public void testGetProductIdGivenNotExist3()throws  Exception{
        String shopToken = this.adminLogin("shop10", "123456");
        this.gatewayClient.get().uri(SHOPPRODUCTID, 10,150)
                .header("authorization", shopToken)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 店家或管理员查看商品详情 - 管理员查看商品详情 - 成功
     * @throws Exception
     */
    @Test
    public void testGetProductIdGivenSuccess1()throws  Exception{
        String adminToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(SHOPPRODUCTID, 0,1550)
                .header("authorization", adminToken)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 店家或管理员查看商品详情 - 店家查看商品详情 - 成功
     * @throws Exception
     */
    @Test
    public void testGetProductIdGivenSuccess2()throws  Exception{
        String shopToken = this.adminLogin("shop10", "123456");
        this.gatewayClient.get().uri(SHOPPRODUCTID, 10,1550)
                .header("authorization", shopToken)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }


    /**
     * @author Yangxin Jiang
     * 店家删除otherProduct - 商品不存在
     * @throws Exception
     */
    @Test
    public void testDeleteOtherProductNotExist()throws Exception{
        String shopToken = this.adminLogin("shop3", "123456");
        this.gatewayClient.delete().uri(OTHERPRODUCT, 3,15551)
                .header("authorization", shopToken)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 店家删除otherProduct - 商品不属于该店铺
     * @throws Exception
     */
    @Test
    public void testDeleteOtherProductForbidden()throws Exception{
        String shopToken = this.adminLogin("shop3", "123456");
        this.gatewayClient.delete().uri(OTHERPRODUCT, 3,1550)
                .header("authorization", shopToken)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }
    /**
     * @author Yangxin Jiang
     * 店家删除otherProduct - 成功
     * @throws Exception
     */
    @Test
    public void testDeleteOtherProductSuccess()throws Exception{
        String shopToken = this.adminLogin("shop3", "123456");
        this.gatewayClient.delete().uri(OTHERPRODUCT, 3,1551)
                .header("authorization", shopToken)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }
    /**
     * 平台管理员修改货品分账比例
     * 是平台管理员
     * 比例小于0
     * @author Huanjia Zhang
     * @throws Exception
     */
    @Test
    @Order(68)
    public void testPutProductRatioGivenRatioWrong() throws Exception {
        assertNotNull(productId);
        String token = this.adminLogin("admin", "123456");
        String json = "{\"commissionRatio\": -1}";
        this.gatewayClient.put().uri(COMMISSIONRATIO,0, 1550)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 平台管理员修改货品分账比例
     * 是平台管理员
     * 比例大于100%
     * @author Huanjia Zhang
     * @throws Exception
     */
    @Test
    @Order(68)
    public void testPutProductRatioGivenRatioWrong1() throws Exception {
        assertNotNull(productId);
        String token = this.adminLogin("admin", "123456");
        String json = "{\"commissionRatio\": 10000000}";
        this.gatewayClient.put().uri(COMMISSIONRATIO,0, 1550)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * @author Huanjia Zhang
     * 价格小于0
     * @throws Exception
     */
    @Test
    public void postOnsaleGivenWrongPrice() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": -1," +
                "\"beginTime\": \"2022-12-18T20:38:20\"," +
                "\"endTime\": \"2025-12-18T20:38:20\","+
                "  \"quantity\": 10000," +
                "  \"type\": 0," +
                "  \"maxQuantity\":10}";
        this.gatewayClient.post().uri(ONSALE, 1, 1223345)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 数量小于0
     * @throws Exception
     */
    @Test
    public void postOnsaleGivenWrongQuantity() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 10," +
                "\"beginTime\": \"2022-12-18T20:38:20\"," +
                "\"endTime\": \"2025-12-18T20:38:20\","+
                "  \"quantity\": -1" +
                "  \"type\": 0," +
                "  \"maxQuantity\":10}";
        this.gatewayClient.post().uri(ONSALE, 1, 1223345)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 最大数量小于0
     * @throws Exception
     */
    @Test
    public void postOnsaleGivenWrongMaxQuantity() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 10" +
                "\"beginTime\": \"2022-12-18T20:38:20\"," +
                "\"endTime\": \"2025-12-18T20:38:20\","+
                "  \"quantity\": 10000," +
                "  \"type\": 0," +
                "  \"maxQuantity\":-1}";
        this.gatewayClient.post().uri(ONSALE, 1, 1223345)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 定金小于0
     * @throws Exception
     */
    @Test
    public void postOnsaleGivenWrongDeposit() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 10" +
                "\"beginTime\": \"2022-12-18T20:38:20\"," +
                "\"endTime\": \"2025-12-18T20:38:20\","+
                "  \"quantity\": 10000," +
                "  \"type\": 0," +
                "  \"maxQuantity\":-1," +
                "\"deposit\": \"-1\" }";
        this.gatewayClient.post().uri(ONSALE, 1, 1223345)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 定金大于价格
     * @throws Exception
     */
    @Test
    public void postOnsaleGivenDepositBiggerThanPrice() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\": 10" +
                "\"beginTime\": \"2022-12-18T20:38:20\"," +
                "\"endTime\": \"2025-12-18T20:38:20\","+
                "  \"quantity\": 10000," +
                "  \"type\": 0," +
                "  \"maxQuantity\":-1," +
                "\"deposit\": \"100\" }";
        this.gatewayClient.post().uri(ONSALE, 1, 1223345)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * author: Huanjia Zhang
     * describe: 修改商品类目信息 比率大于100%
     */
    @Test
    @Order(30)
    public void putCateoryGivenRatioWrong1() throws Exception {
        String token = this.adminLogin("admin", "123456");
        String roleJson = "{\"name\": \"测试一级分类\",\"commissionRatio\": 10000000}";
        this.gatewayClient.put().uri(CATEGORY,0,100000)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(roleJson)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());

    }
    /**
     * author: Huanjia Zhang
     * describe: 比率大于100%
     */
    @Test
    @Order(31)
    public void postSubCategoriesGivenRatioWrong1() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String roleJson = "{\"name\": \"测试二级分类\",\"commissionRatio\": 100000000}";
        this.gatewayClient.post().uri(SUBCATEGORY, 0, 1)
                .header("authorization", token)
                .bodyValue(roleJson)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * 创建团购活动 比例数量小于0
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(415)
    public void testPostGrouponGivenWrongPercentageQuantity() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"name\": \"团购测试1\","+
                "\"thresholds\": [" +
                "{ \"quantity\": -1, \"percentage\": 2}," +
                "{ \"quantity\": 200, \"percentage\": 2}," +
                "{ \"quantity\": 300, \"percentage\": 2}]," +
                "\"price\":1,\"quantity\":100,\"max_quantity\":200," +
                "\"beginTime\":\"2023-12-05T10:09:50.000\",\"endTime\":\"2032-12-05T10:09:50.000\"" +
                "}";

        this.gatewayClient.post().uri(SHOPGROUPON, 1,4959)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo())
                .returnResult().getResponseBody();
    }
    /**
     * 将商品加入到活动中（价格小于0）
     * @throws Exception
     * @author Huanjia Zhang
     */
    @Test
    @Order(470)
    public void testPostAddProductToGrouponGivenWrongPrice() throws Exception {
        assertNotNull(this.grouponId1);
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"price\":-1, \"quantity\": 200, \"maxQuantity\": 2}";
        this.gatewayClient.post().uri(ADDPRODUCTTOGROUPON, 1, 4959, this.grouponId1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }
    /**
     * 草稿商品测试
     * @author Huanjia Zhang
     * 发布商品 比率大于100%
     */
    @Order(1010)
    @Test
    public void testPublicProductGivenRatioWrong1() throws Exception {

        String shopToken = this.adminLogin("13088admin", "123456");
        String json = "{\"commissionRatio\":10000000}";
        this.gatewayClient.put().uri(PUBLISH,0,70)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectHeader()
                .contentType("application/json;charset=UTF-8")
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());

    }
}





