//School of Informatics Xiamen University, GPL-3.0 license

package cn.edu.xmu.oomall.publictest.required.payment;

import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PaymentTest extends BaseTestOomall {
    private final static String REFUNDSID = "/payment/shops/{shopId}/refunds/{id}";//查看退款单的详情信息&&调账退款单
    private final static String REFUNDS = "/payment/shops/{shopId}/payments/{id}/refunds";
    private final static String CHANNELREFUNDS = "/payment/shops/{shopId}/channels/{id}/refunds";
    private final static String PAYMENTSID = "/payment/shops/{shopId}/payments/{id}";
    private final static String PAYMENTS = "/payment/shops/{shopId}/channels/{id}/payments";
    private final static String NOTIFYALIPAY = "/payment/notify/payments/alipay";
    private final static String NOTIFYWEPAY = "/payment/notify/payments/wepay";

    /**
     * @author Chihua Ying
     * 获取支付交易 - 存在 且 微信 且 状态不为 NEW
     * @throws Exception
     */
    @Test
    public void testGetPaymentWhenIdExistAndChannelIsWePayAndStatusIsNotNew() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTSID, 0, 551)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.transNo").isEqualTo("12222")
                .jsonPath("$.data.divAmount").isEqualTo(4)
                .jsonPath("$.data.inRefund").isEqualTo(0)
                .jsonPath("$.data.amount").isEqualTo(100);
    }

    /**
     * @author Chihua Ying
     * 获取支付交易 - 存在 且 支付宝 且 状态不为 NEW
     * @throws Exception
     */
    @Test
    public void testGetPaymentWhenIdExistAndChannelIsAliPayAndStatusIsNotNew() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTSID, 0, 20683)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.transNo").isEqualTo("24896")
                .jsonPath("$.data.divAmount").isEqualTo(49342)
                .jsonPath("$.data.inRefund").isEqualTo(0)
                .jsonPath("$.data.amount").isEqualTo(1233562);
    }

    /**
     * @author Chihua Ying
     * 获取支付交易 - 管理员 存在 且 微信 且 状态为 NEW
     * 状态为NEW,TransNo不为空 的情况下会调用到 模拟微信 的
     * @GetMapping("/internal/v3/pay/partner/transactions/id/{transaction_id}")
     * <当前payTrans表暂缺该条件的数据>
     * @throws Exception
     */
    @Test
    public void testGetPaymentWhenIdExistAndChannelIsWePay() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTSID, 0, 862)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.transNo").isEqualTo("5")
                .jsonPath("$.data.divAmount").isEqualTo(519)
                .jsonPath("$.data.inRefund").isEqualTo(0)
                .jsonPath("$.data.amount").isEqualTo(25944);
    }

    /**
     * @author Chihua Ying
     * 获取支付交易 - 管理员 存在 且 微信 且 状态为 NEW
     * 状态为NEW,TransNo为空 的情况下会调用到 模拟微信 的
     * @GetMapping("/internal/v3/pay/partner/transactions/id/{transaction_id}")
     * <当前payTrans表暂缺该条件的数据>
     * @throws Exception
     */
    @Test
    public void testGetPaymentWhenIdExistAndChannelIsWePayAndTransNoIsNull() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTSID, 0, 860)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.transNo").doesNotExist()
                .jsonPath("$.data.divAmount").isEqualTo(53)
                .jsonPath("$.data.inRefund").isEqualTo(0)
                .jsonPath("$.data.amount").isEqualTo(5308);
    }

    /**
     * @author Chihua Ying
     * 获取支付交易 - 管理员 存在 且 支付宝 且 状态为 NEW
     * 状态为NEW,TransNo不为空 的情况下会调用到 模拟支付宝 的
     * @PostMapping("/internal/v3/alipay/trade/query")
     * @throws Exception
     */
    @Test
    public void testGetPaymentWhenIdExistAndChannelIsAliPay() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTSID, 0, 862)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.transNo").isEqualTo("5")
                .jsonPath("$.data.divAmount").isEqualTo(519)
                .jsonPath("$.data.inRefund").isEqualTo(0)
                .jsonPath("$.data.amount").isEqualTo(25944);
    }

    /**
     * @author Chihua Ying
     * 获取支付交易 - 管理员 存在 支付宝 但 TransNo为空
     * @PostMapping("/internal/v3/alipay/trade/query")
     * @throws Exception
     */
    @Test
    public void testGetPaymentWhenIdExistAndChannelIsAliPayAndTransNoIsNull() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTSID, 0, 860)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.transNo").doesNotExist()
                .jsonPath("$.data.divAmount").isEqualTo(53)
                .jsonPath("$.data.inRefund").isEqualTo(0)
                .jsonPath("$.data.amount").isEqualTo(5308);
    }

    /**
     * @author Chihua Ying
     * 获取支付交易 - 不存在
     * @throws Exception
     */
    @Test
    public void testGetPaymentWhenIdNotExist() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTSID, 0, 552)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 获取支付交易 - 权限不足
     * @throws Exception
     */
    @Test
    public void testGetPaymentWhenAuthorityIsNotEnough() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.get().uri(PAYMENTSID, 0, 551)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 查询固定渠道的支付单 - 管理员查 且 微信
     * https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/payment/retrievePay
     * 这不是查询渠道的api 这是查询固定渠道的支付单的api，路径中有开始时间和结束时间，是查在这段时间内固定渠道的支付单
     * 路径不设置时间的话只会查默认一段时间的，就会查不到
     * 删除了部分断言，因为返回的dto实际上是simple paytrans，没有所有的东西
     * 如果路径
     * @throws Exception
     */
    @Test
    public void testRetrievePaymentsWhenUserIsAdminAndChannelIsWePay() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTS+"?beginTime=2022-11-05T12:30:45", 0, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '768')].status").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '768')].amount").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '768')].outNo").isEqualTo("768")
                .jsonPath("$.data.list[?(@.id == '768')].transNo").isEqualTo("768")
                .jsonPath("$.data.list[?(@.id == '859')].status").isEqualTo(7)
                .jsonPath("$.data.list[?(@.id == '859')].amount").isEqualTo(799566)
                .jsonPath("$.data.list[?(@.id == '859')].outNo").isEqualTo("1")
                .jsonPath("$.data.list[?(@.id == '859')].transNo").isEqualTo("1")
                .jsonPath("$.data.list[?(@.id == '860')].status").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '860')].amount").isEqualTo(5308)
                .jsonPath("$.data.list[?(@.id == '860')].outNo").isEqualTo("2");
    }

    /**
     * @author Chihua Ying
     * 查询固定渠道的支付单 - 管理员查 且 支付宝
     * @throws Exception
     */
    @Test
    public void testRetrievePaymentsWhenUserIsAdminAndChannelIsAliPay() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTS+"?beginTime=2022-11-05T12:30:45", 0, 502)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '862')].status").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '862')].amount").isEqualTo(25944)
                .jsonPath("$.data.list[?(@.id == '862')].outNo").isEqualTo("7")
                .jsonPath("$.data.list[?(@.id == '862')].transNo").isEqualTo("5")
                .jsonPath("$.data.list[?(@.id == '919')].status").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '919')].amount").isEqualTo(283169)
                .jsonPath("$.data.list[?(@.id == '919')].outNo").isEqualTo("79")
                .jsonPath("$.data.list[?(@.id == '919')].transNo").isEqualTo("79")
                .jsonPath("$.data.list[?(@.id == '920')].status").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '920')].amount").isEqualTo(352468)
                .jsonPath("$.data.list[?(@.id == '920')].outNo").isEqualTo("74")
                .jsonPath("$.data.list[?(@.id == '920')].transNo").isEqualTo("74");
    }

    /**
     * @author Chihua Ying
     * 查询固定渠道的支付单 - 商铺查 且 微信
     * @throws Exception
     */
    @Test
    public void testRetrievePaymentsWhenUserIsShopAndChannelIsWePay() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(PAYMENTS+"?beginTime=2022-11-05T12:30:45", 1, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '768')].status").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '768')].amount").isEqualTo(1000)
                .jsonPath("$.data.list[?(@.id == '768')].outNo").isEqualTo("768")
                .jsonPath("$.data.list[?(@.id == '768')].transNo").isEqualTo("768")
                .jsonPath("$.data.list[?(@.id == '859')].status").isEqualTo(7)
                .jsonPath("$.data.list[?(@.id == '859')].amount").isEqualTo(799566)
                .jsonPath("$.data.list[?(@.id == '859')].outNo").isEqualTo("1")
                .jsonPath("$.data.list[?(@.id == '859')].transNo").isEqualTo("1")
                .jsonPath("$.data.list[?(@.id == '864')].status").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '864')].amount").isEqualTo(94052)
                .jsonPath("$.data.list[?(@.id == '864')].outNo").isEqualTo("13")
                .jsonPath("$.data.list[?(@.id == '864')].transNo").isEqualTo("13");

    }

    /**
     * @author Chihua Ying
     * 查询固定渠道的支付单 - 商铺查 且 支付宝
     * @throws Exception
     */
    @Test
    public void testRetrievePaymentsWhenUserIsShopAndChannelIsAliPay() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(PAYMENTS+"?beginTime=2022-11-05T12:30:45", 1, 502)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '862')].status").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '862')].amount").isEqualTo(25944)
                .jsonPath("$.data.list[?(@.id == '862')].outNo").isEqualTo("7")
                .jsonPath("$.data.list[?(@.id == '862')].transNo").isEqualTo("5")
                .jsonPath("$.data.list[?(@.id == '919')].status").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '919')].amount").isEqualTo(283169)
                .jsonPath("$.data.list[?(@.id == '919')].outNo").isEqualTo("79")
                .jsonPath("$.data.list[?(@.id == '919')].transNo").isEqualTo("79")
                .jsonPath("$.data.list[?(@.id == '922')].status").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '922')].amount").isEqualTo(513563)
                .jsonPath("$.data.list[?(@.id == '922')].outNo").isEqualTo("77")
                .jsonPath("$.data.list[?(@.id == '922')].transNo").isEqualTo("77");
    }

    /**
     * @author Chihua Ying
     * 调账 - 不存在该id的支付单
     * @throws Exception
     * @reason (From Chihua Ying) 返回的状态应该是 isNotFound
     */
    //@Test
    public void testAdjustGivenWrongId() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(PAYMENTSID, 0, 123454321)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 调账 - 只有管理员有权限调账
     * @throws Exception
     */
    @Test
    public void testAdjustPaymentsWhenAuthorityIsNotEnough() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(PAYMENTSID, 1, 502)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 调账 - 只有错账才可以调账
     * @throws Exception
     */
    @Test
    public void testAdjustPaymentsWhenStateIsNotWrong() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(PAYMENTSID, 0, 551)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 调账 - 成功
     * @throws Exception
     */
    @Test
    public void testAdjustPaymentGivenRightArgs()throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(PAYMENTSID, 0, 1058)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author renyu
     * 对已经调账过的支付单再次进行调账
     * @throws Exception
     * @reason (From Chihua Ying) 第二个Status不应该是isBadRequest
     */
    //@Test
    public void testAdjustPaymentGivenAlreadyAdjustedId() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        // 首先进行第一次调账
        this.gatewayClient.put().uri(PAYMENTSID,0, 1059)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
        // 尝试进行第二次调账
        this.gatewayClient.put().uri(PAYMENTSID, 0, 1059)
                .header("authorization", token)
                .exchange().expectStatus().isBadRequest()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }

    /**
     * @author renyu
     * 调账 - 支付单不存在
     * @throws Exception
     */
    @Test
    public void testAdjustGivenNonExistentPayment() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(PAYMENTSID, 0, 9999999)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 支付宝 支付回调
     * 状态为 TRADE_CLOSED
     * @throws Exception
     * 回调是顾客的api
     */
    @Test
    public void testAlipayNotifyWhenStateIsTRADE_CLOSED() throws Exception{
        String body = "{\"app_id\": \"20214072300007148\"," +
                "\"trade_no\": \"2013112011001004330000121536\"," +
                "\"out_trade_no\": \"6823789339978248\"," +
                "\"gmt_payment\": \"2023-12-22T12:34:56\"," +
                "\"trade_status\": \"TRADE_CLOSED\"," +
                "  \"recipet_amount\": 100}";
        this.mallClient.post().uri(NOTIFYALIPAY)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 支付宝 支付回调
     * 状态为 TRADE_SUCCESS
     * @throws Exception
     * 回调是顾客的api
     */
    @Test
    public void testAlipayNotifyWhenStateIsTRADE_SUCCESS() throws Exception{
        String body = "{\"app_id\": \"20214072300007148\"," +
                "\"trade_no\": \"2013112011001004330000121536\"," +
                "\"out_trade_no\": \"6823789339978248\"," +
                "\"gmt_payment\": \"2023-12-22T12:34:56\"," +
                "\"trade_status\": \"TRADE_SUCCESS\"," +
                "  \"recipet_amount\": 100}";
        this.mallClient.post().uri(NOTIFYALIPAY)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 支付宝 支付回调
     * 状态为 除了 TRADE_CLOSED和TRADE_SUCCESS 的其他状态
     * @throws Exception
     * 回调是顾客的api
     */
    @Test
    public void testAlipayNotifyWhenStateIsOtherState() throws Exception{
        String body = "{\"app_id\": \"20214072300007148\"," +
                "\"trade_no\": \"2013112011001004330000121536\"," +
                "\"out_trade_no\": \"6823789339978248\"," +
                "\"gmt_payment\": \"2023-12-22T12:34:56\"," +
                "\"trade_status\": \"WAIT_BUYER_PAY\"," +
                "  \"recipet_amount\": 100}";
        this.mallClient.post().uri(NOTIFYALIPAY)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Chihua Ying
     * 微信 支付回调
     * 成功
     * @throws Exception
     * 回调是顾客的api
     */
    @Test
    public void testWePayNotifyGivenRightArgs() throws Exception{
        String body = "{\"id\": \"EV-2018022511223320873\"," +
                "\"create_time\": \"2015-05-20T13:29:35+08:00\"," +
                "\"resource\": {" +
                "\"sp_appid\": \"wx8888888888888888\"," +
                "\"sp_mchid\": \"1230000109\"," +
                "\"sub_mchid\": \"1900000109\"," +
                "\"out_trade_no\": \"1217752501201407033233368018\"," +
                "\"transaction_id\": \"1217752501201407033233368018\"," +
                "\"trade_state\": \"SUCCESS\"," +
                "\"success_time\": \"2013112011001004330000121536\"," +
                "\"amount\": {" +
                "\"total\": 100," +
                "\"payer_total\": 90}," +
                "\"payer\": {" +
                "\"sp_openid\": \"oUpF8uMuAJO_M2pxb1Q9zNjWeS6o\"}" +
                "}}";
        this.mallClient.post().uri(NOTIFYWEPAY)
                .bodyValue(body)
                .exchange().expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    //https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/payment/retrievePay查询渠道支付信息
    /**
     * @author Huanjia Zhang
     * 查询渠道支付信息 管理员带渠道交易号
     */
    @Test
    public void testGetChannelPaymentsGivenTransNo() throws Exception{

        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(PAYMENTS + "?transNo=2111", 0, 501)//管理员id 支付渠道id 之前的渠道不存在
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '768')].transNo").isEqualTo("2111");
    }

    /**
     * @author 吴凯
     * 查询渠道支付信息 管理员带渠道交易号（渠道交易号不存在）
     * @reason (From Chihua Ying) transNo=188888不是路径上的，返回的状态应该是 OK
     */
    //@Test
    public void testGetChannelPaymentsGivenTransNoGivenTransNoNotExisted() throws Exception{

        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(PAYMENTS + "?transNo=188888", 0, 501)//管理员id 支付渠道id
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author 吴凯
     * 查询渠道支付信息 管理员带渠道交易号（支付渠道id不存在）
     */
    @Test
    public void testGetChannelPaymentsGivenTransNoGivenIdNotExisted() throws Exception{

        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(PAYMENTS + "?transNo=12222", 0, 550)//管理员id 支付渠道id
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 查询渠道支付信息 商户带渠道交易号
     */
    @Test
    public void testGetChannelPaymentsGivenShop() throws Exception{

        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(PAYMENTS + "?transNo=2111", 0, 501)//管理员id 支付渠道id
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '768')].transNo").isEqualTo("2111");
    }

    /**
     * @author 吴凯
     * 查询渠道支付信息 商户带渠道交易号（渠道交易号不存在）
     */
    @Test
    public void testGetChannelPaymentsGivenShopTransNoNotExisted() throws Exception{

        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(PAYMENTS + "?transNo=21111", 0, 501)//管理员id 支付渠道id
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author 吴凯
     * 查询渠道支付信息 商户带渠道交易号（支付渠道不存在）
     */
    @Test
    public void testGetChannelPaymentsGivenShopIdNotExisted() throws Exception{

        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(PAYMENTS + "?transNo=2111", 0, 550)//管理员id 支付渠道id
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Rui Li
     * 管理员根据条件查询查询退款单
     * 管理员可以查询channel的所有退款单
     */
    @Test
    public void testRetrieveRefundsGivenManagerTokenWithTranNo() throws Exception {

        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(CHANNELREFUNDS +"?transNo=241&beginTime=2022-11-05T12:30:45&status=1", 0, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '633')].outNo").isEqualTo("241");
    }

    /**
     * @author Rui Li
     * 商户根据条件查询查询退款单
     * 商户只能查询自己shopChannel的退款单
     */
    @Test
    public void testRetrieveRefundsGivenShopTokenWithoutTransNo() throws Exception {

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.get().uri(CHANNELREFUNDS +"?status=0&beginTime=2022-11-05T12:30:45&endTime=2023-11-30T12:30:45&page=1&pageSize=100", 1, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(6)
                .jsonPath("$.data.list[?(@.id == '501')].outNo").isEqualTo("501")
                .jsonPath("$.data.list[?(@.id == '597')].outNo").isEqualTo("597")
                .jsonPath("$.data.list[?(@.id == '598')].outNo").isEqualTo("1")
                .jsonPath("$.data.list[?(@.id == '599')].outNo").isEqualTo("4")
                .jsonPath("$.data.list[?(@.id == '611')].outNo").isEqualTo("62")
                .jsonPath("$.data.list[?(@.id == '613')].outNo").isEqualTo("134");
    }

    /**
     * @author Ningjian Zhang
     * 商户查询不是自己Channel的退款单
     *
     * 处理人：李睿
     * 原因：请求路径错误
     */
//    @Test
    public void testRetriveRefundsGivenShopTokenWithoutTransNoWithWrongChannelId(){

        String token = this.adminLogin("shop2", "123456");

        this.gatewayClient.get().uri(REFUNDS +"?status=0&beginTime=2022-11-05T12:30:45&endTime=2023-11-30T12:30:45&page=1&pageSize=100", 2, 501)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }
   /**
     * @author hyx
     * 商户根据条件查询退款单
     * 支付渠道不存在
    *
    * 处理人：李睿
    * 原因：请求路径错误
     */
//    @Test
    public void testRetrieveRefundsGivenChannelNoExist() throws Exception {

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.get().uri(CHANNELREFUNDS +"?status=0&beginTime=2022-11-05T12:30:45&endTime=2023-11-30T12:30:45&page=1&pageSize=100", 1, 500)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author hyx
     * 商户根据条件查询退款单
     * 商户查询别人的退款单
     *
     * 处理人：李睿
     * 原因：请求路径错误
     */
//    @Test
    public void testRetrieveRefundsGivenSearchOtherRefunds() throws Exception {

        String token = this.adminLogin("shop2", "123456");

        this.gatewayClient.get().uri(CHANNELREFUNDS +"?status=0&beginTime=2022-11-05T12:30:45&endTime=2023-11-30T12:30:45&page=1&pageSize=100", 1, 501)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author Rui Li
     * 管理员调账退款单
     */
    @Test
    public void testJustRefund() throws Exception {

        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.put().uri(REFUNDSID, 0, 617)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Rui Li
     * 退款单状态不为”错账“
     */
    @Test
    public void testJustRefundGivenWrongStatus() throws Exception {

        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.put().uri(REFUNDSID, 0, 1761)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo())
                .jsonPath("$.errmsg").isEqualTo("退款交易对象（id=1761）已退款状态禁止此操作");
    }

    /**
     * @author Rui Li
     * 非管理员访问
     */
    @Test
    public void testJustRefundGivenWrongToken() throws Exception {

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.put().uri(REFUNDSID, 1, 1761)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo())
                .jsonPath("$.errmsg").isEqualTo("退款单对象(id=1761)超出商铺（id = 1）的操作范围");
    }

    /**
     * @author Huanjia Zhang
     * 查询渠道支付信息 未开通渠道
     */
    @Test
    public void testGetChannelPaymentsGivenShop1() throws Exception{

        String token = this.adminLogin("shop2", "123456");

        this.gatewayClient.get().uri(PAYMENTS, 2, 501)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 查询渠道支付信息 支付渠道不存在
     */
    @Test
    public void testGetChannelPaymentsGivenWrongId() throws Exception{

        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(PAYMENTS, 1, 600)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }


    /**
     * @author Huanjia Zhang
     * 查询渠道退款信息 其他商户无权限
     */
    @Test
    public void testGetRefundsGivenWrongAdmin() throws Exception{

        String token = this.adminLogin("shop2", "123456");

        this.gatewayClient.get().uri(CHANNELREFUNDS, 2, 501)//
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }
    /**
     * @author Huanjia Zhang
     * 查询渠道退款信息 错误的退款单号
     */
    @Test
    public void testGetRefundsGivenWrongRefundId() throws Exception{

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.get().uri(CHANNELREFUNDS, 1, 86000)//
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.PAY_CHANNEL_INVALID.getErrNo());
    }
    /**
     * @author Huanjia Zhang
     * 查看退款单详细信息
     */
    //https://app.swaggerhub.com/apis/mingqcn/OOMALL/1.3.2#/payment/getRefund查看退款单详细信息
    @Test
    public void testGetRefundsId() throws Exception{

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.get().uri(REFUNDSID, 1, 598)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(598)
                .jsonPath("$.data.outNo").isEqualTo("1")
                .jsonPath("$.data.amount").isEqualTo(799566)
                .jsonPath("$.data.divAmount").isEqualTo(55970)
                .jsonPath("$.data.successTime").isEqualTo("2022-12-18T01:14:24")
                .jsonPath("$.data.channel.name").isEqualTo("微信支付")
                .jsonPath("$.data.creator.id").isEqualTo(1);
    }
    /**
     * @author Huanjia Zhang
     * 查看退款单详细信息 商户身份错误
     */
    @Test
    public void testGetRefundsIdGivenWrongShop() throws Exception{

        String token = this.adminLogin("shop2", "123456");

        this.gatewayClient.get().uri(REFUNDSID, 2, 598)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }
    /**
     * @author Huanjia Zhang
     * 查看退款单详细信息 不存在的退款单
     */
    @Test
    public void testGetRefundsIdGivenNonExistId() throws Exception{

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.get().uri(REFUNDSID, 1, 59228)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * @author renyu
     * 测试使用无效的店铺ID查询支付信息
     * @reason (From Chihua Ying) 商铺id 和 token 就已经不对应了，上层就挂了
     */
    //@Test
    public void testGetPaymentsGivenInvalidShopId() throws Exception {
        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(PAYMENTS, 99999999 , 501)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
    * @author renyu
    * 测试查询渠道支付信息时提供无效的查询参数，验证系统能够正确处理无效的查询参数（如错误的时间格式、无效的状态码）
    */
    @Test
    public void testGetChannelPaymentsGivenInvalidParameters() throws Exception {
        String token = this.adminLogin("admin", "123456");
    
        this.gatewayClient.get().uri(PAYMENTS + "?beginTime=invalidTime&status=999", 0, 501)
               .header("authorization", token)
               .exchange().expectStatus().isBadRequest() 
               .expectHeader().contentType("application/json;charset=UTF-8")
               .expectBody()
               .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo()); 
    }

    /**
    * @author renyu
    * 测试使用日期范围过滤退款信息时endtime早于begintime的特殊情况
     *
     * 处理人：李睿
     * 原因：请求路径错误
    */
//    @Test
    public void testGetRefundsGivenFilteredByDateRange() throws Exception {
        String token = this.adminLogin("admin", "123456");

        // endtime早于begintime
        this.gatewayClient.get().uri(REFUNDS + "?beginTime=2023-01-31&endTime=2023-01-11", 0, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 微信 支付回调
     * 缺少必要的字段
     * @throws Exception
     */
    @Test
    public void testWePayNotifyGivenBlankArgs() throws Exception{
        String body = "{}";
        this.mallClient.post().uri(NOTIFYWEPAY)
                .bodyValue(body)
                .exchange().expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 支付宝 支付回调
     * 缺少必要的字段
     * @throws Exception
     */
    @Test
    public void testAliPayNotifyGivenBlankArgs() throws Exception{
        String body = "{}";
        this.mallClient.post().uri(NOTIFYALIPAY)
                .bodyValue(body)
                .exchange().expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }


    /**
     * @author Lian ShuQuan
     * 查询退款单，日期错误
     * endTime早于beginTime,ContorllerAspect做了检查，会把endTime设为现在，beginTime设为一个月前，导致查询结果随测试时间不同
     * (有些同学用了REFUNDS这个路径，但这个路径似乎没有api)
     *
     * 处理人：李睿
     * 原因：日期格式错误
     */
//    @Test
    public void testGetRefundsWhenDateError() throws Exception {
        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.get().uri(CHANNELREFUNDS + "?beginTime=2023-01-21&endTime=2023-01-20", 0, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Lian ShuQuan
     * 管理员查询固定渠道的支付单
     * endTime早于beginTime,ContorllerAspect做了检查，会把endTime设为现在，beginTime设为一个月前，导致查询结果随测试时间不同
     * @throws Exception
     * @reason (From Chihua Ying) BadRequest,单单2023-01-21无法成功转换的，要2023-01-21TXX:XX:XX
     */
    //@Test
    public void testRetrievePaymentsWhenDateError() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(PAYMENTS + "?beginTime=2023-01-21&endTime=2023-01-20", 0, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '551')].transNo").isEqualTo("12222")
                .jsonPath("$.data.list[?(@.id == '551')].divAmount").isEqualTo(4)
                .jsonPath("$.data.list[?(@.id == '551')].inRefund").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '551')].amount").isEqualTo(100);
    }


}

