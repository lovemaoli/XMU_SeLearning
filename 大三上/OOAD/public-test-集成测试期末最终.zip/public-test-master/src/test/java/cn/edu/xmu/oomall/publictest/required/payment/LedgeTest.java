//School of Informatics Xiamen University, GPL-3.0 license

package cn.edu.xmu.oomall.publictest.required.payment;

import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class LedgeTest extends BaseTestOomall {
    private static final String LEDGERS = "/payment/shops/{shopId}/ledgers";
    private static final String LEDGERID = "/payment/shops/{shopId}/ledgers/{id}";


    /**
     * @author LianShuQuan
     * 系统中没有该api
     */
//    @Test
//    @Order(10)
//    public void getLedegersGivenShop9() {
//        String token = this.adminLogin("shop9", "123456");
//
//        this.gatewayClient.get().uri(LEDGERS, 9)
//                .header("authorization", token)
//                .exchange().expectStatus().isOk()
//                .expectHeader().contentType("application/json;charset=UTF-8")
//                .expectBody()
//                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
//                .jsonPath("$.data.list.length()").isEqualTo(5);
//    }

    /**
     * @author LianShuQuan
     * 系统中没有该api
     */
//    @Test
//    @Order(10)
//    public void getLedegerId() {
//        String token = this.adminLogin("shop9", "123456");
//
//        this.gatewayClient.get().uri(LEDGERID, 9, 502)
//                .header("authorization", token)
//                .exchange().expectStatus().isOk()
//                .expectHeader().contentType("application/json;charset=UTF-8")
//                .expectBody()
//                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
//                .jsonPath("$.data.id").isEqualTo(502)
//                .jsonPath("$.data.outNo").isEqualTo("31200")
//                .jsonPath("$.data.amount").isEqualTo(110823)
//                .jsonPath("$.data.type").isEqualTo(1)
//                .jsonPath("$.data.status").isEqualTo(0)
//                .jsonPath("$.data.creator.userName").isEqualTo("admin111")
//                .jsonPath("$.data.shopChannel.name").isEqualTo("支付宝")
//                .jsonPath("$.data.trans.id").isEqualTo(25812)
//                .jsonPath("$.data.trans.status").isEqualTo(3)
//                .jsonPath("$.data.trans.amount").isEqualTo(110823);
//    }


    /**
     * @author LianShuQuan
     * 系统中没有该api
     */
//    @Test
//    public void getLedegerIdGivenWrongUser() {
//        String token = this.adminLogin("shop8", "123456");
//
//        this.gatewayClient.get().uri(LEDGERID, 8, 502)
//                .header("authorization", token)
//                .exchange().expectStatus().isForbidden()
//                .expectHeader().contentType("application/json;charset=UTF-8")
//                .expectBody()
//                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
//    }


    /**
     * @author LianShuQuan
     * 系统中没有该api
     */
//    @Test
//    public void getLedegerIdGivenNonExistId() {
//        String token = this.adminLogin("shop8", "123456");
//
//        this.gatewayClient.get().uri(LEDGERID, 8, 12334)
//                .header("authorization", token)
//                .exchange().expectStatus().isNotFound()
//                .expectHeader().contentType("application/json;charset=UTF-8")
//                .expectBody()
//                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
//    }


    /**
     * @author LianShuQuan
     * 系统中没有该api
     */
//    @Test
//    @Order(20)
//    public void putLedgerId() throws Exception{
//        String token = this.adminLogin("shop9", "123456");
//
//        this.gatewayClient.put().uri(LEDGERID, 9, 502)
//                .header("authorization", token)
//                .exchange().expectStatus().isOk()
//                .expectHeader().contentType("application/json;charset=UTF-8")
//                .expectBody()
//                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
//
//        this.gatewayClient.get().uri(LEDGERID, 9, 502)
//                .header("authorization", token)
//                .exchange().expectStatus().isOk()
//                .expectHeader().contentType("application/json;charset=UTF-8")
//                .expectBody()
//                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
//                .jsonPath("$.data.id").isEqualTo(502)
//                .jsonPath("$.data.outNo").isEqualTo("31200")
//                .jsonPath("$.data.amount").isEqualTo(110823)
//                .jsonPath("$.data.type").isEqualTo(1)
//                .jsonPath("$.data.status").isEqualTo(1)
//                .jsonPath("$.data.adjustor.id").isEqualTo(9)
//                .jsonPath("$.data.adjustor.userName").isEqualTo("shop9")
//                .jsonPath("$.data.creator.userName").isEqualTo("admin111")
//                .jsonPath("$.data.shopChannel.name").isEqualTo("支付宝")
//                .jsonPath("$.data.trans.id").isEqualTo(25812)
//                .jsonPath("$.data.trans.status").isEqualTo(2)
//                .jsonPath("$.data.trans.amount").isEqualTo(110823);
//    }

}
