/**
 * Copyright School of Informatics Xiamen University
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/

package cn.edu.xmu.oomall.publictest;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.time.Duration;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@SpringBootTest(classes = PublicTestApp.class)   //标识本类是一个SpringBootTest
public abstract class BaseTestOomall implements InitializingBean {

    @Value("${public-test.gateway-gate}")
    protected String gateway;

    @Value("${public-test.mall-gate}")
    protected String mall;

    protected WebTestClient gatewayClient;

    protected WebTestClient mallClient;

    private static final JwtHelper jwtHelper = new JwtHelper();

    private static final String CUSTOMERTEMP = "{\"userName\":\"%s\",\"password\":\"%s\"}";
    private static final String CUSTOMERLOGIN ="/customer/login";

    private static final Pattern pattern  = Pattern.compile("\\d+$");

    private static Long getEndNum(String str){
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()){
            Long num = Long.parseLong(matcher.group());

            return num;
        }else{
            return null;
        }

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        this.gatewayClient = WebTestClient.bindToServer()
                .responseTimeout(Duration.ofSeconds(10))
                .baseUrl("http://"+gateway)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, "application/json;charset=UTF-8")
                .build();

        this.mallClient = WebTestClient.bindToServer()
                .responseTimeout(Duration.ofSeconds(10))
                .baseUrl("http://"+mall)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, "application/json;charset=UTF-8")
                .build();

    }

    protected String adminLogin(String userName, String password){
        Long departId = getEndNum(userName);
        if (null != departId){
            return jwtHelper.createToken(departId, userName, departId, 1, 3600);
        }else {
            return jwtHelper.createToken(1L, userName, 0L, 1, 3600);
        }
    }

    protected String getNoTokenAdmin1(String userName, String password){
        return jwtHelper.createToken(100L, userName, -1L, 1, 3600);
    }

    protected String getNoTokenAdmin2(String userName, String password){
        return jwtHelper.createToken(101L, userName, -1L, 1, 3600);
    }

    protected String customerLogin(String userName, String password){
        Long departId = getEndNum(userName);
        if (null != departId){
            return jwtHelper.createToken(departId, userName, -100L, 1, 3600);
        }else {
            return jwtHelper.createToken(1L, userName, -100L, 1, 3600);
        }
    }

}
