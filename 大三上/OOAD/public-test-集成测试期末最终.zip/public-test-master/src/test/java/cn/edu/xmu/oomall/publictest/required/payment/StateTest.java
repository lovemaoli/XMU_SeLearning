//School of Informatics Xiamen University, GPL-3.0 license

package cn.edu.xmu.oomall.publictest.required.payment;

import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class StateTest extends BaseTestOomall {

    private static final String PAYSTATE = "/payment/payments/states";
    private static final String REFUNDSTATE = "/payment/refund/states";
    /**
     * 支付交易状态
     * @author shiyuhao
     * @throws Exception
     */
    @Test
    public void getPaymentStates() throws Exception {
        this.mallClient.get().uri(PAYSTATE)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.length()").isEqualTo(6)
                .jsonPath("$.data[?(@.code == '0')].name").isEqualTo("待支付")
                .jsonPath("$.data[?(@.code == '1')].name").isEqualTo("已支付")
                .jsonPath("$.data[?(@.code == '3')].name").isEqualTo("错账")
                .jsonPath("$.data[?(@.code == '4')].name").isEqualTo("支付失败")
                .jsonPath("$.data[?(@.code == '5')].name").isEqualTo("取消")
                .jsonPath("$.data[?(@.code == '7')].name").isEqualTo("分账");
    }

    /**
     * 退款交易状态
     * @author shiyuhao
     * @throws Exception
     */
    @Test
    public void getRefundStates() throws Exception {
        this.mallClient.get().uri(REFUNDSTATE)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.length()").isEqualTo(4)
                .jsonPath("$.data[?(@.code == '0')].name").isEqualTo("待退款")
                .jsonPath("$.data[?(@.code == '1')].name").isEqualTo("已退款")
                .jsonPath("$.data[?(@.code == '3')].name").isEqualTo("错账")
                .jsonPath("$.data[?(@.code == '4')].name").isEqualTo("退款失败");
    }




}
