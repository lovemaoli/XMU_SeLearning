package cn.edu.xmu.oomall.publictest.required.shop;


import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.JacksonUtil;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Objects;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ShopTest extends BaseTestOomall {

    private static final String SHOPSTATE = "/shop/shops/states";
    private static final String SHOPID = "/shop/shops/{id}";
    private static final String ADMINSHOP = "/shop/shops/{id}/shops";
    private static final String POSTSHOP = "/shop/shops";
    private static final String CUSTOMERSHOP = "/shop/shops";
    private static final String AUDITSHOP = "/shop/shops/{shopId}/audit";   //旧API为1.1.7版本，更新为1.3.2版
    private static final String ONLINESHOP = "/shop/shops/{id}/online";
    private static final String OFFLINESHOP = "/shop/shops/{id}/offline";

    private static Long shop1Id = null;

    @Test
    public void getShopState() throws Exception{
        this.mallClient.get().uri(SHOPSTATE)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.length()").isEqualTo(4)
                .jsonPath("$.data[?(@.code == '0')].name").isEqualTo("申请")
                .jsonPath("$.data[?(@.code == '1')].name").isEqualTo("下线")
                .jsonPath("$.data[?(@.code == '2')].name").isEqualTo("上线")
                .jsonPath("$.data[?(@.code == '3')].name").isEqualTo("停用");
    }

    /**
     * 获得商铺信息
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    public void testGetShop() throws Exception{
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(SHOPID,1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(1)
                .jsonPath("$.data.name").isEqualTo("OOMALL自营商铺");
    }

    /**
     * 顾客查询商铺信息(不带参数，返回所有上线和下线态商铺)
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    public void testGetCustomerShopWithoutParam() throws Exception{
        this.mallClient.get().uri(CUSTOMERSHOP+"?page=1&pageSize=40")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.data.list[?(@.id == '1')].name").value(hasItem("OOMALL自营商铺"))
                .jsonPath("$.data.list[?(@.id == '2')].name").value(hasItem("甜蜜之旅"))
                .jsonPath("$.data.list[?(@.id == '3')].name").value(hasItem("向往时刻"))
                .jsonPath("$.data.list[?(@.id == '4')].name").value(hasItem("努力向前"))
                .jsonPath("$.data.list[?(@.id == '5')].name").value(hasItem("坚持就是胜利"))
                .jsonPath("$.data.list[?(@.id == '6')].name").value(hasItem("一口气"))
                .jsonPath("$.data.list[?(@.id == '7')].name").value(hasItem("商铺7"));
    }

    /**
     * 顾客查询商铺信息(带参数，返回指定可查询商铺)
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    public void testGetCustomerShopWithParam() throws Exception{
        this.mallClient.get().uri(CUSTOMERSHOP+"name=OOMALL自营商铺&?page=1&pageSize=40")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.data.list.length()").isEqualTo(1)
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '1')].name").value(hasItem("OOMALL自营商铺"));
    }

    /**
     * 不能查询不存在的商铺
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    public void testGetShopGivenNotExistId() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.get().uri(SHOPID,1221333)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 非平台管理员获取商户信息
     * @author hyx
     * @throws Exception
     */
    @Test
    public void testGetShopGivenWrongUser() throws Exception{
        String token = this.adminLogin("1111", "123456");
        this.gatewayClient.get().uri(SHOPID,1)
                .header("authorization", token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 平台管理员查询商铺(返回所有状态)
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(10)
    public void testGetAdminShop() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(ADMINSHOP+"?page=1&pageSize=40",0)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '1')].name").value(hasItem("OOMALL自营商铺"))
                .jsonPath("$.data.list[?(@.id == '2')].name").value(hasItem("甜蜜之旅"))
                .jsonPath("$.data.list[?(@.id == '3')].name").value(hasItem("向往时刻"))
                .jsonPath("$.data.list[?(@.id == '4')].name").value(hasItem("努力向前"))
                .jsonPath("$.data.list[?(@.id == '5')].name").value(hasItem("坚持就是胜利"))
                .jsonPath("$.data.list[?(@.id == '6')].name").value(hasItem("一口气"))
                .jsonPath("$.data.list[?(@.id == '7')].name").value(hasItem("商铺7"))
                .jsonPath("$.data.list[?(@.id == '8')].name").value(hasItem("商铺8"))
                .jsonPath("$.data.list[?(@.id == '9')].name").value(hasItem("商铺9"))
                .jsonPath("$.data.list[?(@.id == '10')].name").value(hasItem("商铺10"))
                .jsonPath("$.data.list[?(@.id == '45')].name").value(hasItem("停用商铺1"))
                .jsonPath("$.data.list[?(@.id == '71')].name").value(hasItem("停用商铺2"))
                .jsonPath("$.data.list[?(@.id == '72')].name").value(hasItem("停用商铺3"))
                .jsonPath("$.data.list[?(@.id == '73')].name").value(hasItem("停用商铺4"));
    }

    /**
     * 平台管理员查询所有废弃商铺
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(10)
    public void testGetAdminShopWithParam() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(ADMINSHOP+"status=3?page=1&pageSize=40",0)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '45')].name").value(hasItem("停用商铺1"))
                .jsonPath("$.data.list[?(@.id == '71')].name").value(hasItem("停用商铺2"))
                .jsonPath("$.data.list[?(@.id == '72')].name").value(hasItem("停用商铺3"))
                .jsonPath("$.data.list[?(@.id == '73')].name").value(hasItem("停用商铺4"));
    }

    /**
     * 非平台管理员
     * @throws Exception
     */
    @Test
    public void getAdminShopGivenWrongUser() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(ADMINSHOP+"?page=1&pageSize=20",1)
                .header("authorization",token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 商户开铺时给出的信息为空
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    public void testPostShopWithBlankName() throws Exception{
        String token = this.adminLogin("zhy123", "123456");
        String json = "{\"consignee\":{\"name\":\"新开铺\", \"mobile\":\"1233456\", \"regionId\":517935, \"address\":\"北海大道中26号鸿海大厦210室\"}}";
        this.gatewayClient.post().uri(POSTSHOP)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 无店铺用户申请开店
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(20)
    public void testPostShopGivenUserWithoutDepartId() throws Exception{
        String token = this.getNoTokenAdmin2("zhy123", "123456");
        String json = "{\"name\":\"新开铺\", \"consignee\":{\"name\":\"zhy\", \"mobile\":\"1233456\", \"regionId\":517935, \"address\":\"北海大道中26号鸿海大厦210室\"}}";
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(POSTSHOP)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .jsonPath("$.data.name").isEqualTo("新开铺")
                .returnResult().getResponseBody()),"UTF-8");


        shop1Id = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        //判断为店铺为申请状态
        String token1 = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token1)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(0);
    }

    /**
     * 有店铺用户不能再开店
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    public void testPostShopGivenUserWithDepartId() throws Exception{
        String token = this.adminLogin("admin1", "123456");
        String json =  "{\"name\":\"新开铺001\", \"consignee\":{\"name\":\"admin1\", \"mobile\":\"123345687\", \"regionId\":517, \"address\":\"北海大道中26号鸿海大厦211室\"}}";
        this.gatewayClient.post().uri(POSTSHOP)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.SHOP_USER_HASSHOP.getErrNo());
    }

    /**
     * 平台管理员不能开店
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    public void testPostShopGivenWhenUserIsAdmin() throws Exception{
        String token = this.adminLogin("13088admin", "123456");
        String json =  "{\"name\":\"平台管理员的店铺\", \"consignee\":{\"name\":\"13088admin\", \"mobile\":\"1233456\", \"regionId\":517935, \"address\":\"北海大道中26号鸿海大厦210室\"}}";
        this.gatewayClient.post().uri(POSTSHOP)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.SHOP_USER_HASSHOP.getErrNo());
    }

    /**
     * 企图修改不属于自己的商铺
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(30)
    public void testPutShopGivenWrongUser() throws Exception {
        assertNotNull(shop1Id);
        String shopToken = this.adminLogin("shop1", "123456");
        String requestJson = "{\"consignee\":{\"mobile\":\"654321\"}}";
        this.gatewayClient.put().uri(SHOPID, shop1Id)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

        //验证信息未被修改
        this.mallClient.get().uri(SHOPID, shop1Id)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.consignee.name").isEqualTo("654321");
    }

    /**
     * 不存在的商铺
     */
    @Test
    public void putShopGivenNonExistId() throws Exception {
        String shopToken = this.adminLogin("13088admin", "123456");
        String requestJson = "{\"freeThreshold\": 1000}";
        this.gatewayClient.put().uri(SHOPID, 122200)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 修改商铺信息给出空字段
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    public void testPutShopGivenBlankName() throws Exception {
        String shopToken = this.adminLogin("13088admin", "123456");
        String requestJson = "{\"consignee\":{\"name\":\"\", \"mobile\":\"111111111\"}}";
        this.gatewayClient.put().uri(SHOPID, 1)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }


    /**
     * 平台管理员审核不通过
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(40)
    public void testAuditShopGivenRefuse() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        String requestJson = "{\"conclusion\": false}";
        this.gatewayClient.put().uri(AUDITSHOP, shop1Id)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        //验证店铺状态仍为申请态
        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(0);
    }


    /**
     * 非平台管理员不能审核
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(40)
    public void testAuditShopGivenNonPlatformUser() throws Exception {
        assertNotNull(shop1Id);
        String shopToken = this.adminLogin("shop1", "123456");
        String requestJson = "{\"conclusion\": true}";
        this.gatewayClient.put().uri(AUDITSHOP, shop1Id)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

        //验证店铺状态仍为申请态
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(0);
    }

    /**
     * 平台管理员上线未审核的店铺
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(40)
    public void testOnlineShopWithUnauditShop() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(ONLINESHOP, shop1Id)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        //验证店铺状态仍为申请态
        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(0);
    }
    /**
     * 平台管理员下线未审核的店铺
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(40)
    public void testOfflineShopWithUnauditShop() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(OFFLINESHOP, shop1Id)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        //验证店铺状态仍为申请态
        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(0);
    }

    /**
     * 平台管理员审核通过
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(50)
    public void testAuditShopWithApprove() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        String requestJson = "{\"conclusion\": true}";
        this.gatewayClient.put().uri(AUDITSHOP, shop1Id)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(1);
    }

    /**
     * 不能审核不存在的商铺
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    public void testAuditShopGivenNonExistShop() throws Exception {
        String shopToken = this.adminLogin("13088admin", "123456");
        String requestJson = "{\"conclusion\": true}";
        this.gatewayClient.put().uri(AUDITSHOP, 12200)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    
    /**
     * 平台管理员审核商铺 缺少必填属性conclusion
     * @throws Exception
     * @author hyx
     */
    @Test
    @Order(50)
    public void testAuditShopGivenApproveAndLack() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        String requestJson = "{\"conclusion\":}";
        this.gatewayClient.put().uri(AUDITSHOP, shop1Id)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 修改审核通过的商铺的名字
     * 企图修改商铺的id
     */
    @Test
    @Order(60)
    public void putShop() throws Exception{
        assertNotNull(this.shop1Id);
        String shopToken = this.adminLogin("13088admin","123456");
        String requestJson = "{\"freeThreshold\": 1000}";
        this.gatewayClient.put().uri(SHOPID,this.shop1Id)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.mallClient.get().uri(SHOPID,this.shop1Id)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(this.shop1Id.intValue())
                .jsonPath("$.data.freeThreshold").isEqualTo(1000);
    }

    /**
     * 非平台管理员
     */
    @Test
    @Order(70)
    public void onlineShopGivenWrongUser() throws Exception {
        assertNotNull(this.shop1Id);
        String shopToken = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(ONLINESHOP, this.shop1Id)
                .contentType(MediaType.APPLICATION_JSON)
                .header("authorization", shopToken)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 不存在的商铺
     */
    @Test
    public void onlineShopGivenNonExistShop() throws Exception {
        String shopToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(ONLINESHOP, 12200)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 平台管理员上线
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(80)
    public void testOnlineShop() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(ONLINESHOP, shop1Id)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        //验证商铺为上线态
        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(2);
    }

    /**
     * 平台管理员或店家不能关闭非下线态的商铺
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(85)
    public void testDelShopGivenWrongStatus() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.delete().uri(SHOPID, shop1Id)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(2);
    }

    /**
     * 平台管理员不能审核非申请态的店铺
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(90)
    public void testAuditShopWithOnlineShop() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        String requestJson = "{\"conclusion\": true}";
        this.gatewayClient.put().uri(AUDITSHOP, shop1Id)
                .header("authorization", token)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        //验证商铺状态不变
        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(2);
    }

    /**
     * 非平台管理员
     */
    @Test
    @Order(90)
    public void offlineShopGivenWrongUser() throws Exception {
        assertNotNull(this.shop1Id);
        String shopToken = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(OFFLINESHOP, this.shop1Id)
                .header("authorization", shopToken)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 不存在的商铺
     */
    @Test
    public void offlineShopGivenNonExistShop() throws Exception {
        String shopToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(OFFLINESHOP, 123234)
                .header("authorization", shopToken)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * 平台管理员下线
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(100)
    public void testOfflineShop() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(OFFLINESHOP, shop1Id)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(1);
    }

    /**
     * 非平台管理员
     */
    @Test
    @Order(150)
    public void dellineShopGivenWrongUser() throws Exception {
        assertNotNull(this.shop1Id);
        String shopToken = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOPID, this.shop1Id)
                .header("authorization", shopToken)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 不存在的商铺
     */
    @Test
    public void delShopTestGivenNonExistShop() throws Exception {
        String shopToken = this.adminLogin("13088admin", "123456");
        this.gatewayClient.delete().uri(SHOPID, 18996)
                .header("authorization", shopToken)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     *  平台管理员关闭下线态商店
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(160)
    public void testDelShopTest() throws Exception {
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.delete().uri(SHOPID, shop1Id)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(3);
    }

    /**
     *  关闭态(停用)商店不能修改信息
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(165)
    public void testPutShopAfterDelete() throws Exception {
        assertNotNull(shop1Id);
        String shopToken = this.adminLogin("13088admin", "123456");
        String requestJson = "{\"freeThreshold\": 1000}";
        this.gatewayClient.put().uri(SHOPID, shop1Id)
                .header("authorization", shopToken)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",shopToken)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(3);
    }

    /**
     * 上线态商铺只能由下线态转化来（停用态不能恢复为上线态）
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(165)
    public void testOnlineShopAfterDelete() throws Exception{
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(ONLINESHOP, shop1Id)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(3);
    }

    /**
     * 下线态商铺只能由上线态转化来（停用态不能恢复为下线态）
     * @author Zenghongyong
     * @throws Exception
     */
    @Test
    @Order(165)
    public void testOfflineShopAfterDelete() throws Exception{
        assertNotNull(shop1Id);
        String token = this.adminLogin("13088admin", "123456");
        this.gatewayClient.put().uri(OFFLINESHOP, shop1Id)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());

        this.gatewayClient.get().uri(SHOPID,shop1Id)
                .header("authorization",token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(shop1Id)
                .jsonPath("$.data.status").isEqualTo(3);
    }

}
