package cn.edu.xmu.oomall.publictest.required.freight;

import cn.edu.xmu.oomall.publictest.JacksonUtil;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;

import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.ReturnNo;

import java.nio.charset.StandardCharsets;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class FreightTest extends BaseTestOomall {

    private String SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID = "/freight/shops/{shopId}/warehouses/{id}/shoplogistics/{lid}";
    private String SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC = "/freight/shops/{shopId}/warehouses/{id}/shoplogistics";
    private String SHOP_ID_WAREHOUSE = "/freight/shops/{shopId}/warehouses";

    private Long warehouseId = null;

    /**
     * @author maguoqi
     * 商户新建仓库物流 - 商铺不存在
     */
    @Test
    public void testAddWarehouseShopLogisticWhenShopNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";

        this.gatewayClient.post().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 93123L, 1L, 1L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户新建物流 - 仓库不存在
     */
    @Test
    public void testAddWarehouseShopLogisticWhenWarehouseNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";
        this.gatewayClient.post().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 31233L, 1L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus()
                .isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户新建仓库物流 - 商铺物流不存在
     */
    @Test
    public void testAddWarehouseShopLogisticWhenShopLogisticNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";

        this.gatewayClient.post().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 2L, 2L, 133399L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户新建仓库物流 - 该仓库不属于原商铺
     */
    @Test
    public void testAddWarehouseShopLogisticWhenWarehouseNotBelongToShop() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";

        this.gatewayClient.post().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 22L, 1L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户新建仓库物流 - 该商铺物流不属于原商铺
     */
    @Test
    public void testAddWarehouseShopLogisticWhenShopLogisticNotBelongToShop() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";

        this.gatewayClient.post().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 1L, 10L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户新建仓库物流 - 重复添加
     */
    @Test
    public void testAddWarehouseShopLogisticWhenWarehouseLogisticExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";
        this.gatewayClient.post().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 25L, 1)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FREIGHT_WAREHOUSELOGISTIC_EXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户获取仓库物流 - 商铺不存在
     */
    @Test
    public void testGetWarehouseShopLogisticWhenShopNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC, 93123L, 1L)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户获取仓库物流 - 仓库不存在
     */
    @Test
    public void testGetWarehouseShopLogisticWhenWarehouseNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC, 1L, 993L)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户新建仓库 - 成功
     */
    @Test
    @Order(1)
    public void testAddWarehouse() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\n" +
                "  \"name\": \"\"冯唐仓库,\n" +
                "  \"address\": \"河北,邢台,内丘,大孟村,冯唐曙光路16号\",\n" +
                "  \"regionId\": 33762,\n" +
                "  \"senderName\": \"李四\",\n" +
                "  \"senderMobile\": \"13970708820\",\n" +
                "  \"priority\": 1000\n" +
                "}";
        String ret = new String(
                Objects.requireNonNull(
                        this.gatewayClient.post().uri(SHOP_ID_WAREHOUSE, 10L)
                                .header("authorization", token)
                                .bodyValue(body)
                                .exchange()
                                .expectStatus().isCreated()
                                .expectBody()
                                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                                .jsonPath("$.data.name").isEqualTo("冯唐仓库")
                                .returnResult().getResponseBody()),
                StandardCharsets.UTF_8);

        this.warehouseId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);
    }

    /**
     * @author maguoqi
     * 商户获取仓库物流 - 极限值测试 - 该仓库建立的物流为0
     * 必须在`testAddWarehouse`之后执行测试
     */
    @Test
    @Order(2)
    public void testGetWarehouseShopLogisticWhenShopLogisticNotExist() throws Exception {
        assertNotNull(this.warehouseId);

        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC, 10L, this.warehouseId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(0);
    }

    /**
     * @author maguoqi
     * 商户获取仓库物流 - 该仓库不属于原商铺
     */
    @Test
    public void testGetWarehouseShopLogisticWhenWarehouseNotBelongToShop() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.get().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC, 1L, 22L, 1L)
                .header("authorization", token)
                .exchange()
                .expectStatus().is4xxClientError()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户修改仓库物流 - 成功
     */
    @Test
    public void testAlterWarehouseShopLogistic() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";

        this.gatewayClient.put().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 10L, 22L, 908L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户修改仓库物流 - 商铺不存在
     */
    @Test
    public void testAlterWarehouseShopLogisticWhenShopNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";

        this.gatewayClient.put().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 93123L, 1L, 1L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户修改仓库物流 - 仓库不存在
     */
    @Test
    public void testAlterWarehouseShopLogisticWhenWarehouseNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";
        this.gatewayClient.put().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 993L, 1L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange().expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户修改仓库物流 - 仓库物流不存在
     */
    @Test
    public void testAlterWarehouseShopLogisticWhenShopLogisticNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";

        this.gatewayClient.put().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 10L, 2L, 991L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户修改仓库物流 - 该仓库不属于原商铺
     */
    @Test
    public void testAlterWarehouseShopLogisticWhenWarehouseNotBelongToShop() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";

        this.gatewayClient.put().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 22L, 1L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().is4xxClientError()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户修改仓库物流 - 该仓库物流不属于原仓库
     */
    @Test
    public void testAlterWarehouseShopLogisticWhenWarehouseLogisticNotBelongToWarehouse() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        String body = "{\"beginTime\":\"2020-11-11T11:11:11\", \"endTime\":\"2030-12-12T12:12:12\"}";

        this.gatewayClient.put().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 1L, 806L)
                .header("authorization", token)
                .bodyValue(body)
                .exchange()
                .expectStatus().is4xxClientError()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户删除仓库物流 - 成功
     */
    @Test
    public void testDeleteWarehouseShopLogistic() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 10L, 22L, 908L)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户删除仓库物流 - 商铺不存在
     */
    @Test
    public void testDeleteWarehouseShopLogisticWhenShopNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 93123L, 1L, 1L)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户删除仓库物流 - 仓库不存在
     */
    @Test
    public void testDeleteWarehouseShopLogisticWhenWarehouseNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 993L, 1L)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户删除仓库物流 - 仓库物流不存在
     */
    @Test
    public void testDeleteWarehouseShopLogisticWhenShopLogisticNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 10L, 2L, 991L)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户删除仓库物流 - 该仓库不属于原商铺
     */
    @Test
    public void testDeleteWarehouseShopLogisticWhenWarehouseNotBelongToShop() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 22L, 1L)
                .header("authorization", token)
                .exchange()
                .expectStatus().is4xxClientError()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author maguoqi
     * 商户删除仓库物流 - 该仓库物流不属于原仓库
     */
    @Test
    public void testDeleteWarehouseShopLogisticWhenWarehouseLogisticNotBelongToWarehouse() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOP_ID_WAREHOUSE_ID_SHOPLOGISTIC_ID, 1L, 1L, 806L)
                .header("authorization", token)
                .exchange()
                .expectStatus().is4xxClientError()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

}
