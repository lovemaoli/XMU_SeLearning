//School of Informatics Xiamen University, GPL-3.0 license

package cn.edu.xmu.oomall.publictest.required.payment;

import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.JacksonUtil;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import java.util.Objects;

import static org.hamcrest.Matchers.hasItem;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ChannelTest extends BaseTestOomall {

    private static final String CHANNELS = "/payment/channels";
    private static final String VALIDCHANNEL = "/payment/shops/{shopId}/channels/{id}/valid";
    private static final String INVALIDCHANNEL = "/payment/shops/{shopId}/channels/{id}/invalid";
    private static final String SHOPCHANNEL = "/payment/shops/{shopId}/shopchannels";
    private static final String POSTSHOPCHANNEL = "/payment/shops/{shopId}/channels/{id}/shopchannels";
    private static final String SHOPCHANNELID = "/payment/shops/{shopId}/shopchannels/{id}";
    private static final String VALIDSHOPCHANNELID = "/payment/shops/{shopId}/shopchannels/{id}/valid";
    private static final String INVALIDSHOPCHANNELID = "/payment/shops/{shopId}/shopchannels/{id}/invalid";

    private static Long shop7ChannelId = null;//临时验证使用

    /**
     * 获得初始情况下平台的支付渠道
     *
     * @throws Exception
     * @Author Xu Huang
     */
    @Test
    @Order(0)
    public void givenPlatformGetChannels() throws Exception {
        this.mallClient.get().uri(CHANNELS + "?shopId=0")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2); // 初始状态下有微信和支付宝
    }

    /**
     * 获得shop7初始情况下的有效支付渠道 - 顾客通道
     *
     * @throws Exception
     * @Author Xu Huang
     */
    @Test
    @Order(0)
    public void givenShop7GetChannels() throws Exception {
        this.mallClient.get().uri(CHANNELS + "?shopId=7")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(1); //初始状态下shop7签约了支付宝
    }

    /**
     * 获得shop7初始情况下的所有支付渠道 - 商铺通道
     *
     * @throws Exception
     * @auther Xu Huang
     */
    @Test
    @Order(0)
    public void givenShop7GetChannelsAdmin() throws Exception {
        String token = this.adminLogin("shop7", "123456");
        this.gatewayClient.get().uri(SHOPCHANNEL, 7)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(1); //初始状态下shop7签约了支付宝
    }

    /**
     * shop7签约微信（支付宝初始时已签约）
     * 微信和支付宝渠道后续测试均需用到
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(13)
    public void testPostShopChannel() throws Exception {
        String token = this.adminLogin("shop7", "123456");
        String json = "{\"subMchid\": \"test1234\"}";

        // 签约微信支付(501)
        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(POSTSHOPCHANNEL, 7, 501)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .jsonPath("$.data.subMchid").isEqualTo("test1234")
                .jsonPath("$.data.status").isEqualTo(1)
                .returnResult().getResponseBody()), "UTF-8");

        this.shop7ChannelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

    }

    /**
     * shop7签约微信 不能签约已签约的支付渠道
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(14)
    public void testPostShopChannelGivenExistChannelWechat() throws Exception {
        String token = this.adminLogin("shop7", "123456");
        String json = "{\"subMchid\": \"test\"}";

        this.gatewayClient.post().uri(POSTSHOPCHANNEL, 7, 501)
                .header("authorization", token)
                .bodyValue(json)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.PAY_CHANNEL_EXIST.getErrNo());
    }


    /**
     * @author Huanjia Zhang
     * 获得商铺支付渠道 成功
     */
    @Test
    public void testGetShopChannelsByIDGivenShopChannelNo() throws Exception {
        String token = this.adminLogin("shop7", "123456");
        this.gatewayClient.get().uri(SHOPCHANNELID, 7, 534)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.subMchid").isEqualTo("198887")
                .jsonPath("$.data.channel.name").isEqualTo("支付宝")
                .jsonPath("$.data.creator.name").isEqualTo("admin111");
    }

    /**
     * 获取shop7的支付渠道信息 - 其他用户无法获取
     *
     * @throws Exception
     * @Author Xu Huang
     */
    @Test
    @Order(15)
    public void getShopChannelsByIDGivenWrongId() throws Exception {
        String token = this.adminLogin("shop5", "123456");
        this.gatewayClient.get().uri(SHOPCHANNELID, 7, 501)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }


    /**
     * 签约后 - 获取shop7的支付渠道信息 - 不存在的支付渠道id
     *
     * @throws Exception
     * @Author Xu Huang
     */
    @Test
    @Order(15)
    public void getShopChannelsByIDGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop7", "123456");
        this.gatewayClient.get().uri(SHOPCHANNELID, 7, 56563)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());

    }

    /**
     * @author Huanjia Zhang
     * 商铺支付渠道生效 微信 成功
     */
    @Order(20)
    @Test
    public void testPutShop7Valid() throws Exception {
        String token = this.adminLogin("shop7", "123456");

        this.gatewayClient.put().uri(VALIDSHOPCHANNELID, 7, this.shop7ChannelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
        //验证
        this.mallClient.get().uri(CHANNELS + "?shopId=7")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2)
                .jsonPath("$.data.list[?(@.id == '501')].name").isEqualTo("微信支付")
                .jsonPath("$.data.list[?(@.id == '501')].beginTime").isEqualTo("2022-05-02T18:49:48")
                .jsonPath("$.data.list[?(@.id == '501')].endTime").isEqualTo("2099-11-02T18:49:56")
                .jsonPath("$.data.list[?(@.id == '501')].status").isEqualTo(0)
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].beginTime").isEqualTo("2022-12-17T17:19:03")
                .jsonPath("$.data.list[?(@.id == '502')].endTime").isEqualTo("2033-12-17T17:19:07")
                .jsonPath("$.data.list[?(@.id == '502')].status").isEqualTo(0);
    }

    /**
     * 不能删除当前生效的支付渠道
     * shop7微信渠道在前一个测试中生效
     *
     * @throws Exception
     * @Author Xu Huang
     */
    @Test
    @Order(21)
    void testDelShopChannelValidForFailed() throws Exception {
        String token = this.adminLogin("shop7", "123456");

        this.gatewayClient.delete().uri(SHOPCHANNELID, 7, 501)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden() // 不能删除应返回403
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }

    /**
     * 商铺支付渠道生效 - 其他商铺无法开通
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(21)
    public void testPutShop7ValidGivenWrongId() throws Exception {
        String token = this.adminLogin("shop6", "123456");

        this.gatewayClient.put().uri(VALIDSHOPCHANNELID, 7, 543)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

    }

    /**
     * 商铺支付渠道生效 - 不存在的渠道id
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(21)
    public void testPutShop7ValidGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop7", "123456");

        this.gatewayClient.put().uri(VALIDSHOPCHANNELID, 7, 543222)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺支付渠道失效 - 微信
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(23)
    public void testPutShop7InValidWechat() throws Exception { // 修正函数名冲突
        String token = this.adminLogin("shop7", "123456");

        this.gatewayClient.put().uri(INVALIDSHOPCHANNELID, 7, this.shop7ChannelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
        //验证
        this.gatewayClient.get().uri(CHANNELS + "?shopId=7")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(1)  // 仍然有1个支付渠道：502
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].status").isEqualTo(0);
    }

    /**
     * @author Huanjia Zhang
     * 商铺支付渠道失效 支付宝 成功
     */
    @Order(21)
    @Test
    public void testPutShop7InValid() throws Exception {
        String token = this.adminLogin("shop7", "123456");

        this.gatewayClient.put().uri(INVALIDSHOPCHANNELID, 7, 534)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
        //恢复
        this.gatewayClient.put().uri(VALIDSHOPCHANNELID, 7, 534)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * 商铺支付渠道失效 - 其他商铺无法操作
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(22)
    public void testPutShop7InValidGivenWrongUser() throws Exception {
        String token = this.adminLogin("shop6", "123456");

        this.gatewayClient.put().uri(INVALIDSHOPCHANNELID, 7, 501)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());

    }

    /**
     * 商铺支付渠道失效 - 不存在的渠道id
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(22)
    public void testPutShop7InValidGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop7", "123456");

        this.gatewayClient.put().uri(INVALIDSHOPCHANNELID, 7, 543222)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 平台支付渠道失效 微信 成功
     */
    @Order(22)
    @Test
    public void testPutChannelInValid() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(INVALIDCHANNEL, 0, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
        //验证 微信关闭后平台支持的支付渠道
        this.mallClient.get().uri(CHANNELS + "?shopId=0")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].beginTime").isEqualTo("2022-12-17T17:19:03")
                .jsonPath("$.data.list[?(@.id == '502')].endTime").isEqualTo("2033-12-17T17:19:07");
        //验证 微信关闭后商铺1支持的支付渠道
        this.mallClient.get().uri(CHANNELS + "?shopId=1")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(1)
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].beginTime").isEqualTo("2022-12-17T17:19:03")
                .jsonPath("$.data.list[?(@.id == '502')].endTime").isEqualTo("2033-12-17T17:19:07");
    }

    /**
     * @author Huanjia Zhang
     * 平台支付渠道失效 支付宝 关闭失败
     */
    @Order(22)
    @Test
    public void testPutChannelInValid1() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(INVALIDCHANNEL, 0, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
        //验证 接着支付宝关闭失败后平台支持的支付渠道
        this.mallClient.get().uri(CHANNELS + "?shopId=0")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].beginTime").isEqualTo("2022-12-17T17:19:03")
                .jsonPath("$.data.list[?(@.id == '502')].endTime").isEqualTo("2033-12-17T17:19:07");
        //验证 接着支付宝关闭后商铺1支持的支付渠道
        this.mallClient.get().uri(CHANNELS + "?shopId=1")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].beginTime").isEqualTo("2022-12-17T17:19:03")
                .jsonPath("$.data.list[?(@.id == '502')].endTime").isEqualTo("2033-12-17T17:19:07");
    }

    /**
     * 平台支付渠道失效 - 其他用户无法操作
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(30)
    public void testPutChannelInValidGivenWrongUser() throws Exception {
        String token = this.adminLogin("shop6", "123456");
        this.gatewayClient.put().uri(INVALIDCHANNEL, 7, 502)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 平台支付渠道失效 平台支付渠道不存在
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(30) //改正测试顺序
    public void testPutChannelInValidGivenNonExistId() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(INVALIDCHANNEL, 0, 4533)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 平台支付渠道生效 微信 成功
     */
    @Order(23) //与Order(22)对应
    @Test
    public void testPutChannelValid() throws Exception {
        //目前微信无效、支付宝有效
        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.put().uri(VALIDCHANNEL, 0, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
        //验证
        this.mallClient.get().uri(CHANNELS + "?shopId=0")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2)
                .jsonPath("$.data.list[?(@.id == '501')].name").isEqualTo("微信支付")
                .jsonPath("$.data.list[?(@.id == '501')].beginTime").isEqualTo("2022-05-02T18:49:48")
                .jsonPath("$.data.list[?(@.id == '501')].endTime").isEqualTo("2099-11-02T18:49:56")
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].beginTime").isEqualTo("2022-12-17T17:19:03")
                .jsonPath("$.data.list[?(@.id == '502')].endTime").isEqualTo("2033-12-17T17:19:07");

        this.mallClient.get().uri(CHANNELS + "?shopId=1")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2)
                .jsonPath("$.data.list[?(@.id == '501')].name").isEqualTo("微信支付")
                .jsonPath("$.data.list[?(@.id == '501')].beginTime").isEqualTo("2022-05-02T18:49:48")
                .jsonPath("$.data.list[?(@.id == '501')].endTime").isEqualTo("2099-11-02T18:49:56")
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].beginTime").isEqualTo("2022-12-17T17:19:03")
                .jsonPath("$.data.list[?(@.id == '502')].endTime").isEqualTo("2033-12-17T17:19:07");
    }

    /**
     * @author Huanjia Zhang
     * 平台支付渠道生效 支付宝 已经有效
     */
    @Order(23)
    @Test
    public void testPutChannelValid1() throws Exception {
        //目前支付宝有效
        String token = this.adminLogin("admin", "123456");

        this.gatewayClient.put().uri(VALIDCHANNEL, 0, 501)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
        //验证
        this.mallClient.get().uri(CHANNELS + "?shopId=0")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2)
                .jsonPath("$.data.list[?(@.id == '501')].name").isEqualTo("微信支付")
                .jsonPath("$.data.list[?(@.id == '501')].beginTime").isEqualTo("2022-05-02T18:49:48")
                .jsonPath("$.data.list[?(@.id == '501')].endTime").isEqualTo("2099-11-02T18:49:56")
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].beginTime").isEqualTo("2022-12-17T17:19:03")
                .jsonPath("$.data.list[?(@.id == '502')].endTime").isEqualTo("2033-12-17T17:19:07");

        this.mallClient.get().uri(CHANNELS + "?shopId=1")
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2)
                .jsonPath("$.data.list[?(@.id == '501')].name").isEqualTo("微信支付")
                .jsonPath("$.data.list[?(@.id == '501')].beginTime").isEqualTo("2022-05-02T18:49:48")
                .jsonPath("$.data.list[?(@.id == '501')].endTime").isEqualTo("2099-11-02T18:49:56")
                .jsonPath("$.data.list[?(@.id == '502')].name").isEqualTo("支付宝")
                .jsonPath("$.data.list[?(@.id == '502')].beginTime").isEqualTo("2022-12-17T17:19:03")
                .jsonPath("$.data.list[?(@.id == '502')].endTime").isEqualTo("2033-12-17T17:19:07");
    }

    /**
     * 平台支付渠道生效 - 其他用户无法操作
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(35)
    public void testPutChannelValidGivenWrongUser() throws Exception {
        String token = this.adminLogin("shop6", "123456");
        this.gatewayClient.put().uri(VALIDCHANNEL, 7, 501)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 平台支付渠道生效 平台支付渠道不存在
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(35) //改正测试顺序
    public void testPutChannelValidGivenNonExistId() throws Exception {
        String token = this.adminLogin("admin", "123456");
        this.gatewayClient.put().uri(VALIDCHANNEL, 0, 4533)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 解约店铺的账户 - 其他用户无法操作
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(50)
    public void testDelShopChannelGivenWrongShop() throws Exception {
        String token = this.adminLogin("shop6", "123456");

        this.gatewayClient.delete().uri(SHOPCHANNELID, 7, 501)
                .header("authorization", token)
                .exchange().expectStatus().isForbidden()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 解约店铺的账户 - 渠道不存在
     *
     * @throws Exception
     * @author Xu Huang
     */
    @Test
    @Order(50)
    public void delShopChannelGivenNonExistId() throws Exception {
        String token = this.adminLogin("shop7", "123456");

        this.gatewayClient.delete().uri(SHOPCHANNELID, 7, 45454)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 删除商铺支付渠道 微信
     */
    @Order(25)
    @Test
    public void testDelShopChannelGivenWePay() throws Exception {

        String token = this.adminLogin("shop7", "123456");

        this.gatewayClient.delete().uri(SHOPCHANNELID, 7, this.shop7ChannelId)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
        //验证
        this.gatewayClient.get().uri(SHOPCHANNELID, 7, this.shop7ChannelId)
                .header("authorization", token)
                .exchange().expectStatus().isNotFound()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 删除支付渠道 不能解约已经解约的渠道 微信
     */
    @Test
    public void testDelShopChannelGivenWePay1() throws Exception {

        String token = this.adminLogin("shop6", "123456");
        //数据库中没有已经解约的数据，先解约
        this.gatewayClient.delete().uri(SHOPCHANNELID, 6, 543)
                .header("authorization", token)
                .exchange().expectStatus().isOk()//测试报错<500 INTERNAL_SERVER_ERROR>
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.delete().uri(SHOPCHANNELID, 6, 543)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }

    /**
     * @author Huanjia Zhang
     * 删除支付渠道 不能解约已经解约的渠道 支付宝
     */
    @Test
    public void testDelShopChannelGivenAliPay() throws Exception {

        String token = this.adminLogin("shop1", "123456");
        //数据库中没有已经解约的数据，先解约
        this.gatewayClient.delete().uri(SHOPCHANNELID, 1, 528)
                .header("authorization", token)
                .exchange().expectStatus().isOk()//测试报错<500 INTERNAL_SERVER_ERROR>
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.delete().uri(SHOPCHANNELID, 1, 528)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }

    /**
     * @author renyu
     * 尝试签约不存在的支付渠道
     */
    @Test
    @Order(13)
    public void testPostChannelGivenNonExistentChannelId() throws Exception {
        String token = this.adminLogin("shop7", "123456");
        String json = "{\"subMchid\": \"test1234\"}";

        this.gatewayClient.post().uri(POSTSHOPCHANNEL, 7, 9999)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author renyu
     * 签约支付渠道时缺少必要信息
     */
    @Test
    @Order(10)
    public void testCreatePaymentChannelGivenMissingInfo() throws Exception {
        String token = this.adminLogin("shop7", "123456");
        String json = "{}"; // 缺少subMchid等关键信息

        this.gatewayClient.post().uri(POSTSHOPCHANNEL, 7, 501)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange().expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

}
