/**
 * Copyright School of Informatics Xiamen University
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/

package cn.edu.xmu.oomall.publictest.required.shop;


import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.JacksonUtil;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class FreightTemplateTest extends BaseTestOomall {

    private static final String MODEL = "/shop/shops/{shopId}/templates";
    private static final String MODELID = "/shop/shops/{shopId}/templates/{id}";
    private static final String REGIONMODEL = "/shop/shops/{shopId}/templates/{id}/regions";
    private static final String WEIGHTMODEL = "/shop/shops/{shopId}/templates/{id}/regions/{rid}/weighttemplate";
    private static final String PIECEMODEL = "/shop/shops/{shopId}/templates/{id}/regions/{rid}/piecetemplates";
    private static final String CLONE = "/shop/shops/{shopId}/templates/{id}/clone";
    private static final String REGIONTEMPLATE = "/shop/shops/{shopId}/templates/{id}/regions/{rid}";
    private static final String DELMODEL = "/shop/shops/{shopId}/templates/{id}";
    private static final String CLONEREGION = "/shop/shops/{shopId}/templates/{id}/regions/{sid}/clone/regions/{rid}";
    private static Long weightMaxSimpleModelId = null;
    private static Long weightMaxBackPackModelId = null;
    private static Long weightAverageSimpleModelId = null;
    private static Long weightAverageBackPackModelId = null;
    private static Long weightGreedyModelId = null;
    private static Long weightOptimalModelId = null;
    private static Long pieceMaxSimpleModelId = null;
    private static Long pieceMaxBackPackModelId = null;
    private static Long pieceAverageSimpleModelId = null;
    private static Long pieceAverageBackPackModelId = null;
    private static Long pieceGreedyModelId = null;
    private static Long pieceOptimalModelId = null;
    private static Long cloneModelId = null;

    /**
     * 新增计重的运费模板
     * 最大分包简单打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostWeightTemplateGivenMaxSimple() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"最大分包简单打包计重模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 0," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.MaxDivideStrategy\"," +
                "\"packAlgorithm\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.SimpleAlgorithm\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        weightMaxSimpleModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, weightMaxSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(weightMaxSimpleModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("最大分包简单打包计重模板");

    }

    /**
     * 新增计重的运费模板
     * 最大分包背包打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostWeightTemplateGivenMaxBackPack() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"最大分包背包打包计重模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 0," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.MaxDivideStrategy\"," +
                "\"packAlgorithm\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.BackPackAlgorithm\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        weightMaxBackPackModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, weightMaxBackPackModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(weightMaxBackPackModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("最大分包背包打包计重模板");
    }

    /**
     * 新增计重的运费模板
     * 平均分包简单打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostWeightTemplateGivenAverageSimple() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"平均分包简单打包计重模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 0," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.AverageDivideStrategy\"," +
                "\"packAlgorithm\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.SimpleAlgorithm\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        weightAverageSimpleModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, weightAverageSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(weightAverageSimpleModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("平均分包简单打包计重模板");
    }

    /**
     * 新增计重的运费模板
     * 平均分包背包打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostWeightTemplateGivenAverageBackPack() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"平均分包背包打包计重模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 0," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.AverageDivideStrategy\"," +
                "\"packAlgorithm\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.SimpleAlgorithm\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        weightAverageBackPackModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, weightAverageBackPackModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(weightAverageBackPackModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("平均分包背包打包计重模板");
    }

    /**
     * 新增计重的运费模板
     * 贪心分包打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostWeightTemplateGivenGreedy() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"贪心计重模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 0," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.GreedyAverageDivideStrategy\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        weightGreedyModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, weightGreedyModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(weightGreedyModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("贪心计重模板");
    }

    /**
     * 新增计重的运费模板
     * 最优分包打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostWeightTemplateGivenOptimal() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"最优计重模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 0," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.OptimalDivideStrategy\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        weightOptimalModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, weightOptimalModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(weightOptimalModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("最优计重模板");
    }

    /**
     * 新增计件的运费模板
     * 最大分包简单打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostPieceTemplateGivenMaxSimple() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"最大分包简单打包计件模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 1," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.MaxDivideStrategy\"," +
                "\"packAlgorithm\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.SimpleAlgorithm\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        pieceMaxSimpleModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, pieceMaxSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(pieceMaxSimpleModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("最大分包简单打包计件模板");

    }

    /**
     * 新增计件的运费模板
     * 最大分包背包打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostPieceTemplateGivenMaxBackPack() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"最大分包背包打包计件模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 1," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.MaxDivideStrategy\"," +
                "\"packAlgorithm\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.BackPackAlgorithm\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        pieceMaxBackPackModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, pieceMaxBackPackModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(pieceMaxBackPackModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("最大分包背包打包计件模板");
    }

    /**
     * 新增计件的运费模板
     * 平均分包简单打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostPieceTemplateGivenAverageSimple() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"平均分包简单打包计件模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 1," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.AverageDivideStrategy\"," +
                "\"packAlgorithm\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.SimpleAlgorithm\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        pieceAverageSimpleModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, pieceAverageSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(pieceAverageSimpleModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("平均分包简单打包计件模板");
    }

    /**
     * 新增计件的运费模板
     * 平均分包背包打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostPieceTemplateGivenAverageBackPack() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"平均分包背包打包计件模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 1," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.AverageDivideStrategy\"," +
                "\"packAlgorithm\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.SimpleAlgorithm\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        pieceAverageBackPackModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, pieceAverageBackPackModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(pieceAverageBackPackModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("平均分包背包打包计件模板");
    }

    /**
     * 新增计件的运费模板
     * 贪心分包打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostPieceTemplateGivenGreedy() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"贪心计件模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 1," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.GreedyAverageDivideStrategy\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        pieceGreedyModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, pieceGreedyModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(pieceGreedyModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("贪心计件模板");
    }

    /**
     * 新增计件的运费模板
     * 最优分包打包
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(10)
    public void testPostPieceTemplateGivenOptimal() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{" +
                "\"name\": \"最优计件模板\"," +
                "\"defaultModel\": 0," +
                "\"type\": 1," +
                "\"divideStrategy\": \"cn.edu.xmu.oomall.shop.dao.bo.divide.OptimalDivideStrategy\"" +
                "}";

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        pieceOptimalModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);

        this.gatewayClient.get().uri(MODELID, 3, pieceOptimalModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(pieceOptimalModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("最优计件模板");
    }

    /**
     * 处理人：ChenLinghui
     * 原因：参数不存在时即被aop拦截，不会有此返回值
     */

    /**
     * 新增计重的运费模板
     * 模板为空
     *
     * @throws Exception
     * @author Huanjia Zhang
     */
    //@Test
    @Order(10)
    public void testPostWeightTemplateGivenBlank() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String body = "{}";

        this.gatewayClient.post().uri(MODEL, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isBadRequest()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());

    }

    /**
     * 商铺管理员获取运费模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(20)
    public void testGetModel() throws Exception {
        assertNotNull(weightMaxSimpleModelId);
        assertNotNull(weightMaxBackPackModelId);
        assertNotNull(weightAverageSimpleModelId);
        assertNotNull(weightAverageBackPackModelId);
        assertNotNull(weightGreedyModelId);
        assertNotNull(weightOptimalModelId);
        assertNotNull(pieceMaxSimpleModelId);
        assertNotNull(pieceMaxBackPackModelId);
        assertNotNull(pieceAverageSimpleModelId);
        assertNotNull(pieceAverageBackPackModelId);
        assertNotNull(pieceGreedyModelId);
        assertNotNull(pieceOptimalModelId);

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.get().uri(MODEL, 3)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '" + weightMaxSimpleModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + weightMaxBackPackModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + weightAverageSimpleModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + weightAverageBackPackModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + weightGreedyModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + weightOptimalModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + pieceMaxSimpleModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + pieceMaxBackPackModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + pieceAverageSimpleModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + pieceAverageBackPackModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + pieceGreedyModelId + "')].id").exists()
                .jsonPath("$.data.list[?(@.id == '" + pieceOptimalModelId + "')].id").exists();
    }

    /**
     * 商铺管理员获取运费模板
     * 指定模板的名称
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(20)
    public void testGetModelGivenName() throws Exception {
        assertNotNull(weightMaxSimpleModelId);

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.get().uri(MODEL + "?name=最大分包简单打包计重模板", 3)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.id == '" + weightMaxSimpleModelId + "')].id").exists();
    }

    /**
     * 商铺管理员获取运费模板详情
     * 获取不是该商铺管理员的模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(20)
    public void testGetModelIdGivenWrongUser() throws Exception {
        assertNotNull(weightMaxSimpleModelId);

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.get().uri(MODELID, 1, weightMaxSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 商铺管理员获取运费模板详情
     * 获取不存在的运费模板id的模板
     *
     * @throws Exception
     */
    @Test
    @Order(20)
    public void testGetModelIdGivenNoExistId() throws Exception {

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.get().uri(MODELID, 3, 111122)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺管理员修改运费模板
     * 修改不存在运费模板id的模板
     *
     * @throws Exception
     */
    @Test
    @Order(30)
    public void testPutModelGivenNoExistId() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String json = "{\"name\": \"测试修改运费模板1\"}";

        this.gatewayClient.put().uri(MODELID, 3, 111122)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺管理员修改运费模板
     * 修改不是该管理员的运费模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(30)
    public void testPutModelGivenWrongUser() throws Exception {
        assertNotNull(weightGreedyModelId);

        String token = this.adminLogin("shop1", "123456");

        String json = "{\"name\": \"测试修改运费模板2\"}";

        this.gatewayClient.put().uri(MODELID, 1, weightGreedyModelId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 商铺管理员修改运费模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(30)
    public void testPutModel() throws Exception {
        assertNotNull(weightGreedyModelId);

        String token = this.adminLogin("shop3", "123456");

        String json = "{\"name\": \"贪心分包打包计重模板修改\"}";

        this.gatewayClient.put().uri(MODELID, 3, weightGreedyModelId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(MODELID, 3, weightGreedyModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(weightGreedyModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("贪心分包打包计重模板修改");
    }

    /**
     * 商铺管理员定义计件地区模板
     * 不存在对应的运费模板Id
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(40)
    public void testPostPieceGivenNoExistId() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String json = "{" +
                "\"unit\":2," +
                "\"upperLimit\":10," +
                "\"firstItem\":2," +
                "\"firstItemPrice\": 500," +
                "\"additionalItems\": 2," +
                "\"additionalItemsPrice\": 100" +
                "}";

        this.gatewayClient.post().uri(PIECEMODEL, 3, 114514, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺管理员定义计件地区模板
     * 不是该管理员的运费模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(40)
    public void testPostPieceGivenWrongUser() throws Exception {
        assertNotNull(pieceMaxSimpleModelId);

        String token = this.adminLogin("shop1", "123456");

        String json = "{" +
                "\"unit\":2," +
                "\"upperLimit\":10," +
                "\"firstItem\":2," +
                "\"firstItemPrice\": 500," +
                "\"additionalItems\": 2," +
                "\"additionalItemsPrice\": 100" +
                "}";

        this.gatewayClient.post().uri(PIECEMODEL, 1, pieceMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 商铺管理员定义计件地区模板
     * 不存在对应的地区
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(40)
    public void testPostPieceGivenNoExistRegion() throws Exception {
        assertNotNull(pieceMaxSimpleModelId);

        String token = this.adminLogin("shop3", "123456");

        String json = "{" +
                "\"unit\":2," +
                "\"upperLimit\":10," +
                "\"firstItem\":2," +
                "\"firstItemPrice\": 500," +
                "\"additionalItems\": 2," +
                "\"additionalItemsPrice\": 100" +
                "}";

        this.gatewayClient.post().uri(PIECEMODEL, 3, pieceMaxSimpleModelId, 114514)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺管理员定义计件地区模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(50)
    public void testPostPiece() throws Exception {
        assertNotNull(pieceMaxSimpleModelId);

        String json = "{" +
                "\"unit\":2," +
                "\"upperLimit\":10," +
                "\"firstItem\":2," +
                "\"firstItemPrice\": 500," +
                "\"additionalItems\": 2," +
                "\"additionalItemsPrice\": 100" +
                "}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(PIECEMODEL, 3, pieceMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo());

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, pieceMaxSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(1)
                .jsonPath("$.data.list[?(@.region.id == '1')]").exists();

        json = "{" +
                "\"unit\":2," +
                "\"upperLimit\":10," +
                "\"firstItem\":2," +
                "\"firstItemPrice\": 500," +
                "\"additionalItems\": 2," +
                "\"additionalItemsPrice\": 100" +
                "}";

        this.gatewayClient.post().uri(PIECEMODEL, 3, pieceMaxSimpleModelId, 2)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo());

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, pieceMaxSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2)
                .jsonPath("$.data.list[?(@.region.id == '1')]").exists()
                .jsonPath("$.data.list[?(@.region.id == '2')]").exists();

    }

    /**
     * 商铺管理员定义计件地区模板
     * 存在重复的地区
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(51)
    public void testPostPieceGivenExistRegion() throws Exception {
        assertNotNull(pieceMaxSimpleModelId);

        String json = "{" +
                "\"unit\":2," +
                "\"upperLimit\":10," +
                "\"firstItem\":2," +
                "\"firstItemPrice\": 500," +
                "\"additionalItems\": 2," +
                "\"additionalItemsPrice\": 100" +
                "}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(PIECEMODEL, 3, pieceMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FREIGHT_REGIONEXIST.getErrNo());
    }

    /**
     * 商铺管理员修改计件地区模板
     * 不存在对应的模板Id
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(60)
    public void testPutPieceGivenNoExistId() throws Exception {
        String json = "{\"upperLimit\":20}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.put().uri(PIECEMODEL, 3, 114514, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺管理员修改计件地区模板
     * 不是该商户的地区模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(60)
    public void testPutPieceGivenWrongUser() throws Exception {
        //厦门市
        assertNotNull(pieceMaxSimpleModelId);

        String json = "{\"upperLimit\":20}";

        String token = this.adminLogin("shop2", "123456");

        //厦门市
        this.gatewayClient.put().uri(PIECEMODEL, 2, pieceMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 商铺管理员修改计件地区模板
     * 不存在对应的地区
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(60)
    public void testPutPieceGivenNoExistRegion() throws Exception {
        //厦门市
        assertNotNull(pieceMaxSimpleModelId);

        String json = "{\"upperLimit\":20}";

        String token = this.adminLogin("shop3", "123456");

        //厦门市
        this.gatewayClient.put().uri(PIECEMODEL, 3, pieceMaxSimpleModelId, 114514)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 处理人：ChenLinghui
     * 原因：参数不存在时即被aop拦截，不会有此返回值
     */

    /**
     * 商铺管理员定义计件地区模板
     * 模板为空
     *
     * @throws Exception
     * @author Huanjia Zhang
     */
    //@Test
    @Order(40)
    public void testPostPieceGivenBlank() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        String json = "{}";

        this.gatewayClient.post().uri(PIECEMODEL, 3, 111122, 247478)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 商铺管理员修改计件地区模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(60)
    public void testPutPiece() throws Exception {
        assertNotNull(pieceMaxSimpleModelId);

        //厦门市
        String json = "{\"upperLimit\":20}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, pieceMaxSimpleModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.region.id == '1')].upperLimit").isEqualTo(10);

        //厦门市
        this.gatewayClient.put().uri(PIECEMODEL, 3, pieceMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, pieceMaxSimpleModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.region.id == '1')].upperLimit").isEqualTo(20);
    }

    /**
     * 商铺管理员定义计重地区模板
     * 不存在对应的模板Id
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(70)
    public void testPostWeightGivenNoExistId() throws Exception {
        String json = "{\"unit\":50," +
                "\"upperLimit\":500000," +
                "\"firstWeight\":100," +
                "\"firstWeightFreight\": 1000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 100}," +
                "{\"below\": 50000, \"price\": 100}," +
                "{\"below\": 100000, \"price\": 100}," +
                "{\"below\": 300000, \"price\": 100}," +
                "{\"below\": 500000, \"price\": 100}]}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(WEIGHTMODEL, 3, 114514, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺管理员定义计重地区模板
     * 不是该管理员的模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(70)
    public void testPostWeightGivenWrongUser() throws Exception {

        assertNotNull(weightMaxSimpleModelId);

        String json = "{\"unit\":50," +
                "\"upperLimit\":500000," +
                "\"firstWeight\":100," +
                "\"firstWeightFreight\": 1000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 100}," +
                "{\"below\": 50000, \"price\": 100}," +
                "{\"below\": 100000, \"price\": 100}," +
                "{\"below\": 300000, \"price\": 100}," +
                "{\"below\": 500000, \"price\": 100}]}";

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.post().uri(WEIGHTMODEL, 1, weightMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 商铺管理员定义计重地区模板
     * 不是对应的地区
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(70)
    public void testPostWeightGivenNoExistRegion() throws Exception {
        assertNotNull(weightMaxSimpleModelId);

        String json = "{\"unit\":50," +
                "\"upperLimit\":500000," +
                "\"firstWeight\":100," +
                "\"firstWeightFreight\": 1000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 100}," +
                "{\"below\": 50000, \"price\": 100}," +
                "{\"below\": 100000, \"price\": 100}," +
                "{\"below\": 300000, \"price\": 100}," +
                "{\"below\": 500000, \"price\": 100}]}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(WEIGHTMODEL, 3, weightMaxSimpleModelId, 114514)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺管理员定义计重地区模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(70)
    public void testPostWeight() throws Exception {
        assertNotNull(weightMaxSimpleModelId);

        String json = "{\"unit\":50," +
                "\"upperLimit\":500000," +
                "\"firstWeight\":100," +
                "\"firstWeightFreight\": 1000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 100}," +
                "{\"below\": 50000, \"price\": 100}," +
                "{\"below\": 100000, \"price\": 100}," +
                "{\"below\": 300000, \"price\": 100}," +
                "{\"below\": 500000, \"price\": 100}]}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(WEIGHTMODEL, 3, weightMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo());

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, weightMaxSimpleModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(1)
                .jsonPath("$.data.list[?(@.region.id == '1')]").exists();

        json = "{\"unit\":50," +
                "\"upperLimit\":500000," +
                "\"firstWeight\":100," +
                "\"firstWeightFreight\": 1000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 100}," +
                "{\"below\": 50000, \"price\": 100}," +
                "{\"below\": 100000, \"price\": 100}," +
                "{\"below\": 300000, \"price\": 100}," +
                "{\"below\": 500000, \"price\": 100}]}";

        this.gatewayClient.post().uri(WEIGHTMODEL, 3, weightMaxSimpleModelId, 2)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo());

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, weightMaxSimpleModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list.length()").isEqualTo(2)
                .jsonPath("$.data.list[?(@.region.id == '1')]").exists()
                .jsonPath("$.data.list[?(@.region.id == '2')]").exists();
    }

    /**
     * 商铺管理员定义计重地区模板
     * 地区重复
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(71)
    public void testPostWeightGivenExistRegion() throws Exception {
        assertNotNull(weightMaxSimpleModelId);

        String json = "{\"unit\":50," +
                "\"upperLimit\":500000," +
                "\"firstWeight\":100," +
                "\"firstWeightFreight\": 1000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 100}," +
                "{\"below\": 50000, \"price\": 100}," +
                "{\"below\": 100000, \"price\": 100}," +
                "{\"below\": 300000, \"price\": 100}," +
                "{\"below\": 500000, \"price\": 100}]}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(WEIGHTMODEL, 3, weightMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FREIGHT_REGIONEXIST.getErrNo());
    }

    /**
     * 商铺管理员修改计重地区模板
     * 不是该管理员的地区模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(80)
    public void testPutWeightGivenWrongUser() throws Exception {
        assertNotNull(weightMaxSimpleModelId);

        String token = this.adminLogin("shop2", "123456");

        String json = "{\"upperLimit\":700000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 50}," +
                "{\"below\": 50000, \"price\": 50}," +
                "{\"below\": 100000, \"price\": 50}," +
                "{\"below\": 300000, \"price\": 50}," +
                "{\"below\": 500000, \"price\": 50}," +
                "{\"below\": 700000, \"price\": 50}]}";

        this.gatewayClient.put().uri(WEIGHTMODEL, 2, weightMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 商铺管理员修改计重地区模板
     * 没有对应的运费模板Id
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(80)
    public void testPutWeightGivenNoExistId() throws Exception {

        String token = this.adminLogin("shop3", "123456");

        String json = "{\"upperLimit\":700000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 50}," +
                "{\"below\": 50000, \"price\": 50}," +
                "{\"below\": 100000, \"price\": 50}," +
                "{\"below\": 300000, \"price\": 50}," +
                "{\"below\": 500000, \"price\": 50}," +
                "{\"below\": 700000, \"price\": 50}]}";

        this.gatewayClient.put().uri(WEIGHTMODEL, 3, 114514, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 商铺管理员修改计重地区模板
     * 没有对应的地区
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(80)
    public void testPutWeightGivenNoExistRegion() throws Exception {
        assertNotNull(weightMaxSimpleModelId);

        String token = this.adminLogin("shop3", "123456");

        String json = "{\"upperLimit\":700000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 50}," +
                "{\"below\": 50000, \"price\": 50}," +
                "{\"below\": 100000, \"price\": 50}," +
                "{\"below\": 300000, \"price\": 50}," +
                "{\"below\": 500000, \"price\": 50}," +
                "{\"below\": 700000, \"price\": 50}]}";

        this.gatewayClient.put().uri(WEIGHTMODEL, 3, weightMaxSimpleModelId, 114514)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 处理人：ChenLinghui
     * 原因：参数不存在时即被aop拦截，不会有此返回值
     */

    /**
     * 商铺管理员修改计重地区模板
     * 模板为空
     *
     * @throws Exception
     * @author Huanjia Zhang
     */
    //@Test
    @Order(80)
    public void testPutWeightGivenBlank() throws Exception {

        String token = this.adminLogin("shop3", "123456");

        String json = "{}";

        this.gatewayClient.put().uri(WEIGHTMODEL, 3, weightMaxSimpleModelId, 112247478)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }

    /**
     * 商铺管理员修改计重地区模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(80)
    public void testPutWeight() throws Exception {
        assertNotNull(weightMaxSimpleModelId);

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, weightMaxSimpleModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.region.id == '1')].upperLimit").isEqualTo(500000)
                .jsonPath("$.data.list[?(@.region.id == '1')].thresholds.length()").isEqualTo(5);


        String json = "{\"upperLimit\":700000," +
                "  \"thresholds\": [" +
                "{\"below\": 10000, \"price\": 50}," +
                "{\"below\": 50000, \"price\": 50}," +
                "{\"below\": 100000, \"price\": 50}," +
                "{\"below\": 300000, \"price\": 50}," +
                "{\"below\": 500000, \"price\": 50}," +
                "{\"below\": 700000, \"price\": 50}]}";

        this.gatewayClient.put().uri(WEIGHTMODEL, 3, weightMaxSimpleModelId, 1)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, weightMaxSimpleModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.region.id == '1')].upperLimit").isEqualTo(700000)
                .jsonPath("$.data.list[?(@.region.id == '1')].thresholds.length()").isEqualTo(6);
    }

    /**
     * 管理员克隆运费模板
     * 没有对应的模板Id
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(90)
    public void testCloneModelGivenNoExistId() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(CLONE, 3, 111122)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员克隆运费模板
     * 不是该管理员的模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(90)
    public void testCloneModelGivenWrongUser() throws Exception {
        assertNotNull(pieceMaxSimpleModelId);

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.post().uri(CLONE, 1, pieceMaxSimpleModelId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 管理员克隆运费模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(90)
    public void testCloneModel() throws Exception {
        assertNotNull(pieceMaxSimpleModelId);

        String token = this.adminLogin("shop3", "123456");

        String ret = new String(Objects.requireNonNull(this.gatewayClient.post().uri(CLONE, 3, pieceMaxSimpleModelId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody()), "UTF-8");

        cloneModelId = JacksonUtil.parseSubnodeToObject(ret, "/data/id", Long.class);
    }

    /**
     * 管理员修改克隆模板
     *
     * @throws Exception
     */
    @Test
    @Order(100)
    public void testPutCloneModelID() throws Exception {
        assertNotNull(cloneModelId);

        String json = "{\"name\": \"测试修改克隆模板1\"}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.get().uri(MODELID, 3, cloneModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(cloneModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0);

        this.gatewayClient.put().uri(MODELID, 3, cloneModelId)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(MODELID, 3, cloneModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.id").isEqualTo(cloneModelId.intValue())
                .jsonPath("$.data.defaultModel").isEqualTo(0)
                .jsonPath("$.data.name").isEqualTo("测试修改克隆模板1");

    }

    /**
     * 管理员根据克隆模板定义地区模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(110)
    public void testPostClonePiece() throws Exception {
        assertNotNull(cloneModelId);

        String json = "{" +
                "\"unit\":2," +
                "\"upperLimit\":10," +
                "\"firstItem\":2," +
                "\"firstItemPrice\": 500," +
                "\"additionalItems\": 2," +
                "\"additionalItemsPrice\": 100" +
                "}";

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, cloneModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.region.id == '3')]").doesNotExist();

        this.gatewayClient.post().uri(PIECEMODEL, 3, cloneModelId, 3)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo());

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, cloneModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.data.list[?(@.region.id == '3')]").exists();
    }

    /**
     * 管理员删除地区模板
     * 不是该管理员的模板
     *
     * @throws Exception
     */
    @Test
    @Order(120)
    public void testDelPieceGivenWrongUser() throws Exception {
        assertNotNull(cloneModelId);

        String token = this.adminLogin("shop2", "123456");

        //莆田
        this.gatewayClient.delete().uri(REGIONTEMPLATE, 2, cloneModelId, 3)
                .header("authorization", token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 管理员删除地区模板
     * 不存在对应的模板Id
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(120)
    public void testDelPieceGivenNoExistID() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        //莆田
        this.gatewayClient.delete().uri(REGIONTEMPLATE, 3, 1223, 3)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员删除地区模板
     * 不存在对应地区的模板
     *
     * @throws Exception
     */
    @Test
    @Order(120)
    public void testDelPieceGivenNoExistRegion() throws Exception {
        assertNotNull(cloneModelId);

        String token = this.adminLogin("shop3", "123456");

        //莆田
        this.gatewayClient.delete().uri(REGIONTEMPLATE, 3, cloneModelId, 24812059)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员删除地区模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(120)
    public void testDelPiece() throws Exception {
        assertNotNull(cloneModelId);

        String token = this.adminLogin("shop3", "123456");

        //莆田
        this.gatewayClient.delete().uri(REGIONTEMPLATE, 3, cloneModelId, 3)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(REGIONMODEL + "?page=1&pageSize=30", 3, cloneModelId)
                .header("authorization", token)
                .exchange().expectStatus().isOk()
                .expectHeader().contentType("application/json;charset=UTF-8")
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.region.id == '3')]").doesNotExist();
    }

    /**
     * 管理员删除地区模板
     * 模板已经删除不存在
     *
     * @throws Exception
     */
    @Test
    @Order(121)
    public void testDelPieceGivenNoExist() throws Exception {
        assertNotNull(cloneModelId);

        String token = this.adminLogin("shop3", "123456");

        //莆田
        this.gatewayClient.delete().uri(REGIONTEMPLATE, 3, cloneModelId, 3)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员克隆地区模板
     *
     * @throws Exception
     * @author Caozhiyi
     */
    @Test
    @Order(130)
    public void testCloneRegionModel() throws Exception {
        String token = this.adminLogin("shop3", "123456");
        this.gatewayClient.post().uri(CLONEREGION, 1, 1, 1, 2)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .returnResult().getResponseBody();
    }


    /**
     * 管理员克隆地区模板
     * 商铺没有对应的模板Id
     *
     * @throws Exception
     * @author Caozhiyi
     */
    @Test
    @Order(130)
    public void testCloneRegionModelGivenNoExistId() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(CLONEREGION, 3, 111122, 251197, 2)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo())
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

    }

    /**
     * 管理员克隆地区模板
     * 商铺没有对应的源地区Id
     *
     * @throws Exception
     * @author Caozhiyi
     */
    @Test
    @Order(130)
    public void testCloneRegionModelGivenNoExistOriginRegionId() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(CLONEREGION, 1, 1, 9999999, 2)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员克隆地区模板
     * 非商铺管理员越权操作
     * @throws Exception
     * @author Caozhiyi
     */
    @Test
    @Order(130)
    public void testCloneRegionModelWithNoAdmin() throws Exception {
        String token = this.customerLogin("customer1", "123456");

        this.gatewayClient.post().uri(CLONEREGION, 1, 1, 251197, 2)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 管理员克隆地区模板
     * 商铺没有对应的对应地区Id
     *
     * @throws Exception
     * @author Caozhiyi
     */
    @Test
    @Order(130)
    public void testCloneRegionModelGivenNoExistRegionId() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(CLONEREGION, 1, 1, 251197, 2261378)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员克隆运费模板
     * 源地区id与目标地区id一致
     *
     * @throws Exception
     * @author Caozhiyi
     */
    @Test
    @Order(130)
    public void testCloneRegionModelGivenWrongRegion() throws Exception {

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.post().uri(CLONEREGION, 1, 1, 251197, 251197)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员删除运费模板
     * 不是该管理员的运费模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(140)
    public void testDelModelGivenWrongUser() throws Exception {
        assertNotNull(weightAverageSimpleModelId);

        String token = this.adminLogin("shop1", "123456");

        this.gatewayClient.delete().uri(DELMODEL, 1, weightAverageSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * 管理员删除运费模板
     * 没有对应的模板Id
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(140)
    public void testDelModelGivenNoExistID() throws Exception {
        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.delete().uri(DELMODEL, 3, 114514)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * 管理员删除运费模板
     *
     * @throws Exception
     * @author ZhaoDong Wang
     */
    @Test
    @Order(140)
    public void testDelModel() throws Exception {
        assertNotNull(weightAverageSimpleModelId);

        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.delete().uri(DELMODEL, 3, weightAverageSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());

        this.gatewayClient.get().uri(MODELID, 3, weightAverageSimpleModelId)
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @throws Exception
     * @author renyu
     * 克隆运费模板至一个已有运费模板的地区
     */
    @Test
    @Order(90)
    public void testCloneFreightTemplateToRegionGivenExistingTemplate() throws Exception {
        assertNotNull(pieceMaxSimpleModelId);
        String token = this.adminLogin("shop3", "123456");

        this.gatewayClient.post().uri(CLONEREGION, 3, pieceMaxSimpleModelId, 1, 247478)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FREIGHT_REGIONEXIST.getErrNo());
    }

    /**
     * @throws Exception
     * @author renyu
     * 店铺管理员尝试克隆不属于自己店铺的运费模板
     */
    @Test
    public void testCloneFreightTemplateOfAnotherShopGivenUnauthorized() throws Exception {
        String token = this.adminLogin("shop3", "123456");
        // shop3尝试克隆shop4的运费模板
        this.gatewayClient.post().uri(CLONEREGION, 4, pieceMaxSimpleModelId, 1, 2)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

}
