package cn.edu.xmu.oomall.publictest.required.freight;

import cn.edu.xmu.oomall.publictest.BaseTestOomall;
import cn.edu.xmu.oomall.publictest.PublicTestApp;
import cn.edu.xmu.oomall.publictest.ReturnNo;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@SpringBootTest(classes = PublicTestApp.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ShopLogisticTest extends BaseTestOomall{
    private String SHOPLOGISTIC = "/freight/shops/{shopId}/shoplogistics";

    private String PUTSHOPLOGISTIC = "/freight/shops/{shopId}/shoplogistics/{id}";

    private String SUSPENDLOGISTIC = "/freight/shops/{shopId}/shoplogistics/{id}/suspend";

    private String RESUMELOGISITIC = "/freight/shops/{shopId}/shoplogistics/{id}/resume";

    private String SHOPLOGISTICSREGIONUNDEL = "/freight/shops/{shopId}/shoplogistics/{id}/regions/{rid}/undeliverable";

    private String SHOPLOGISTICSUNDELREGIONS = "/freight/shops/{shopId}/shoplogistics/{id}/undeliverableregions";

    /**
     * @author fan ninghan
     * 商户添加不可配送地区 - 由无权操作shopLogistics的商户添加
     */
    @Test
    public void testAddUndeliverableGivenUnauthorizedShop() throws Exception{
        String token = this.adminLogin("shop9", "123456");
        String json = "{\"beginTime\":\"2013-12-05T10:09:50\",\"endTime\":\"2032-12-05T10:09:50\"}";
        this.gatewayClient.post().uri(SHOPLOGISTICSREGIONUNDEL, 9L, 4L, 66L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author fan ninghan
     * 商户添加不可配送地区 - region不存在
     */
    @Test
    public void testAddUndeliverableGivenUnrealRegion() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"beginTime\":\"2013-12-05T10:09:50\",\"endTime\":\"2032-12-05T10:09:50\"}";
        this.gatewayClient.post().uri(SHOPLOGISTICSREGIONUNDEL, 2L, 4L, 9999L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author fan ninghan
     * 商户添加不可配送地区 - 成功
     */
    @Test
    public void testAddUndeliverable() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"beginTime\":\"2013-12-05T10:09:50\",\"endTime\":\"2032-12-05T10:09:50\"}";
        this.gatewayClient.post().uri(SHOPLOGISTICSREGIONUNDEL, 2L, 4L, 66L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo());
    }

    /**
     * @author fan ninghan
     * 商户修改不可配送地区 - 由无权操作shopLogistics的商户添加
     */
    @Test
    public void testModifyUndeliverableGivenUnauthorizedShop() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"beginTime\":\"2013-12-05T10:09:50\",\"endTime\":\"2022-11-11T10:09:50\"}";
        this.gatewayClient.put().uri(SHOPLOGISTICSREGIONUNDEL, 1L, 4L, 66L)   // 之前测试中新增的不可配送地区
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author fan ninghan
     * 商户修改不可配送地区 - RegionId不存在
     * (RegionId存在，但不在shopLogisticsId的Undeliverable中报错依然为RESOURCE_ID_NOTEXIST，此处不重复测试类似情况）
     */
    @Test
    public void testModifyUndeliverableGivenUnrealRegion() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"beginTime\":\"2013-12-05T10:09:50\",\"endTime\":\"2022-11-11T10:09:50\"}";
        this.gatewayClient.put().uri(SHOPLOGISTICSREGIONUNDEL, 2L, 4L, 9999L)   // 之前测试中新增的不可配送地区
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author hyx
     * 商户新增不可配送地区 - 非法参数，开始时间晚于结束时间
     */
    @Test
    public void testAddUndeliverableGivenEarlyEnd() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"beginTime\":\"2013-12-05T10:09:50\",\"endTime\":\"2032-12-05T10:09:50\"}";
        this.gatewayClient.post().uri(SHOPLOGISTICSREGIONUNDEL, 2L, 4L, 66L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.LATE_BEGINTIME.getErrNo());
    }

    /**
     * @author fan ninghan
     * 商户修改不可配送地区 - 非法参数，开始时间晚于结束时间
     */
    @Test
    public void testModifyUndeliverableGivenEarlyEnd() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"beginTime\":\"2032-12-05T10:09:50\",\"endTime\":\"2013-12-05T10:09:50\"}";
        this.gatewayClient.put().uri(SHOPLOGISTICSREGIONUNDEL, 2L, 4L, 66L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.LATE_BEGINTIME.getErrNo());
    }

    /**
     * @author fan ninghan
     * 商户修改不可配送地区 - 成功
     */
    @Test
    public void testModifyUndeliverable() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"beginTime\":\"2013-12-05T10:09:50\",\"endTime\":\"2022-11-11T10:09:50\"}";
        this.gatewayClient.put().uri(SHOPLOGISTICSREGIONUNDEL, 2L, 4L, 66L)   // 之前测试中新增的不可配送地区
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author fan ninghan
     * 商户获取不可配送地区 - 成功：同时确认增加修改是否成功
     */
    @Test
    public void testGetUndeliverable() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.get().uri(SHOPLOGISTICSUNDELREGIONS, 2L, 4L)   // 之前测试中新增的不可配送地区
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[?(@.region.id==66)].beginTime").isEqualTo("2013-12-05T10:09:50")
                .jsonPath("$.data.list[?(@.region.id==66)].endTime").isEqualTo("2022-11-11T10:09:50");  // 符合修改后的时间
    }

    /**
     * @author fan ninghan
     * 商户删除不可配送地区 - 由无权操作的商户删除
     */
    @Test
    public void testDeleteUndeliverableGivenUnauthorizedShop() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.delete().uri(SHOPLOGISTICSREGIONUNDEL, 1L, 4L, 66L)   // 之前测试中新增并修改的不可配送地区
                .header("authorization", token)
                .exchange()
                .expectStatus().isForbidden()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author fan ninghan
     * 商户删除不可配送地区 - Region存在，但不在shopLogisticsId的Undeliverable中
     * (与修改类似，RegionId不存在的报错依然为RESOURCE_ID_NOTEXIST，此处不重复测试类似情况）
     */
    @Test
    public void testDeleteUndeliverableGivenNotExistUndel() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.delete().uri(SHOPLOGISTICSREGIONUNDEL, 2L, 4L, 55L)   // 存在的地区，但不在undel中
                .header("authorization", token)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author fan ninghan
     * 商户删除不可配送地区 - 成功
     */
    @Test
    public void testDeleteUndeliverable() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.delete().uri(SHOPLOGISTICSREGIONUNDEL, 2L, 4L, 66L)   // 之前测试中新增并修改的不可配送地区
                .header("authorization", token)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 商户添加合作物流 - 无物流
     * @throws Exception
     */
    @Test
    public void testAddShopLogisticGivenNotExist() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"logisticsId\":\"99\", \"secret\":\"secret2\", \"priority\":\"6\"}";
        this.gatewayClient.post().uri(SHOPLOGISTIC, 1L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 商户添加合作物流 - 已有合作物流
     * @throws Exception
     */
    @Test
    public void testAddShopLogisticGivenFail() throws Exception{
        String token = this.adminLogin("shop1", "123456");
        String json = "{\"logisticsId\":\"1\", \"secret\":\"secret1\", \"priority\":\"6\"}";
        this.gatewayClient.post().uri(SHOPLOGISTIC, 1L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FREIGHT_LOGISTIC_EXIST.getErrNo());
    }
    /**
     * @author Yangxin Jiang
     * 商户添加合作物流 - 成功添加
     * @throws Exception
     */
    @Test
    public void testAddShopLogisticGivenSuccess() throws Exception{
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"logisticsId\":\"2\", \"secret\":\"secret1\", \"priority\":\"6\"}";
        this.gatewayClient.post().uri(SHOPLOGISTIC, 2L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.CREATED.getErrNo())
                .jsonPath("$.data.logistics.id").isEqualTo(0);
    }

    /**
     * @author Yangxin Jiang
     * 商户查看合作物流详情 - 成功获得有物流记录的商铺物流信息
     * @throws Exception
     */
    @Test
    public void testGetShopLogisticsSuccess() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.post().uri(SHOPLOGISTIC, 2L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list[0].logistics.id").isEqualTo(1);
    }

    /**
     * @author Yangxin Jiang
     * 商户查看合作物流详情 - 商铺无对应物流信息
     * @throws Exception
     */
    @Test
    public void testGetShopLogisticsEmpty() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.post().uri(SHOPLOGISTIC, 2L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo())
                .jsonPath("$.data.list").isEmpty();
    }

    /**
     * @author Yangxin Jiang
     * 商户修改物流合作信息 - 修改LogisticId
     * @throws Exception
     */
    @Test
    public void testPutShopLogisticsGivenInValid() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"logisticsId\":\"666\", \"secret\":\"secret1\", \"priority\":\"6\"}";
        this.gatewayClient.put().uri(PUTSHOPLOGISTIC, 2L,1L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.FIELD_NOTVALID.getErrNo());
    }


    /**
     * @author Yangxin Jiang
     * 商户修改物流合作信息 - logisticId不存在
     * @throws Exception
     */
    @Test
    public void testPutShopLogisticsGivenNotExist() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"secret\":\"secret1\", \"priority\":\"6\"}";
        this.gatewayClient.put().uri(PUTSHOPLOGISTIC, 2L,1121L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 商户修改物流合作信息 - shop与shoplogisticId不匹配
     * @throws Exception
     */
    @Test
    public void testPutShopLogisticsGivenNotExist2() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"secret\":\"secret1\", \"priority\":\"6\"}";
        this.gatewayClient.put().uri(PUTSHOPLOGISTIC, 2L,2L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 商户修改物流合作信息 - 修改成功
     * @throws Exception
     */
    @Test
    public void testPutShopLogisticsGivenSuccess() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        String json = "{\"secret\":\"secret6\", \"priority\":\"6\"}";
        this.gatewayClient.put().uri(PUTSHOPLOGISTIC, 1L,1L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 商户停用某个物流合作 - 物流不存在
     * @throws Exception
     */
    @Test
    public void testSuspendShopLogisticsGivenNotExit() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(SUSPENDLOGISTIC, 2L,112345L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 商户停用某个物流合作 - 商户未与物流建立合作
     * @throws Exception
     */
    @Test
    public void testSuspendShopLogisticsGivenNotExit2() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(SUSPENDLOGISTIC, 2L,2L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }
    /**
     * @author Yangxin Jiang
     * 商户停用某个物流合作 - 禁用已经禁用的物流
     * @throws Exception
     */
    @Test
    public void testSuspendShopLogisticsGivenForbidden() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(SUSPENDLOGISTIC, 1L,3L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }
    /**
     * @author Yangxin Jiang
     * 商户停用某个物流合作 - 禁用成功
     * @throws Exception
     */
    @Test
    public void testSuspendShopLogisticsGivenSuccess() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(SUSPENDLOGISTIC, 1L,1L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }
    /**
     * @author Yangxin Jiang
     * 商户恢复物流 - 不存在shopLogisticId
     * @throws Exception
     */
    @Test
    public void testResumeShopLogisticsGivenNotExist() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(RESUMELOGISITIC, 1L,112345L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_NOTEXIST.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 商户恢复物流 - shopLogisticId的shopId与shopId不符
     * @throws Exception
     */
    @Test
    public void testResumeShopLogisticsGivenForbidden() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(RESUMELOGISITIC, 2L,1L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.RESOURCE_ID_OUTSCOPE.getErrNo());
    }

    /**
     * @author Yangxin Jiang
     * 商户恢复某个物流合作 - 恢复正常物流
     * @throws Exception
     */
    @Test
    public void testResumeShopLogisticsGivenForbidden2() throws Exception {
        String token = this.adminLogin("shop2", "123456");
        this.gatewayClient.put().uri(RESUMELOGISITIC, 1L,1L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.STATENOTALLOW.getErrNo());
    }
    /**
     * @author Yangxin Jiang
     * 商户恢复某个物流合作 - 恢复成功
     * @throws Exception
     */
    @Test
    public void testResumeShopLogisticsGivenSuccess() throws Exception {
        String token = this.adminLogin("shop1", "123456");
        this.gatewayClient.put().uri(RESUMELOGISITIC, 1L,3L)
                .header("authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.errno").isEqualTo(ReturnNo.OK.getErrNo());
    }
}
