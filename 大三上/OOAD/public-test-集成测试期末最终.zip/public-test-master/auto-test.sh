#!/bin/bash
docker rm $(docker ps -a -q)
TIME=$(date "+%Y%m%d%H%M%S")
docker exec -i $(docker container ls -aq -f name=test.*) bash /public-test/runtest.sh required $TIME gateway:8080 gateway:8080 192.168.0.48   *****
