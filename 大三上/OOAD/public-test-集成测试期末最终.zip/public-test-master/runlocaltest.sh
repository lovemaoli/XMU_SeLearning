#!/bin/bash
## modified by luxun@2020

## 将文件结尾从CRLF改为LF，解决了cd 错误问题
cd /public-test
git pull

cd /test/integration-test

if [ ! -d $1 ];then
  mkdir $1
fi

mkdir $1/$2
mkdir $1/$2/css
mkdir $1/$2/images
mkdir $1/$2/images/logos

if [ ! -d /temp ];then
  mkdir /temp
fi

cd /temp

if [ -d $1 ];then
  rm -r "$1"
fi

mkdir "$1"
echo “mkdir $1”
#mkdir "$1/public"
#echo “mkdir $1/public”
#mkdir "$1/private"

cp -rf /public-test/* $1
#cp -rf /home/mybaby/private-test/* $1/private

## 在主项目下使用 -pl -am 编译子项目，否则找不到依赖
## $1 代表第一个参数，$0代表命令名
cd $1
mvn clean surefire-report:report -Dmanagement.gate=$3 -Dmall.gate=$4 1>public.log
cp  target/site/surefire-report.html /test/integration-test/$1/$2/index.html
cp  css/apache-maven-fluido-1.11.1.min.css /test/integration-test/$1/$2/css/apache-maven-fluido-1.11.1.min.css
cp  css/print.css /test/integration-test/$1/$2/css/print.css
cp  css/site.css /test/integration-test/$1/$2/css/site.css
cp  images/logos/maven-feather.png /test/integration-test/$1/$2/images/logos/maven-feather.png
cp  public.log /test/integration-test/$1/$2/public.log

#cd ../private
#mvn surefire-report:report -Dmanagement.gate=$3 -Dmall.gate=$4
#mvn site:deploy
