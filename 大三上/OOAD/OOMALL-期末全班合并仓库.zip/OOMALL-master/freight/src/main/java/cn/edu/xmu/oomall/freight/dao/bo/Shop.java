package cn.edu.xmu.oomall.freight.dao.bo;

public class Shop {
}
