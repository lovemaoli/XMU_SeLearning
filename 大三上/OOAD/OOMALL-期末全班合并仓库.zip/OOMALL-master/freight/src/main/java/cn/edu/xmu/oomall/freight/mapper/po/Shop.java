package cn.edu.xmu.oomall.freight.mapper.po;

public class Shop {
    private Long id;

    private String name;
}
