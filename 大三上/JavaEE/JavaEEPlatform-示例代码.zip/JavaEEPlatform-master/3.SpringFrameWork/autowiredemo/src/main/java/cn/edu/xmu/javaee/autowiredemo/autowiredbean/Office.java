// JavaEEPlatform by School of Informatics Xiamen University, GPL-3.0 license
package cn.edu.xmu.javaee.autowiredemo.autowiredbean;

import org.springframework.stereotype.Component;

/**
 * @author: Ming Qiu
 * @date: Created in 17:02 2020/7/31
 **/
@Component
public class Office {
}
