// JavaEEPlatform by School of Informatics Xiamen University, GPL-3.0 license
package cn.edu.xmu.javaee.autowiredemo.autowiredbean;

/**
 * @author: Ming Qiu
 * @date: Created in 17:01 2020/7/31
 **/
public interface Car {
}
