// JavaEEPlatform by School of Informatics Xiamen University, GPL-3.0 license
package cn.edu.xmu.javaee.autowiredemo.autowiredbean;

/**
 * @author: Ming Qiu
 * @date: Created in 9:06 2020/9/19
 **/
public class Haval implements Car {
}
