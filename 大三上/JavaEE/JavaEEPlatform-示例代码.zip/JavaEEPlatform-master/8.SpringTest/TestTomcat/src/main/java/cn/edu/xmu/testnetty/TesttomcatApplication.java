package cn.edu.xmu.testnetty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesttomcatApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesttomcatApplication.class, args);
	}

}
