package cn.edu.xmu.testnetty;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesttomcatApplicationTests {

	@Test
	void contextLoads() {
	}

}
