package cn.edu.xmu.rocketmqdemo.model;

/**
 * @author Ming Qiu
 **/
public interface VoObject {

    /**
     * 创建Vo对象
     * @return Vo对象
     */
    public Object createVo();
}
