//School of Informatics Xiamen University, GPL-3.0 license
package cn.edu.xmu.javaee.productdemo.controller.vo;

import cn.edu.xmu.javaee.productdemo.dao.bo.OnSale;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class SimpleProductRetVo {

    private Long id;
    private String name;
    private String imageUrl;
    private Long price;
    private Integer quantity;
    private Byte status;
}
