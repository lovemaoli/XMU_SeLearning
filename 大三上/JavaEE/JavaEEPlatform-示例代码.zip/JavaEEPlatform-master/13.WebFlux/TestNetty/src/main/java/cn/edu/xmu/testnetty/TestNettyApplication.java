package cn.edu.xmu.testnetty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestNettyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestNettyApplication.class, args);
	}

}
