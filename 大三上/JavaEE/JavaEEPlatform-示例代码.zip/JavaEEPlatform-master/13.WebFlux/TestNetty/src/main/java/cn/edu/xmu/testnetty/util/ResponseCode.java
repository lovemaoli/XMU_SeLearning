package cn.edu.xmu.testnetty.util;

/**
 * 返回的错误码
 * @author Ming Qiu
 */
public class ResponseCode {

    public static final Integer OK = 0;
    public static final String OK_MSG = "成功";
}
