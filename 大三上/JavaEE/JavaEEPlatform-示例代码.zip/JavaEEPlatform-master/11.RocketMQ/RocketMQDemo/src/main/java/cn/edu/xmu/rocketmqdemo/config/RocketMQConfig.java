package cn.edu.xmu.rocketmqdemo.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author Ming Qiu
 * @date Created in 2020/11/8 5:49
 **/
@Configuration
public class RocketMQConfig {

}
